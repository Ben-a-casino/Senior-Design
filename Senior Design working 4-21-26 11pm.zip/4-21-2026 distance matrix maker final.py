from __future__ import annotations

import argparse
import ast
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
import math
from zoneinfo import ZoneInfo

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Optional
import logging

import geopandas as gpd
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from shapely.geometry import LineString, Point, Polygon


try:
    import requests
except ImportError:
    requests = None

try:
    import boto3
except ImportError:
    boto3 = None

try:
    from slack_sdk import WebClient
    from slack_sdk.errors import SlackApiError
except ImportError:
    WebClient = None

    class SlackApiError(Exception):
        pass

try:
    import pytz
except ImportError:
    pytz = None

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*args: Any, **kwargs: Any) -> bool:
        return False


load_dotenv("env_variables.env")


# =========================================================
# LOGGING
# =========================================================

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)


# =========================================================
# VEHICLE POSITION POLLING CONFIG
# =========================================================

headers = {
    'Authorization': os.environ.get('SWIFTLY_AUTHORIZATION_TOKEN'),
    'Content-Type': 'application/octet-stream',
    'Accept': 'application/json',
}

positions_url = 'https://api.goswift.ly/real-time/mta-maryland/gtfs-rt-vehicle-positions'
positions_queryString = {
    'format': 'json',
    'enable-feature': 'deleted-trips',
}

SLACK_BOT_TOKEN = os.environ.get('SLACK_BOT_TOKEN')
channel_id = os.environ.get('SLACK_CHANNEL_ID', 'mta-updates')
S3_BUCKET = os.environ.get('S3_BUCKET', 's3-tbb-data-dev')


def get_slack_client() -> Optional[WebClient]:
    if WebClient is None or not SLACK_BOT_TOKEN:
        return None
    return WebClient(token=SLACK_BOT_TOKEN)


def get_s3_client():
    if boto3 is None:
        return None
    return boto3.client('s3')


# =========================================================
# CONSTANTS / CONFIG
# =========================================================

Mode = Literal["walk", "drive"]
INVALID_STATUS = "INVALID_NON_NEIGHBOR"
INVALID_MATRIX_VALUE = -1.0

DOWNTOWN_BALTIMORE_LON = -76.6122
DOWNTOWN_BALTIMORE_LAT = 39.2904

TOP_5_HIGH_SCHOOLS = [
    {"rank": 1, "school_name": "Eastern Technical High School", "address": "1100 Mace Avenue, Baltimore, MD 21221", "lon": -76.4598, "lat": 39.3088},
    {"rank": 2, "school_name": "Western School of Technology & Environmental Science", "address": "100 Kenwood Avenue, Catonsville, MD 21228", "lon": -76.7332, "lat": 39.2698},
    {"rank": 3, "school_name": "George W. Carver Center for Arts & Technology", "address": "938 York Road, Towson, MD 21204", "lon": -76.6046, "lat": 39.4105},
    {"rank": 4, "school_name": "Towson High School", "address": "69 Cedar Avenue, Towson, MD 21286", "lon": -76.6018, "lat": 39.4003},
    {"rank": 5, "school_name": "Hereford High School", "address": "17301 York Road, Parkton, MD 21120", "lon": -76.6500, "lat": 39.6416},
]

# Top 10 high schools (deterministic coordinates)
TOP_10_HIGH_SCHOOLS = [
    ("Eastern Technical High School", -76.4598, 39.3088),
    ("Western School of Technology", -76.7332, 39.2698),
    ("Carver Center", -76.6046, 39.4105),
    ("Towson High School", -76.6018, 39.4003),
    ("Hereford High School", -76.6500, 39.6416),
    ("Dulaney High School", -76.5765, 39.3930),
    ("Perry Hall High School", -76.4430, 39.3549),
    ("Franklin High School", -76.7500, 39.3500),
    ("Parkville High School", -76.5976, 39.3690),
    ("Catonsville High School", -76.7121, 39.2718),
]


@dataclass(frozen=True)
class RouteResult:
    distance_m: float
    travel_time_min: float
    mode: str
    time_window: Optional[str]
    source: str


@dataclass(frozen=True)
class ProjectConfig:
    input_crs: str = "EPSG:4326"
    projected_crs: str = "EPSG:5070"
    default_id_col: str = "GEOID"
    require_shared_boundary: bool = True
    use_synthetic_backup: bool = True
    create_school_routes: bool = True
    auto_download_real_tracts: bool = True
    baltimore_city_tract_geojson_url: str = "https://egisdata.baltimorecity.gov/egis/rest/services/311/ReferenceLayer/MapServer/49"
    census_tiger_md_tract_zip_url: str = "https://www2.census.gov/geo/tiger/TIGER2024/TRACT/tl_2024_24_tract.zip"
    census_baltimore_city_countyfp: str = "510"
    auto_download_cache_dir: str = "data_cache"
    use_live_traffic_api: bool = True
    google_routes_api_key: Optional[str] = field(default_factory=lambda: os.getenv("GOOGLE_MAPS_API_KEY"))
    google_routes_matrix_url: str = "https://routes.googleapis.com/distanceMatrix/v2:computeRouteMatrix"
    google_routes_field_mask: str = "originIndex,destinationIndex,distanceMeters,duration,staticDuration,condition,status"
    traffic_timezone: str = "America/New_York"
    route_request_timeout_sec: int = 60
    route_api_cache_filename: str = "route_api_cache.json"
    search_roots: tuple[str, ...] = (
        r"D:\\",
        r"D:\\Senior-Design",
        r"D:\\TransitNightmare",
        r"D:\\BusPosition",
        r"D:\\data",
    )
    search_keywords: tuple[str, ...] = (
        "baltimore county",
        "baltimore_county",
        "baltimorecounty",
        "baltimore city",
        "baltimore_city",
        "baltimorecity",
        "tract",
        "tracts",
        "census tract",
        "census_tract",
        "bus position",
        "transit nightmare",
    )
    allowed_extensions: tuple[str, ...] = (".shp", ".geojson", ".gpkg", ".json")
    max_search_depth: int = 6
    walk_distance_factor: float = 1.20
    drive_distance_factor: float = 1.35
    walk_speed_m_per_min: float = 80.4672
    drive_speeds_m_per_min: dict[str, float] = field(
        default_factory=lambda: {
            "OFFPEAK": 536.448,
            "AM_PEAK_7_8": 402.336,
            "PM_PEAK_3_4": 375.7824,
        }
    )


@dataclass(frozen=True)
class OutputFiles:
    adjacency_matrix_csv: str = "tract_adjacency_matrix_adjacent_only.csv"
    neighbor_csv: str = "tract_neighbor_distances.csv"
    walk_distance_matrix_csv: str = "tract_walk_distance_matrix_adjacent_only.csv"
    walk_time_matrix_csv: str = "tract_walk_time_matrix_adjacent_only.csv"
    drive_distance_matrix_csv: str = "tract_drive_distance_matrix_adjacent_only.csv"
    drive_time_offpeak_matrix_csv: str = "tract_drive_time_matrix_offpeak_adjacent_only.csv"
    drive_time_am_matrix_csv: str = "tract_drive_time_matrix_am_7_8_adjacent_only.csv"
    drive_time_pm_matrix_csv: str = "tract_drive_time_matrix_pm_3_4_adjacent_only.csv"
    walk_distance_matrix_by_id_csv: str = "tract_walk_distance_matrix_adjacent_only_by_id.csv"
    walk_time_matrix_by_id_csv: str = "tract_walk_time_matrix_adjacent_only_by_id.csv"
    drive_distance_matrix_by_id_csv: str = "tract_drive_distance_matrix_adjacent_only_by_id.csv"
    drive_time_offpeak_matrix_by_id_csv: str = "tract_drive_time_matrix_offpeak_adjacent_only_by_id.csv"
    drive_time_am_matrix_by_id_csv: str = "tract_drive_time_matrix_am_7_8_adjacent_only_by_id.csv"
    drive_time_pm_matrix_by_id_csv: str = "tract_drive_time_matrix_pm_3_4_adjacent_only_by_id.csv"
    tract_lookup_csv: str = "tract_lookup.csv"
    route_validation_csv: str = "route_validation_report.csv"
    run_metadata_json: str = "run_metadata.json"
    query_results_csv: str = "tract_pair_query_results.csv"
    adjacency_map_png: str = "tract_adjacency_only_map.png"
    distance_heatmap_png: str = "adjacent_only_distance_heatmaps.png"
    school_route_map_png: str = "top5_high_schools_to_downtown_routes.png"
    school_route_summary_csv: str = "top5_high_school_route_summary.csv"
    school_route_edges_csv: str = "top5_high_school_route_edges.csv"


# =========================================================
# BASIC HELPERS
# =========================================================


def meters_to_miles(meters: float) -> float:
    return meters / 1609.344


def ensure_directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def timestamp_suffix() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_to_csv(df: pd.DataFrame, path: str | Path, **kwargs: Any) -> Path:
    out_path = Path(path)
    ensure_directory(out_path.parent)
    try:
        df.to_csv(out_path, **kwargs)
        return out_path
    except PermissionError:
        fallback = out_path.with_name(f"{out_path.stem}_{timestamp_suffix()}{out_path.suffix}")
        df.to_csv(fallback, **kwargs)
        logger.warning("Could not write to %s; wrote to %s instead.", out_path, fallback)
        return fallback


def safe_write_json(data: Any, path: str | Path) -> Path:
    out_path = Path(path)
    ensure_directory(out_path.parent)
    try:
        out_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return out_path
    except PermissionError:
        fallback = out_path.with_name(f"{out_path.stem}_{timestamp_suffix()}{out_path.suffix}")
        fallback.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.warning("Could not write to %s; wrote to %s instead.", out_path, fallback)
        return fallback


def _download_text(url: str, timeout: int = 60) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read().decode("utf-8")


def _download_bytes(url: str, timeout: int = 60) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


OFFICIAL_BALTIMORE_CITY_TRACTS_LAYER = (
    "https://egisdata.baltimorecity.gov/egis/rest/services/311/ReferenceLayer/MapServer/49"
)
OFFICIAL_CENSUS_MD_TRACTS_ZIP = (
    "https://www2.census.gov/geo/tiger/TIGER2024/TRACT/tl_2024_24_tract.zip"
)


def get_cache_dir(config: ProjectConfig) -> Path:
    cache_dir = Path(config.auto_download_cache_dir)
    if not cache_dir.is_absolute():
        cache_dir = Path(__file__).resolve().parent / cache_dir
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def build_arcgis_query_url(base_layer_url: str, *, out_fields: str = "*", where: str = "1=1") -> str:
    params = {
        "where": where,
        "outFields": out_fields,
        "returnGeometry": "true",
        "f": "geojson",
        "outSR": "4326",
    }
    return f"{base_layer_url}/query?{urllib.parse.urlencode(params)}"


def standardize_real_tract_fields(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    standardized = gdf.copy()

    rename_map = {}
    if "GEOID" not in standardized.columns:
        for candidate in ["GEOID20", "GEOID10", "geoid", "geoid20", "geoid10"]:
            if candidate in standardized.columns:
                rename_map[candidate] = "GEOID"
                break

    if "NAME" not in standardized.columns:
        for candidate in ["NAME20", "NAMELSAD20", "NAME10", "NAMELSAD10", "NAMELSAD", "name"]:
            if candidate in standardized.columns:
                rename_map[candidate] = "NAME"
                break

    if "TRACTCE" not in standardized.columns:
        for candidate in ["TRACTCE20", "TRACTCE10", "tractce20", "tractce10", "TRACTCE"]:
            if candidate in standardized.columns:
                rename_map[candidate] = "TRACTCE"
                break

    standardized = standardized.rename(columns=rename_map)

    if "GEOID" not in standardized.columns and all(col in standardized.columns for col in ["STATEFP", "COUNTYFP", "TRACTCE"]):
        standardized["GEOID"] = (
            standardized["STATEFP"].astype(str).str.zfill(2)
            + standardized["COUNTYFP"].astype(str).str.zfill(3)
            + standardized["TRACTCE"].astype(str).str.zfill(6)
        )

    if "NAME" not in standardized.columns:
        if "TRACTCE" in standardized.columns:
            standardized["NAME"] = "Census Tract " + standardized["TRACTCE"].astype(str)
        elif "GEOID" in standardized.columns:
            standardized["NAME"] = "Census Tract " + standardized["GEOID"].astype(str).str[-6:]

    if "GEOID" in standardized.columns:
        standardized["GEOID"] = standardized["GEOID"].astype(str)
    if "NAME" in standardized.columns:
        standardized["NAME"] = standardized["NAME"].astype(str)

    return standardized


def is_valid_cached_geojson(path: Path) -> bool:
    if not path.exists() or path.stat().st_size == 0:
        return False
    try:
        gdf = gpd.read_file(path)
        return not gdf.empty and gdf.geometry.notna().any()
    except Exception:
        return False


def download_baltimore_city_tract_geojson(config: ProjectConfig) -> Optional[Path]:
    cache_dir = get_cache_dir(config)
    out_path = cache_dir / "baltimore_city_tracts_official.geojson"
    try:
        city_query_url = build_arcgis_query_url(OFFICIAL_BALTIMORE_CITY_TRACTS_LAYER)
        out_path.write_bytes(_download_bytes(city_query_url, timeout=config.route_request_timeout_sec))
        downloaded = gpd.read_file(out_path)
        downloaded = standardize_real_tract_fields(downloaded)
        if downloaded.empty:
            raise ValueError("Baltimore City official tract layer returned no features.")
        downloaded.to_file(out_path, driver="GeoJSON")
        return out_path
    except Exception as exc:
        logger.warning("Official Baltimore City tract layer download failed: %s", exc)
        return None


def download_baltimore_city_tracts_from_tiger(config: ProjectConfig) -> Optional[Path]:
    cache_dir = get_cache_dir(config)
    zip_path = cache_dir / "tl_2024_24_tract.zip"
    geojson_path = cache_dir / "baltimore_city_tracts_from_tiger.geojson"
    try:
        zip_path.write_bytes(_download_bytes(OFFICIAL_CENSUS_MD_TRACTS_ZIP, timeout=config.route_request_timeout_sec))
        md_tracts = gpd.read_file(f"zip://{zip_path}")
        md_tracts = standardize_real_tract_fields(md_tracts)

        if "COUNTYFP" in md_tracts.columns:
            city_tracts = md_tracts[md_tracts["COUNTYFP"].astype(str).str.zfill(3) == config.census_baltimore_city_countyfp].copy()
        elif "GEOID" in md_tracts.columns:
            city_tracts = md_tracts[md_tracts["GEOID"].astype(str).str.startswith("24510")].copy()
        else:
            raise ValueError("Downloaded TIGER tract file but could not identify Baltimore City tracts.")

        if city_tracts.empty:
            raise ValueError("Downloaded TIGER tract file but isolated zero Baltimore City tracts.")

        city_tracts = standardize_real_tract_fields(city_tracts)
        if city_tracts.crs is None:
            city_tracts = city_tracts.set_crs(config.input_crs)
        elif city_tracts.crs.to_string() != config.input_crs:
            city_tracts = city_tracts.to_crs(config.input_crs)
        city_tracts.to_file(geojson_path, driver="GeoJSON")
        return geojson_path
    except Exception as exc:
        logger.warning("Official Census TIGER tract download failed: %s", exc)
        return None


def auto_download_real_tract_path(config: ProjectConfig) -> Optional[str]:
    if not config.auto_download_real_tracts:
        return None

    cache_dir = get_cache_dir(config)
    city_geojson = cache_dir / "baltimore_city_tracts_official.geojson"

    if is_valid_cached_geojson(city_geojson):
        logger.info("Using cached official Baltimore City tract file: %s", city_geojson)
        return str(city_geojson)

    for candidate in (
        download_baltimore_city_tract_geojson(config),
        download_baltimore_city_tracts_from_tiger(config),
    ):
        if candidate is not None and candidate.exists():
            logger.info("Using auto-downloaded official tract data from %s", candidate)
            return str(candidate)
    return None


def _next_weekday_datetime(hour: int, minute: int, timezone_name: str) -> datetime:
    tz = ZoneInfo(timezone_name)
    now = datetime.now(tz)
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    while candidate.weekday() >= 5 or candidate <= now:
        candidate += timedelta(days=1)
        candidate = candidate.replace(hour=hour, minute=minute, second=0, microsecond=0)
    return candidate


def parse_duration_seconds(duration_text: str | None) -> Optional[float]:
    if not duration_text:
        return None
    if duration_text.endswith("s"):
        try:
            return float(duration_text[:-1])
        except ValueError:
            return None
    return None


def load_route_api_cache(config: ProjectConfig) -> dict[str, dict[str, float]]:
    cache_dir = ensure_directory(Path(config.auto_download_cache_dir))
    cache_path = cache_dir / config.route_api_cache_filename
    if not cache_path.exists():
        return {}
    try:
        return json.loads(cache_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_route_api_cache(config: ProjectConfig, cache: dict[str, dict[str, float]]) -> None:
    cache_dir = ensure_directory(Path(config.auto_download_cache_dir))
    cache_path = cache_dir / config.route_api_cache_filename
    cache_path.write_text(json.dumps(cache, indent=2), encoding="utf-8")


def call_google_route_matrix_single(
    origin_lat: float,
    origin_lon: float,
    dest_lat: float,
    dest_lon: float,
    travel_mode: str,
    config: ProjectConfig,
    departure_time: Optional[datetime] = None,
    traffic_aware: bool = False,
) -> Optional[dict[str, float]]:
    if not config.google_routes_api_key:
        return None

    body: dict[str, Any] = {
        "origins": [{"waypoint": {"location": {"latLng": {"latitude": origin_lat, "longitude": origin_lon}}}}],
        "destinations": [{"waypoint": {"location": {"latLng": {"latitude": dest_lat, "longitude": dest_lon}}}}],
        "travelMode": travel_mode,
    }
    if departure_time is not None:
        body["departureTime"] = departure_time.isoformat()
    if travel_mode == "DRIVE" and traffic_aware:
        body["routingPreference"] = "TRAFFIC_AWARE"

    request = urllib.request.Request(
        config.google_routes_matrix_url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "X-Goog-Api-Key": config.google_routes_api_key,
            "X-Goog-FieldMask": config.google_routes_field_mask,
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=config.route_request_timeout_sec) as response:
            raw = response.read().decode("utf-8").strip()
    except urllib.error.HTTPError as exc:
        logger.warning("Google Routes API request failed (%s): %s", exc.code, exc.reason)
        return None
    except Exception as exc:
        logger.warning("Google Routes API request failed: %s", exc)
        return None

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        lines = [line.strip() for line in raw.splitlines() if line.strip()]
        payload = [json.loads(line) for line in lines] if lines else []

    if isinstance(payload, dict):
        payload = [payload]
    if not payload:
        return None

    element = payload[0]
    distance_m = element.get("distanceMeters")
    duration_s = parse_duration_seconds(element.get("duration"))
    static_duration_s = parse_duration_seconds(element.get("staticDuration"))
    if distance_m is None or duration_s is None:
        return None
    return {
        "distance_m": float(distance_m),
        "duration_min": float(duration_s) / 60.0,
        "static_duration_min": float(static_duration_s) / 60.0 if static_duration_s is not None else float(duration_s) / 60.0,
    }


# =========================================================
# FILE DISCOVERY / INPUT PREP
# =========================================================


def resolve_tract_path(config: ProjectConfig) -> Optional[str]:
    """Search likely folders for a Baltimore-area tract file."""
    banned_terms = {"maricopa", "arizona", "phoenix"}
    search_roots = [Path(root) for root in (*config.search_roots, str(Path.cwd()), str(Path(__file__).resolve().parent))]

    def score_path(path: Path) -> int:
        path_text = str(path).lower()
        name_text = path.name.lower()
        parent_text = str(path.parent).lower()

        if any(term in path_text for term in banned_terms):
            return -10_000

        score = 0
        if "baltimore" in path_text:
            score += 50
        if "county" in path_text or "city" in path_text:
            score += 20
        if "tract" in name_text:
            score += 15

        for keyword in config.search_keywords:
            if keyword in name_text:
                score += 12
            if keyword in parent_text:
                score += 8
            if keyword in path_text:
                score += 5

        if path.suffix.lower() == ".shp":
            score += 5
        elif path.suffix.lower() in {".geojson", ".gpkg"}:
            score += 3
        return score

    candidates: list[tuple[int, Path]] = []

    def walk_directory(root: Path, depth: int = 0) -> None:
        if depth > config.max_search_depth or not root.exists() or not root.is_dir():
            return
        try:
            for entry in root.iterdir():
                try:
                    if entry.is_file() and entry.suffix.lower() in config.allowed_extensions:
                        score = score_path(entry)
                        if score > 0:
                            candidates.append((score, entry))
                    elif entry.is_dir():
                        walk_directory(entry, depth + 1)
                except (PermissionError, OSError):
                    continue
        except (PermissionError, OSError):
            return

    for root in search_roots:
        walk_directory(root)

    if not candidates:
        return None

    baltimore_candidates = [item for item in candidates if "baltimore" in str(item[1]).lower()]
    if baltimore_candidates:
        baltimore_candidates.sort(key=lambda item: item[0], reverse=True)
        best_score, best_path = baltimore_candidates[0]
        logger.info("Resolved Baltimore tract path: %s (score=%s)", best_path, best_score)
        return str(best_path)

    if config.use_synthetic_backup:
        logger.warning(
            "Found tract files, but none appear to be Baltimore-area. "
            "Falling back to synthetic backup data."
        )
        return None

    candidates.sort(key=lambda item: item[0], reverse=True)
    best_score, best_path = candidates[0]
    logger.warning("Resolved non-Baltimore tract path: %s (score=%s)", best_path, best_score)
    return str(best_path)


# =========================================================
# SYNTHETIC BACKUP DATA
# =========================================================


def make_synthetic_baltimore_county_mask() -> Polygon:
    base = Polygon([
        (0, 0), (10, 0), (11, 2), (12, 4), (12, 6), (11, 8), (10, 10),
        (8, 11), (6, 11.5), (4, 11), (2.5, 10), (1, 8.5), (0.3, 6.5),
        (-0.2, 4.5), (0, 2),
    ])
    notch1 = Point(1.0, 10.5).buffer(1.2, resolution=32)
    notch2 = Point(11.0, 1.0).buffer(1.0, resolution=32)
    notch3 = Point(10.8, 8.8).buffer(0.9, resolution=32)
    return base.difference(notch1.union(notch2).union(notch3))



def generate_synthetic_tracts(projected_crs: str) -> gpd.GeoDataFrame:
    rows, cols, cell_size = 14, 14, 6000.0
    county_mask = make_synthetic_baltimore_county_mask()
    county_mask = Polygon([(x * cell_size, y * cell_size) for x, y in county_mask.exterior.coords])

    polygons: list[Polygon] = []
    geoids: list[str] = []
    counter = 1

    for row in range(rows):
        for col in range(cols):
            x0 = col * cell_size
            y0 = row * cell_size
            cell = Polygon([
                (x0, y0),
                (x0 + cell_size, y0),
                (x0 + cell_size, y0 + cell_size),
                (x0, y0 + cell_size),
            ])
            intersection = cell.intersection(county_mask)
            if intersection.is_empty or intersection.area < 0.20 * cell.area:
                continue
            polygons.append(intersection)
            geoids.append(f"BCO_{counter:03d}")
            counter += 1

    return gpd.GeoDataFrame({"GEOID": geoids, "geometry": polygons}, geometry="geometry", crs=projected_crs)



def generate_synthetic_high_schools(tracts_gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    bounds = tracts_gdf.total_bounds
    minx, miny, maxx, maxy = bounds
    points = [
        Point(minx + 0.18 * (maxx - minx), maxy - 0.08 * (maxy - miny)),
        Point(minx + 0.33 * (maxx - minx), maxy - 0.12 * (maxy - miny)),
        Point(minx + 0.48 * (maxx - minx), maxy - 0.10 * (maxy - miny)),
        Point(minx + 0.62 * (maxx - minx), maxy - 0.14 * (maxy - miny)),
        Point(minx + 0.78 * (maxx - minx), maxy - 0.18 * (maxy - miny)),
    ]
    return gpd.GeoDataFrame(
        {
            "rank": [1, 2, 3, 4, 5],
            "school_name": [f"Synthetic Top School {i}" for i in range(1, 6)],
            "address": ["synthetic backup"] * 5,
            "geometry": points,
        },
        geometry="geometry",
        crs=tracts_gdf.crs,
    )


# =========================================================
# TRACT LOADING AND CLEANING
# =========================================================


def load_tracts(path: str, input_crs: str) -> gpd.GeoDataFrame:
    gdf = gpd.read_file(path)
    if gdf.empty:
        raise ValueError("Input tract file is empty.")
    if gdf.crs is None:
        raise ValueError("Input tract file has no CRS.")
    if gdf.crs.to_string() != input_crs:
        gdf = gdf.to_crs(input_crs)
    return gdf



def validate_geometries(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    cleaned = gdf.copy()
    cleaned = cleaned[~cleaned.geometry.isna()]
    cleaned = cleaned[~cleaned.geometry.is_empty]

    invalid = ~cleaned.geometry.is_valid
    if invalid.any():
        cleaned.loc[invalid, "geometry"] = cleaned.loc[invalid, "geometry"].buffer(0)

    cleaned = cleaned[cleaned.geometry.is_valid]
    if cleaned.empty:
        raise ValueError("No valid tract geometries remain after cleaning.")
    return cleaned



def detect_id_column(gdf: gpd.GeoDataFrame, preferred: str) -> str:
    if preferred in gdf.columns:
        return preferred

    candidates = [
        "geoid", "GEOID10", "GEOID20", "TRACTCE", "tractce", "TRACT", "tract",
        "OBJECTID", "objectid", "NAME", "name",
    ]
    lower_lookup = {column.lower(): column for column in gdf.columns}

    for candidate in candidates:
        if candidate.lower() in lower_lookup:
            return lower_lookup[candidate.lower()]

    for column in gdf.columns:
        if column != gdf.geometry.name:
            return column

    raise ValueError("Could not detect a tract ID column.")



def add_polygon_labels(gdf: gpd.GeoDataFrame, id_col: str, output_col: str = "polygon_label") -> gpd.GeoDataFrame:
    name_candidates = ["NAME20", "NAMELSAD20", "NAME10", "NAMELSAD10", "NAME", "Name", "name", "TRACT_NAME", "tract_name", "LABEL", "label", "NAMELSAD", "namelsad"]
    labeled = gdf.copy()
    chosen_name_col = None

    for column in name_candidates:
        if column in labeled.columns:
            values = labeled[column].astype(str).str.strip().replace("nan", "")
            if (values != "").any():
                chosen_name_col = column
                break

    if chosen_name_col:
        labeled["tract_name"] = labeled[chosen_name_col].astype(str).str.strip()
    else:
        labeled["tract_name"] = "Tract " + labeled[id_col].astype(str)

    labeled["matrix_label"] = labeled["tract_name"].astype(str).str.strip() + " | " + labeled[id_col].astype(str)
    labeled[output_col] = labeled["matrix_label"]
    return labeled



def project_and_add_centroids(gdf: gpd.GeoDataFrame, projected_crs: str) -> gpd.GeoDataFrame:
    projected = gdf.to_crs(projected_crs).reset_index(drop=True).copy()
    projected["centroid"] = projected.geometry.centroid
    projected["centroid_x"] = projected["centroid"].x
    projected["centroid_y"] = projected["centroid"].y
    return projected


# =========================================================
# ADJACENCY NETWORK
# =========================================================


def get_adjacent_pairs(tracts_gdf: gpd.GeoDataFrame, id_col: str, require_shared_boundary: bool) -> pd.DataFrame:
    sindex = tracts_gdf.sindex
    geometries = tracts_gdf.geometry.to_numpy()
    tract_ids = tracts_gdf[id_col].astype(str).to_numpy()
    rows: list[dict[str, object]] = []

    for idx, geometry in enumerate(geometries):
        candidate_idxs = list(sindex.intersection(geometry.bounds))

        for other_idx in candidate_idxs:
            other_idx = int(other_idx)
            if idx >= other_idx:
                continue

            other = geometries[other_idx]
            if not geometry.touches(other):
                continue

            shared_boundary_length = geometry.boundary.intersection(other.boundary).length
            if require_shared_boundary and shared_boundary_length <= 0:
                continue

            rows.append(
                {
                    "i": idx,
                    "j": other_idx,
                    "tract_i": str(tract_ids[idx]),
                    "tract_j": str(tract_ids[other_idx]),
                    "shared_boundary_length_m": float(shared_boundary_length),
                }
            )

    return pd.DataFrame(rows)


def build_edge_network(
    tracts_gdf: gpd.GeoDataFrame,
    id_col: str,
    projected_crs: str,
    require_shared_boundary: bool,
    label_col: str = "polygon_label",
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame]:
    tracts = project_and_add_centroids(tracts_gdf, projected_crs)
    centroid_wgs84 = gpd.GeoSeries(tracts["centroid"], crs=projected_crs).to_crs("EPSG:4326")
    tracts["centroid_lon"] = centroid_wgs84.x
    tracts["centroid_lat"] = centroid_wgs84.y
    adjacency = get_adjacent_pairs(tracts, id_col=id_col, require_shared_boundary=require_shared_boundary)

    edge_rows: list[dict[str, object]] = []
    for _, pair in adjacency.iterrows():
        i, j = pair["i"], pair["j"]
        centroid_i = tracts.at[i, "centroid"]
        centroid_j = tracts.at[j, "centroid"]

        edge_rows.append(
            {
                "i": i,
                "j": j,
                "tract_i": str(pair["tract_i"]),
                "tract_j": str(pair["tract_j"]),
                "tract_i_label": str(tracts.at[i, label_col]),
                "tract_j_label": str(tracts.at[j, label_col]),
                "tract_i_matrix_label": str(tracts.at[i, "matrix_label"]) if "matrix_label" in tracts.columns else str(tracts.at[i, label_col]),
                "tract_j_matrix_label": str(tracts.at[j, "matrix_label"]) if "matrix_label" in tracts.columns else str(tracts.at[j, label_col]),
                "centroid_i": centroid_i,
                "centroid_j": centroid_j,
                "centroid_i_lon": float(tracts.at[i, "centroid_lon"]),
                "centroid_i_lat": float(tracts.at[i, "centroid_lat"]),
                "centroid_j_lon": float(tracts.at[j, "centroid_lon"]),
                "centroid_j_lat": float(tracts.at[j, "centroid_lat"]),
                "shared_boundary_length_m": float(pair["shared_boundary_length_m"]),
                "edge_length_m": float(centroid_i.distance(centroid_j)),
                "is_adjacent": True,
                "geometry": LineString([centroid_i, centroid_j]),
            }
        )

    edge_gdf = gpd.GeoDataFrame(edge_rows, geometry="geometry", crs=projected_crs)
    return tracts, edge_gdf

def build_binary_adjacency_matrix(
    nodes: list[str],
    edge_gdf: gpd.GeoDataFrame,
    node_label_mode: str = "id",
    invalid_value: float = INVALID_MATRIX_VALUE,
) -> pd.DataFrame:
    if node_label_mode == "matrix_label":
        left_col, right_col = "tract_i_matrix_label", "tract_j_matrix_label"
    elif node_label_mode == "label":
        left_col, right_col = "tract_i_label", "tract_j_label"
    else:
        left_col, right_col = "tract_i", "tract_j"

    matrix = pd.DataFrame(float(invalid_value), index=nodes, columns=nodes, dtype=float)

    for node in nodes:
        matrix.loc[node, node] = 0.0

    for _, row in edge_gdf.iterrows():
        matrix.loc[str(row[left_col]), str(row[right_col])] = 1.0
        matrix.loc[str(row[right_col]), str(row[left_col])] = 1.0

    return matrix

# =========================================================
# EDGE METRICS / MATRICES
# =========================================================
# EDGE METRICS / MATRICES
# =========================================================


def estimate_route(origin: Point, destination: Point, mode: Mode, config: ProjectConfig, time_window: Optional[str] = None) -> RouteResult:
    straight_line_m = float(origin.distance(destination))

    if mode == "walk":
        distance_m = straight_line_m * config.walk_distance_factor
        return RouteResult(
            distance_m=distance_m,
            travel_time_min=distance_m / config.walk_speed_m_per_min,
            mode="walk",
            time_window=time_window,
            source="fallback_planar_walk",
        )

    if mode == "drive":
        distance_m = straight_line_m * config.drive_distance_factor
        speed = config.drive_speeds_m_per_min.get(time_window or "OFFPEAK", config.drive_speeds_m_per_min["OFFPEAK"])
        return RouteResult(
            distance_m=distance_m,
            travel_time_min=distance_m / speed,
            mode="drive",
            time_window=time_window,
            source="fallback_planar_drive",
        )

    raise ValueError(f"Unsupported mode: {mode}")



def calculate_pair_metrics(edge_gdf: gpd.GeoDataFrame, config: ProjectConfig) -> gpd.GeoDataFrame:
    metrics = edge_gdf.copy()
    if metrics.empty:
        return metrics

    use_live_api = bool(config.use_live_traffic_api and config.google_routes_api_key)
    cache = load_route_api_cache(config) if use_live_api else {}
    am_departure = _next_weekday_datetime(7, 30, config.traffic_timezone)
    pm_departure = _next_weekday_datetime(15, 30, config.traffic_timezone)

    walk_distance_m: list[float] = []
    walk_time_min: list[float] = []
    walk_distance_type: list[str] = []
    drive_distance_m: list[float] = []
    drive_distance_type: list[str] = []
    drive_time_offpeak: list[float] = []
    drive_time_am: list[float] = []
    drive_time_pm: list[float] = []

    for _, row in metrics.iterrows():
        tract_pair = f"{row['tract_i']}|{row['tract_j']}"
        walk_key = f"WALK|STATIC|{tract_pair}"
        drive_am_key = f"DRIVE|AM|{tract_pair}"
        drive_pm_key = f"DRIVE|PM|{tract_pair}"

        walk_result = None
        drive_am_result = None
        drive_pm_result = None

        if use_live_api:
            walk_result = cache.get(walk_key)
            if walk_result is None:
                walk_result = call_google_route_matrix_single(
                    origin_lat=float(row['centroid_i_lat']),
                    origin_lon=float(row['centroid_i_lon']),
                    dest_lat=float(row['centroid_j_lat']),
                    dest_lon=float(row['centroid_j_lon']),
                    travel_mode='WALK',
                    config=config,
                )
                if walk_result is not None:
                    cache[walk_key] = walk_result

            drive_am_result = cache.get(drive_am_key)
            if drive_am_result is None:
                drive_am_result = call_google_route_matrix_single(
                    origin_lat=float(row['centroid_i_lat']),
                    origin_lon=float(row['centroid_i_lon']),
                    dest_lat=float(row['centroid_j_lat']),
                    dest_lon=float(row['centroid_j_lon']),
                    travel_mode='DRIVE',
                    config=config,
                    departure_time=am_departure,
                    traffic_aware=True,
                )
                if drive_am_result is not None:
                    cache[drive_am_key] = drive_am_result

            drive_pm_result = cache.get(drive_pm_key)
            if drive_pm_result is None:
                drive_pm_result = call_google_route_matrix_single(
                    origin_lat=float(row['centroid_i_lat']),
                    origin_lon=float(row['centroid_i_lon']),
                    dest_lat=float(row['centroid_j_lat']),
                    dest_lon=float(row['centroid_j_lon']),
                    travel_mode='DRIVE',
                    config=config,
                    departure_time=pm_departure,
                    traffic_aware=True,
                )
                if drive_pm_result is not None:
                    cache[drive_pm_key] = drive_pm_result

        if walk_result is None:
            fallback_walk = estimate_route(row['centroid_i'], row['centroid_j'], 'walk', config)
            walk_result = {
                'distance_m': fallback_walk.distance_m,
                'duration_min': fallback_walk.travel_time_min,
                'static_duration_min': fallback_walk.travel_time_min,
            }
            walk_source = fallback_walk.source
        else:
            walk_source = 'google_routes_walk'

        if drive_am_result is None:
            fallback_drive_offpeak = estimate_route(row['centroid_i'], row['centroid_j'], 'drive', config, 'OFFPEAK')
            fallback_drive_am = estimate_route(row['centroid_i'], row['centroid_j'], 'drive', config, 'AM_PEAK_7_8')
            drive_am_result = {
                'distance_m': fallback_drive_am.distance_m,
                'duration_min': fallback_drive_am.travel_time_min,
                'static_duration_min': fallback_drive_offpeak.travel_time_min,
            }
            drive_source = fallback_drive_am.source
        else:
            drive_source = 'google_routes_drive_traffic'

        if drive_pm_result is None:
            fallback_drive_pm = estimate_route(row['centroid_i'], row['centroid_j'], 'drive', config, 'PM_PEAK_3_4')
            fallback_offpeak = estimate_route(row['centroid_i'], row['centroid_j'], 'drive', config, 'OFFPEAK')
            drive_pm_result = {
                'distance_m': fallback_drive_pm.distance_m,
                'duration_min': fallback_drive_pm.travel_time_min,
                'static_duration_min': fallback_offpeak.travel_time_min,
            }

        walk_distance_m.append(float(walk_result['distance_m']))
        walk_time_min.append(float(walk_result['duration_min']))
        walk_distance_type.append(walk_source)
        drive_distance_m.append(float(drive_am_result['distance_m']))
        drive_distance_type.append(drive_source)
        drive_time_offpeak.append(float(drive_am_result.get('static_duration_min', drive_am_result['duration_min'])))
        drive_time_am.append(float(drive_am_result['duration_min']))
        drive_time_pm.append(float(drive_pm_result['duration_min']))

    if use_live_api:
        save_route_api_cache(config, cache)

    metrics['walk_distance_m'] = walk_distance_m
    metrics['walk_time_min'] = walk_time_min
    metrics['walk_distance_type'] = walk_distance_type
    metrics['walk_distance_miles'] = metrics['walk_distance_m'].apply(meters_to_miles)

    metrics['drive_distance_m'] = drive_distance_m
    metrics['drive_distance_type'] = drive_distance_type
    metrics['drive_distance_miles'] = metrics['drive_distance_m'].apply(meters_to_miles)
    metrics['drive_time_min_offpeak'] = drive_time_offpeak
    metrics['drive_time_min_am_peak_7_8'] = drive_time_am
    metrics['drive_time_min_pm_peak_3_4'] = drive_time_pm

    return metrics



def get_matrix_nodes(tract_nodes: gpd.GeoDataFrame, id_col: str, node_label_mode: str = "id") -> list[str]:
    if node_label_mode == "matrix_label":
        return sorted(tract_nodes["matrix_label"].astype(str).tolist())
    if node_label_mode == "label":
        return sorted(tract_nodes["polygon_label"].astype(str).tolist())
    return sorted(tract_nodes[id_col].astype(str).tolist())


def build_metric_matrix_from_edges(
    nodes: list[str],
    edge_gdf: gpd.GeoDataFrame,
    weight_col: str,
    node_label_mode: str = "id",
    invalid_value: float = INVALID_MATRIX_VALUE,
) -> pd.DataFrame:
    if node_label_mode == "matrix_label":
        left_col, right_col = ("tract_i_matrix_label", "tract_j_matrix_label")
    elif node_label_mode == "label":
        left_col, right_col = ("tract_i_label", "tract_j_label")
    else:
        left_col, right_col = ("tract_i", "tract_j")
    matrix = pd.DataFrame(float(invalid_value), index=nodes, columns=nodes, dtype=float)

    for node in nodes:
        matrix.loc[node, node] = 0.0

    for _, row in edge_gdf.iterrows():
        value = float(row[weight_col])
        matrix.loc[str(row[left_col]), str(row[right_col])] = value
        matrix.loc[str(row[right_col]), str(row[left_col])] = value

    return matrix


def build_graph_from_edges(edge_gdf: gpd.GeoDataFrame, weight_col: str, nodes: Optional[list[str]] = None) -> nx.Graph:
    graph = nx.Graph()
    if nodes is not None:
        graph.add_nodes_from(str(node) for node in nodes)
    for _, row in edge_gdf.iterrows():
        graph.add_edge(str(row["tract_i"]), str(row["tract_j"]), weight=float(row[weight_col]))
    return graph


def build_all_pairs_shortest_path_matrix(
    edge_gdf: gpd.GeoDataFrame,
    weight_col: str,
    nodes: Optional[list[str]] = None,
    invalid_value: float = np.inf,
) -> pd.DataFrame:
    graph = build_graph_from_edges(edge_gdf, weight_col, nodes=nodes)
    node_list = sorted(str(node) for node in (nodes if nodes is not None else list(graph.nodes())))
    matrix = pd.DataFrame(float(invalid_value), index=node_list, columns=node_list, dtype=float)

    for node in node_list:
        matrix.loc[node, node] = 0.0

    for source, lengths in nx.all_pairs_dijkstra_path_length(graph, weight="weight"):
        for target, value in lengths.items():
            matrix.loc[str(source), str(target)] = float(value)
    return matrix


# =========================================================
# NEIGHBOR LOOKUP / QUERY HELPERS

# =========================================================
# NEIGHBOR LOOKUP / QUERY HELPERS
# =========================================================


def _normalize_pair(tract_a: str, tract_b: str) -> tuple[str, str]:
    return tuple(sorted((str(tract_a), str(tract_b))))



def build_neighbor_lookup(edge_gdf: gpd.GeoDataFrame) -> dict[tuple[str, str], pd.Series]:
    return {_normalize_pair(row["tract_i"], row["tract_j"]): row for _, row in edge_gdf.iterrows()}



def get_direct_neighbor_metrics(edge_gdf: gpd.GeoDataFrame, tract_a: str, tract_b: str) -> dict[str, object]:
    lookup = build_neighbor_lookup(edge_gdf)
    pair = _normalize_pair(tract_a, tract_b)

    if pair not in lookup:
        return {
            "tract_a": str(tract_a),
            "tract_b": str(tract_b),
            "status": INVALID_STATUS,
            "message": "These tracts do not share a boundary, so no direct tract-to-tract distance is reported.",
        }

    row = lookup[pair]
    return {
        "tract_a": str(tract_a),
        "tract_b": str(tract_b),
        "status": "VALID_NEIGHBOR_PAIR",
        "tract_i": str(row["tract_i"]),
        "tract_j": str(row["tract_j"]),
        "tract_i_label": str(row["tract_i_label"]),
        "tract_j_label": str(row["tract_j_label"]),
        "walk_distance_m": float(row["walk_distance_m"]),
        "walk_distance_miles": float(row["walk_distance_miles"]),
        "walk_time_min": float(row["walk_time_min"]),
        "drive_distance_m": float(row["drive_distance_m"]),
        "drive_distance_miles": float(row["drive_distance_miles"]),
        "drive_time_min_offpeak": float(row["drive_time_min_offpeak"]),
        "drive_time_min_am_peak_7_8": float(row["drive_time_min_am_peak_7_8"]),
        "drive_time_min_pm_peak_3_4": float(row["drive_time_min_pm_peak_3_4"]),
        "shared_boundary_length_m": float(row["shared_boundary_length_m"]),
    }



def build_query_results_table(edge_gdf: gpd.GeoDataFrame, query_pairs: list[tuple[str, str]]) -> pd.DataFrame:
    return pd.DataFrame([get_direct_neighbor_metrics(edge_gdf, tract_a, tract_b) for tract_a, tract_b in query_pairs])



def build_neighbor_distance_table(edge_gdf: gpd.GeoDataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for _, row in edge_gdf.iterrows():
        shared = {
            "walk_distance_m": float(row["walk_distance_m"]),
            "walk_distance_miles": float(row["walk_distance_miles"]),
            "walk_time_min": float(row["walk_time_min"]),
            "drive_distance_m": float(row["drive_distance_m"]),
            "drive_distance_miles": float(row["drive_distance_miles"]),
            "drive_time_min_offpeak": float(row["drive_time_min_offpeak"]),
            "drive_time_min_am_peak_7_8": float(row["drive_time_min_am_peak_7_8"]),
            "drive_time_min_pm_peak_3_4": float(row["drive_time_min_pm_peak_3_4"]),
            "edge_length_m": float(row["edge_length_m"]),
            "shared_boundary_length_m": float(row["shared_boundary_length_m"]),
            "status": "VALID_NEIGHBOR_PAIR",
        }
        rows.extend([
            {
                "tract_id": str(row["tract_i"]),
                "tract_label": str(row["tract_i_label"]),
                "neighbor_tract_id": str(row["tract_j"]),
                "neighbor_tract_label": str(row["tract_j_label"]),
                **shared,
            },
            {
                "tract_id": str(row["tract_j"]),
                "tract_label": str(row["tract_j_label"]),
                "neighbor_tract_id": str(row["tract_i"]),
                "neighbor_tract_label": str(row["tract_i_label"]),
                **shared,
            },
        ])

    if not rows:
        return pd.DataFrame(
            columns=[
                "tract_id",
                "tract_label",
                "neighbor_tract_id",
                "neighbor_tract_label",
                "walk_distance_m",
                "walk_distance_miles",
                "walk_time_min",
                "drive_distance_m",
                "drive_distance_miles",
                "drive_time_min_offpeak",
                "drive_time_min_am_peak_7_8",
                "drive_time_min_pm_peak_3_4",
                "edge_length_m",
                "shared_boundary_length_m",
                "status",
            ]
        )

    return pd.DataFrame(rows).sort_values(["tract_label", "neighbor_tract_label"]).reset_index(drop=True)



def build_output_tables(tract_nodes: gpd.GeoDataFrame, edge_gdf: gpd.GeoDataFrame, id_col: str) -> dict[str, pd.DataFrame]:
    tract_id_nodes = get_matrix_nodes(tract_nodes, id_col=id_col, node_label_mode="id")
    tract_matrix_label_nodes = get_matrix_nodes(tract_nodes, id_col=id_col, node_label_mode="matrix_label")

    return {
        "adjacency_matrix": build_binary_adjacency_matrix(tract_id_nodes, edge_gdf, node_label_mode="id"),
        "neighbor_table": build_neighbor_distance_table(edge_gdf),
        "walk_distance_matrix": build_metric_matrix_from_edges(tract_matrix_label_nodes, edge_gdf, "walk_distance_m", node_label_mode="matrix_label"),
        "walk_time_matrix": build_metric_matrix_from_edges(tract_matrix_label_nodes, edge_gdf, "walk_time_min", node_label_mode="matrix_label"),
        "drive_distance_matrix": build_metric_matrix_from_edges(tract_matrix_label_nodes, edge_gdf, "drive_distance_m", node_label_mode="matrix_label"),
        "drive_time_offpeak_matrix": build_metric_matrix_from_edges(tract_matrix_label_nodes, edge_gdf, "drive_time_min_offpeak", node_label_mode="matrix_label"),
        "drive_time_am_matrix": build_metric_matrix_from_edges(tract_matrix_label_nodes, edge_gdf, "drive_time_min_am_peak_7_8", node_label_mode="matrix_label"),
        "drive_time_pm_matrix": build_metric_matrix_from_edges(tract_matrix_label_nodes, edge_gdf, "drive_time_min_pm_peak_3_4", node_label_mode="matrix_label"),
        "walk_distance_matrix_by_id": build_metric_matrix_from_edges(tract_id_nodes, edge_gdf, "walk_distance_m", node_label_mode="id"),
        "walk_time_matrix_by_id": build_metric_matrix_from_edges(tract_id_nodes, edge_gdf, "walk_time_min", node_label_mode="id"),
        "drive_distance_matrix_by_id": build_metric_matrix_from_edges(tract_id_nodes, edge_gdf, "drive_distance_m", node_label_mode="id"),
        "drive_time_offpeak_matrix_by_id": build_metric_matrix_from_edges(tract_id_nodes, edge_gdf, "drive_time_min_offpeak", node_label_mode="id"),
        "drive_time_am_matrix_by_id": build_metric_matrix_from_edges(tract_id_nodes, edge_gdf, "drive_time_min_am_peak_7_8", node_label_mode="id"),
        "drive_time_pm_matrix_by_id": build_metric_matrix_from_edges(tract_id_nodes, edge_gdf, "drive_time_min_pm_peak_3_4", node_label_mode="id"),
        "all_pairs_walk_time_matrix": build_all_pairs_shortest_path_matrix(edge_gdf, "walk_time_min", nodes=tract_id_nodes),
        "all_pairs_drive_time_am_matrix": build_all_pairs_shortest_path_matrix(edge_gdf, "drive_time_min_am_peak_7_8", nodes=tract_id_nodes),
        "all_pairs_drive_time_pm_matrix": build_all_pairs_shortest_path_matrix(edge_gdf, "drive_time_min_pm_peak_3_4", nodes=tract_id_nodes),
    }



def build_tract_lookup_table(tract_nodes: gpd.GeoDataFrame, id_col: str) -> pd.DataFrame:
    lookup = tract_nodes.copy()
    area_series = lookup.geometry.area if lookup.crs is not None and getattr(lookup.crs, "is_projected", False) else pd.Series([np.nan] * len(lookup), index=lookup.index)

    rows: list[dict[str, Any]] = []
    for idx, row in lookup.iterrows():
        centroid_lon = row.get("centroid_lon", np.nan)
        centroid_lat = row.get("centroid_lat", np.nan)
        rows.append({
            "GEOID": str(row[id_col]),
            "tract_name": str(row.get("tract_name", f"Tract {row[id_col]}")),
            "matrix_label": str(row.get("matrix_label", f"Tract {row[id_col]} | {row[id_col]}")),
            "polygon_label": str(row.get("polygon_label", row.get("matrix_label", row[id_col]))),
            "centroid_lon": float(centroid_lon) if not pd.isna(centroid_lon) else np.nan,
            "centroid_lat": float(centroid_lat) if not pd.isna(centroid_lat) else np.nan,
            "area_m2": float(area_series.loc[idx]) if idx in area_series.index and not pd.isna(area_series.loc[idx]) else np.nan,
        })

    return pd.DataFrame(rows).sort_values(["tract_name", "GEOID"]).reset_index(drop=True)


def export_core_outputs(outputs: dict[str, pd.DataFrame], files: OutputFiles) -> None:
    safe_to_csv(outputs["adjacency_matrix"], files.adjacency_matrix_csv)
    safe_to_csv(outputs["neighbor_table"], files.neighbor_csv, index=False)
    safe_to_csv(outputs["walk_distance_matrix"], files.walk_distance_matrix_csv)
    safe_to_csv(outputs["walk_time_matrix"], files.walk_time_matrix_csv)
    safe_to_csv(outputs["drive_distance_matrix"], files.drive_distance_matrix_csv)
    safe_to_csv(outputs["drive_time_offpeak_matrix"], files.drive_time_offpeak_matrix_csv)
    safe_to_csv(outputs["drive_time_am_matrix"], files.drive_time_am_matrix_csv)
    safe_to_csv(outputs["drive_time_pm_matrix"], files.drive_time_pm_matrix_csv)
    safe_to_csv(outputs["walk_distance_matrix_by_id"], files.walk_distance_matrix_by_id_csv)
    safe_to_csv(outputs["walk_time_matrix_by_id"], files.walk_time_matrix_by_id_csv)
    safe_to_csv(outputs["drive_distance_matrix_by_id"], files.drive_distance_matrix_by_id_csv)
    safe_to_csv(outputs["drive_time_offpeak_matrix_by_id"], files.drive_time_offpeak_matrix_by_id_csv)
    safe_to_csv(outputs["drive_time_am_matrix_by_id"], files.drive_time_am_matrix_by_id_csv)
    safe_to_csv(outputs["drive_time_pm_matrix_by_id"], files.drive_time_pm_matrix_by_id_csv)



# =========================================================
# SCHOOL ROUTES
# =========================================================


def build_school_points(real_data: bool, tracts_gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    if not real_data:
        return generate_synthetic_high_schools(tracts_gdf)

    school_df = pd.DataFrame(TOP_5_HIGH_SCHOOLS)
    schools = gpd.GeoDataFrame(
        school_df,
        geometry=gpd.points_from_xy(school_df["lon"], school_df["lat"]),
        crs="EPSG:4326",
    )
    return schools.to_crs(tracts_gdf.crs)



def assign_schools_to_origin_tracts(schools_gdf: gpd.GeoDataFrame, tracts_gdf: gpd.GeoDataFrame, id_col: str) -> gpd.GeoDataFrame:
    joined = gpd.sjoin(
        schools_gdf,
        tracts_gdf[[id_col, "geometry"]],
        how="left",
        predicate="within",
    ).drop(columns=["index_right"], errors="ignore")

    missing = joined[id_col].isna()
    if missing.any():
        tract_centroids = tracts_gdf.copy()
        tract_centroids["geometry"] = tract_centroids.geometry.centroid
        nearest = gpd.sjoin_nearest(
            joined.loc[missing, ["rank", "school_name", "address", "geometry"]],
            tract_centroids[[id_col, "geometry"]],
            how="left",
            distance_col="nearest_tract_dist_m",
        ).drop(columns=["index_right"], errors="ignore")
        joined.loc[missing, id_col] = nearest[id_col].values

    return joined.rename(columns={id_col: "origin_tract_id"})



def get_downtown_target_tract(tracts_gdf: gpd.GeoDataFrame, id_col: str) -> str:
    downtown = gpd.GeoDataFrame(
        {"name": ["Downtown Baltimore"]},
        geometry=[Point(DOWNTOWN_BALTIMORE_LON, DOWNTOWN_BALTIMORE_LAT)],
        crs="EPSG:4326",
    ).to_crs(tracts_gdf.crs)

    centroids = tracts_gdf.copy()
    centroids["geometry"] = centroids.geometry.centroid
    nearest = gpd.sjoin_nearest(
        downtown,
        centroids[[id_col, "geometry"]],
        how="left",
        distance_col="dist_to_downtown_m",
    ).drop(columns=["index_right"], errors="ignore")
    return str(nearest.iloc[0][id_col])



def shortest_path_tracts(edge_gdf: gpd.GeoDataFrame, start_tract: str, end_tract: str, weight_col: str) -> tuple[list[str], gpd.GeoDataFrame, float]:
    graph = nx.Graph()
    for _, row in edge_gdf.iterrows():
        graph.add_edge(
            str(row["tract_i"]),
            str(row["tract_j"]),
            weight=float(row[weight_col]),
        )

    path_nodes = nx.shortest_path(graph, source=str(start_tract), target=str(end_tract), weight="weight")
    total_cost = nx.shortest_path_length(graph, source=str(start_tract), target=str(end_tract), weight="weight")

    lookup = build_neighbor_lookup(edge_gdf)
    path_rows = []
    for left, right in zip(path_nodes[:-1], path_nodes[1:]):
        pair = _normalize_pair(left, right)
        if pair in lookup:
            path_rows.append(lookup[pair])

    route_edges = gpd.GeoDataFrame(path_rows, geometry="geometry", crs=edge_gdf.crs)
    return path_nodes, route_edges, float(total_cost)



def summarize_route_distances(path_edges: gpd.GeoDataFrame) -> dict[str, object]:
    if path_edges.empty:
        return {"total_walk_m": 0.0, "total_drive_m": 0.0, "path_edge_rows": pd.DataFrame()}

    return {
        "total_walk_m": float(path_edges["walk_distance_m"].sum()),
        "total_drive_m": float(path_edges["drive_distance_m"].sum()),
        "path_edge_rows": path_edges.copy(),
    }



def plot_school_routes(
    tracts_gdf: gpd.GeoDataFrame,
    edge_gdf: gpd.GeoDataFrame,
    school_routes: pd.DataFrame,
    schools_with_origins: gpd.GeoDataFrame,
    downtown_target_tract: str,
    id_col: str,
    output_path: str,
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(18, 9))
    county_ax, zoom_ax = axes

    for axis in axes:
        tracts_gdf.plot(ax=axis, facecolor="#e0e0e0", edgecolor="black", linewidth=0.4, alpha=0.8)

    edge_gdf.plot(ax=county_ax, color="#aaaaaa", linewidth=0.5, alpha=0.25)
    edge_gdf.plot(ax=zoom_ax, color="#cccccc", linewidth=0.4, alpha=0.18)

    colors = ["red", "blue", "green", "purple", "orange"]
    for idx, (_, route_row) in enumerate(school_routes.iterrows()):
        route_edges = route_row.get("route_edges_gdf")
        if route_edges is None or len(route_edges) == 0:
            continue
        color = colors[idx % len(colors)]
        route_edges.plot(ax=county_ax, color=color, linewidth=2.8, alpha=0.95)
        route_edges.plot(ax=zoom_ax, color=color, linewidth=3.4, alpha=0.95)

    schools_with_origins.plot(ax=county_ax, color="gold", edgecolor="black", markersize=90, marker="^")
    schools_with_origins.plot(ax=zoom_ax, color="gold", edgecolor="black", markersize=110, marker="^")

    for _, school in schools_with_origins.iterrows():
        x, y = school.geometry.x, school.geometry.y
        label = f"{int(school['rank'])}. {school['school_name']}"
        county_ax.text(x, y, label, fontsize=7, ha="left", va="bottom")
        zoom_ax.text(x, y, label, fontsize=8, ha="left", va="bottom")

    downtown_polygon = tracts_gdf[tracts_gdf[id_col].astype(str) == str(downtown_target_tract)]
    if not downtown_polygon.empty:
        downtown_polygon.plot(ax=county_ax, facecolor="cyan", edgecolor="black", alpha=0.55)
        downtown_polygon.plot(ax=zoom_ax, facecolor="cyan", edgecolor="black", alpha=0.65)
        centroid = downtown_polygon.geometry.centroid.iloc[0]
        county_ax.scatter(centroid.x, centroid.y, s=80, c="black")
        zoom_ax.scatter(centroid.x, centroid.y, s=95, c="black")

    centroid = tracts_gdf.geometry.centroid
    minx, miny, maxx, maxy = centroid.x.quantile(0.15), centroid.y.quantile(0.15), centroid.x.quantile(0.85), centroid.y.quantile(0.85)
    zoom_ax.set_xlim(minx, maxx)
    zoom_ax.set_ylim(miny, maxy)

    county_ax.set_title("Top Baltimore County high school routes to downtown\nCountywide view")
    zoom_ax.set_title("Top Baltimore County high school routes to downtown\nZoomed view")
    county_ax.set_axis_off()
    zoom_ax.set_axis_off()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)



def build_school_route_outputs(
    tracts_gdf: gpd.GeoDataFrame,
    edge_gdf: gpd.GeoDataFrame,
    id_col: str,
    using_synthetic: bool,
    files: OutputFiles,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    schools_gdf = build_school_points(real_data=not using_synthetic, tracts_gdf=tracts_gdf)
    schools_with_origins = assign_schools_to_origin_tracts(schools_gdf, tracts_gdf, id_col)
    downtown_target_tract = get_downtown_target_tract(tracts_gdf, id_col)

    route_summary_rows: list[dict[str, object]] = []
    route_edge_rows: list[pd.DataFrame] = []

    for _, school in schools_with_origins.sort_values("rank").iterrows():
        path_nodes, route_edges_gdf, _ = shortest_path_tracts(
            edge_gdf,
            start_tract=str(school["origin_tract_id"]),
            end_tract=downtown_target_tract,
            weight_col="drive_distance_m",
        )
        route_summary = summarize_route_distances(route_edges_gdf)

        route_summary_rows.append(
            {
                "rank": int(school["rank"]),
                "school_name": school["school_name"],
                "address": school["address"],
                "origin_tract_id": str(school["origin_tract_id"]),
                "destination_tract_id": downtown_target_tract,
                "num_tracts_in_path": len(path_nodes),
                "path_sequence": " -> ".join(path_nodes),
                "total_walk_m": route_summary["total_walk_m"],
                "total_walk_miles": meters_to_miles(route_summary["total_walk_m"]),
                "total_drive_m": route_summary["total_drive_m"],
                "total_drive_miles": meters_to_miles(route_summary["total_drive_m"]),
                "route_edges_gdf": route_edges_gdf,
            }
        )

        route_edges_export = route_summary["path_edge_rows"].copy()
        if not route_edges_export.empty:
            route_edges_export["school_rank"] = int(school["rank"])
            route_edges_export["school_name"] = school["school_name"]
            route_edges_export["destination_tract_id"] = downtown_target_tract
            route_edges_export["walk_distance_miles"] = route_edges_export["walk_distance_m"].apply(meters_to_miles)
            route_edges_export["drive_distance_miles"] = route_edges_export["drive_distance_m"].apply(meters_to_miles)
            route_edge_rows.append(route_edges_export)

    school_routes_df = pd.DataFrame(route_summary_rows)
    school_routes_df.drop(columns=["route_edges_gdf"], errors="ignore").to_csv(files.school_route_summary_csv, index=False)

    if route_edge_rows:
        pd.concat(route_edge_rows, ignore_index=True).to_csv(files.school_route_edges_csv, index=False)
    else:
        pd.DataFrame().to_csv(files.school_route_edges_csv, index=False)

    plot_school_routes(
        tracts_gdf=tracts_gdf,
        edge_gdf=edge_gdf,
        school_routes=school_routes_df,
        schools_with_origins=schools_with_origins,
        downtown_target_tract=downtown_target_tract,
        id_col=id_col,
        output_path=files.school_route_map_png,
    )
    return school_routes_df, schools_with_origins


# =========================================================
# VISUALIZATION HELPERS
# =========================================================


def matrix_to_numeric(matrix: pd.DataFrame) -> pd.DataFrame:
    numeric = matrix.replace(float(INVALID_MATRIX_VALUE), np.nan)
    return numeric.apply(pd.to_numeric, errors="coerce")



def plot_adjacency_map(tract_nodes: gpd.GeoDataFrame, edge_network: gpd.GeoDataFrame, output_path: str) -> None:
    fig, ax = plt.subplots(figsize=(11, 11))
    tract_nodes.plot(ax=ax, facecolor="#e8ecef", edgecolor="black", linewidth=0.4, alpha=0.9)
    edge_network.plot(ax=ax, color="#d1495b", linewidth=0.8, alpha=0.7)
    gpd.GeoDataFrame(geometry=tract_nodes["centroid"], crs=tract_nodes.crs).plot(ax=ax, color="#1f77b4", markersize=6, alpha=0.9)
    ax.set_title("Adjacent-Only Tract Network")
    ax.set_axis_off()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)



def plot_distance_heatmaps(walk_distance_matrix: pd.DataFrame, drive_distance_matrix: pd.DataFrame, output_path: str) -> None:
    walk_numeric = matrix_to_numeric(walk_distance_matrix)
    drive_numeric = matrix_to_numeric(drive_distance_matrix)

    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    walk_im = axes[0].imshow(walk_numeric.values, aspect="auto")
    drive_im = axes[1].imshow(drive_numeric.values, aspect="auto")

    axes[0].set_title("Adjacent-Only Walk Distance Matrix")
    axes[1].set_title("Adjacent-Only Drive Distance Matrix")
    for axis in axes:
        axis.set_xlabel("Tracts")
        axis.set_ylabel("Tracts")

    fig.colorbar(walk_im, ax=axes[0], fraction=0.046, pad=0.04)
    fig.colorbar(drive_im, ax=axes[1], fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_top10_routes(
    tracts_gdf: gpd.GeoDataFrame,
    edge_gdf: gpd.GeoDataFrame,
    schools_gdf: gpd.GeoDataFrame,
    dest_tract_id: str,
    route_geoms: dict[str, list[LineString]],
    id_col: str,
    out_path: str = "top10_routes.png",
) -> None:
    """
    High-quality single-panel plot for top 10 routes.
    """
    target_crs = tracts_gdf.crs
    plot_tracts = tracts_gdf.to_crs(target_crs).copy()
    plot_edges = edge_gdf.to_crs(target_crs).copy()
    plot_schools = schools_gdf.to_crs(target_crs).copy()

    fig, ax = plt.subplots(1, 1, figsize=(14, 12))

    # Base layer: tract polygons
    plot_tracts.plot(ax=ax, facecolor="#f3f3f3", edgecolor="#bfc0c2", linewidth=0.3)

    # adjacency edges
    if not plot_edges.empty:
        plot_edges.plot(ax=ax, color="#cfcfcf", linewidth=0.6, alpha=0.5)

    cmap = plt.get_cmap("tab10")
    for idx, (school_name, geoms) in enumerate(route_geoms.items()):
        color = cmap(idx % 10)
        for geom in geoms:
            if geom is None or geom.is_empty:
                continue
            xs, ys = geom.xy
            ax.plot(xs, ys, color=color, linewidth=3.2, solid_capstyle="round", zorder=3)

    # Plot schools as yellow triangles
    plot_schools.plot(ax=ax, color="gold", edgecolor="black", marker="^", markersize=110, zorder=6)
    for i, row in plot_schools.reset_index(drop=True).iterrows():
        x, y = row.geometry.x, row.geometry.y
        label = f"{i+1}. {row['school_name']}"
        ax.text(x, y, label, fontsize=8, ha="left", va="bottom", zorder=7)

    # Highlight downtown tract
    downtown_poly = plot_tracts[plot_tracts[id_col].astype(str) == str(dest_tract_id)]
    if not downtown_poly.empty:
        downtown_poly.plot(ax=ax, facecolor="cyan", edgecolor="black", alpha=0.6, zorder=5)
        centroid = downtown_poly.geometry.centroid.iloc[0]
        ax.scatter(centroid.x, centroid.y, s=140, c="black", zorder=8)

    ax.set_title("Top 10 High School Routes to Downtown Baltimore", fontsize=14)
    ax.set_axis_off()
    plt.tight_layout()
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close(fig)



def export_route_tract_order(
    summary_df: pd.DataFrame,
    tract_nodes: gpd.GeoDataFrame,
    id_col: str,
    out_csv: str = "top10_route_tract_order.csv",
    route_name_col: str = "school_name",
) -> pd.DataFrame:
    """
    Expand each route path into one row per tract in route order.
    This is the file to use when you need the exact tract-by-tract sequence.
    """
    if summary_df.empty:
        ordered_df = pd.DataFrame(
            columns=[
                "route_name",
                "stop_order",
                "tract_id",
                "centroid_lon",
                "centroid_lat",
                "is_origin",
                "is_destination",
            ]
        )
        safe_to_csv(ordered_df, out_csv, index=False)
        return ordered_df

    coord_cols = [id_col]
    if "centroid_lon" in tract_nodes.columns:
        coord_cols.append("centroid_lon")
    if "centroid_lat" in tract_nodes.columns:
        coord_cols.append("centroid_lat")

    tract_lookup = tract_nodes[coord_cols].copy()
    tract_lookup[id_col] = tract_lookup[id_col].astype(str)
    tract_lookup = tract_lookup.drop_duplicates(subset=[id_col])

    ordered_rows: list[dict[str, object]] = []

    for _, row in summary_df.iterrows():
        route_name = str(row.get(route_name_col, "route"))
        path_sequence = str(row.get("path_sequence", "")).strip()
        if not path_sequence:
            continue

        tract_ids = [part.strip() for part in path_sequence.split("->") if part.strip()]
        total_tracts = len(tract_ids)

        for stop_order, tract_id in enumerate(tract_ids, start=1):
            match = tract_lookup[tract_lookup[id_col] == str(tract_id)]
            centroid_lon = float(match.iloc[0]["centroid_lon"]) if (not match.empty and "centroid_lon" in match.columns and pd.notna(match.iloc[0]["centroid_lon"])) else np.nan
            centroid_lat = float(match.iloc[0]["centroid_lat"]) if (not match.empty and "centroid_lat" in match.columns and pd.notna(match.iloc[0]["centroid_lat"])) else np.nan

            ordered_rows.append(
                {
                    "route_name": route_name,
                    "stop_order": stop_order,
                    "tract_id": str(tract_id),
                    "centroid_lon": centroid_lon,
                    "centroid_lat": centroid_lat,
                    "is_origin": stop_order == 1,
                    "is_destination": stop_order == total_tracts,
                }
            )

    ordered_df = pd.DataFrame(
        ordered_rows,
        columns=[
            "route_name",
            "stop_order",
            "tract_id",
            "centroid_lon",
            "centroid_lat",
            "is_origin",
            "is_destination",
        ],
    )
    safe_to_csv(ordered_df, out_csv, index=False)
    logger.info("Saved ordered route tract file to %s", out_csv)
    return ordered_df


def create_top10_routes(
    tracts_gdf: gpd.GeoDataFrame,
    edge_gdf: gpd.GeoDataFrame,
    id_col: str,
    out_map: str = "top10_routes.png",
    out_csv: str = "top10_route_summary.csv",
    out_order_csv: str = "top10_route_tract_order.csv",
) -> pd.DataFrame:
    """
    Build school points, assign to tracts, compute shortest paths to downtown, plot and save outputs.
    Returns summary DataFrame.
    """
    # build schools gdf
    schools_df = pd.DataFrame(TOP_10_HIGH_SCHOOLS, columns=["school_name", "lon", "lat"]).reset_index()
    schools_df = schools_df.rename(columns={"index": "rank"})
    schools_df["address"] = ""
    schools_gdf = gpd.GeoDataFrame(
        schools_df,
        geometry=gpd.points_from_xy(schools_df.lon, schools_df.lat),
        crs="EPSG:4326",
    ).to_crs(tracts_gdf.crs)

    # assign to origin tracts
    schools_with_origins = assign_schools_to_origin_tracts(schools_gdf, tracts_gdf, id_col)

    # downtown target
    downtown_target = get_downtown_target_tract(tracts_gdf, id_col)

    summary_rows: list[dict[str, object]] = []
    route_geoms: dict[str, list[LineString]] = {}

    for _, school in schools_with_origins.sort_values("rank").iterrows():
        start = str(school["origin_tract_id"])
        school_name = school["school_name"]
        try:
            path_nodes, route_edges_gdf, total_cost = shortest_path_tracts(edge_gdf, start, downtown_target, weight_col="drive_distance_m")
        except Exception:
            path_nodes, route_edges_gdf, total_cost = [], gpd.GeoDataFrame(), float("nan")

        total_drive = float(total_cost) if not pd.isna(total_cost) else float("nan")
        summary_rows.append(
            {
                "school_name": school_name,
                "origin_tract": start,
                "destination_tract": downtown_target,
                "total_distance_m": total_drive,
                "total_distance_miles": meters_to_miles(total_drive) if not pd.isna(total_drive) else float("nan"),
                "num_tracts_in_path": len(path_nodes) if path_nodes else 0,
                "path_sequence": " -> ".join(path_nodes) if path_nodes else "",
            }
        )

        geoms = []
        if not route_edges_gdf.empty:
            for _, r in route_edges_gdf.iterrows():
                geoms.append(r.geometry)
        route_geoms[school_name] = geoms

    summary_df = pd.DataFrame(summary_rows)
    safe_to_csv(summary_df, out_csv, index=False)
    logger.info("Saved top10 route summary to %s", out_csv)
    export_route_tract_order(summary_df, tracts_gdf, id_col=id_col, out_csv=out_order_csv, route_name_col="school_name")

    plot_top10_routes(
        tracts_gdf=tracts_gdf,
        edge_gdf=edge_gdf,
        schools_gdf=schools_with_origins,
        dest_tract_id=downtown_target,
        route_geoms=route_geoms,
        id_col=id_col,
        out_path=out_map,
    )
    logger.info("Saved top10 route map to %s", out_map)
    return summary_df


# =========================================================
# PIPELINE
# =========================================================


def prepare_tract_data(config: ProjectConfig) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, bool, str]:
    tract_path = auto_download_real_tract_path(config) or resolve_tract_path(config)
    using_synthetic = False

    if tract_path is None:
        if not config.use_synthetic_backup:
            raise FileNotFoundError("No real Baltimore-area tract file was found.")
        logger.warning("No real tract file found. Using synthetic backup tract data.")
        tracts = generate_synthetic_tracts(projected_crs=config.projected_crs)
        using_synthetic = True
        id_col = config.default_id_col
    else:
        try:
            tracts = load_tracts(tract_path, input_crs=config.input_crs)
            tracts = validate_geometries(tracts)
            id_col = detect_id_column(tracts, preferred=config.default_id_col)
        except Exception as exc:
            if not config.use_synthetic_backup:
                raise
            logger.warning("Failed to use real tract file (%s). Falling back to synthetic data.", exc)
            tracts = generate_synthetic_tracts(projected_crs=config.projected_crs)
            using_synthetic = True
            id_col = config.default_id_col

    tracts = add_polygon_labels(tracts, id_col=id_col)
    tract_nodes, edge_network = build_edge_network(
        tracts_gdf=tracts,
        id_col=id_col,
        projected_crs=config.projected_crs,
        require_shared_boundary=config.require_shared_boundary,
    )
    edge_network = calculate_pair_metrics(edge_network, config)
    return tract_nodes, edge_network, using_synthetic, id_col




# =========================================================
# ROUTE IMPORT / COLUMN-WISE SOLUTION HELPERS
# =========================================================

FILL_VALUE = -1

# These filenames match the tract-based exporter in the updated routing script.
DEFAULT_MATRIX_FILES = {
    "adjacency": "tract_adjacency_matrix_adjacent_only.csv",
    "walk_distance": "tract_walk_distance_matrix_adjacent_only_by_id.csv",
    "walk_time": "tract_walk_time_matrix_adjacent_only_by_id.csv",
    "drive_distance": "tract_drive_distance_matrix_adjacent_only_by_id.csv",
    "drive_time_offpeak": "tract_drive_time_matrix_offpeak_adjacent_only_by_id.csv",
    "drive_time_am": "tract_drive_time_matrix_am_7_8_adjacent_only_by_id.csv",
    "drive_time_pm": "tract_drive_time_matrix_pm_3_4_adjacent_only_by_id.csv",
}


# =========================================================
# PARSING HELPERS
# =========================================================


def is_missing(value: Any) -> bool:
    return value is None or (isinstance(value, float) and np.isnan(value))



def parse_route_value(route_value: Any) -> list[str]:
    """
    Accepts routes stored as:
    - ["24510040100", "24510040200"]
    - "[24510040100, 24510040200]"
    - "24510040100,24510040200"
    - tuple / numpy array / pandas Series-like
    Returns a list of tract IDs as strings.
    """
    if is_missing(route_value):
        return []

    if isinstance(route_value, (list, tuple, np.ndarray, pd.Series)):
        return [str(x).strip() for x in route_value if not is_missing(x) and str(x).strip() not in {"", str(FILL_VALUE)}]

    if isinstance(route_value, str):
        text = route_value.strip()
        if text == "":
            return []

        # JSON / Python literal list first
        if (text.startswith("[") and text.endswith("]")) or (text.startswith("(") and text.endswith(")")):
            try:
                parsed = ast.literal_eval(text)
                return parse_route_value(parsed)
            except Exception:
                pass

        # fallback comma-separated string; also clean surrounding brackets/quotes
        cleaned_text = text.strip().strip('[]()')
        parts = [part.strip().strip("'\"") for part in cleaned_text.split(',')]
        return [part for part in parts if part not in {"", str(FILL_VALUE)}]

    return [str(route_value).strip()]



def detect_stop_columns(columns: list[str], prefixes: tuple[str, ...] = ("stop_", "tract_", "node_")) -> list[str]:
    stop_cols = [col for col in columns if any(str(col).lower().startswith(prefix) for prefix in prefixes)]
    if not stop_cols:
        return []

    def sort_key(name: str) -> tuple[int, str]:
        digits = "".join(ch for ch in str(name) if ch.isdigit())
        return (int(digits) if digits else 10**9, str(name))

    return sorted(stop_cols, key=sort_key)



def row_to_route_list(row: pd.Series) -> list[str]:
    stop_cols = detect_stop_columns(list(row.index))
    if not stop_cols:
        return []

    route: list[str] = []
    for col in stop_cols:
        value = row[col]
        if is_missing(value):
            continue
        value_str = str(value).strip()
        if value_str in {"", str(FILL_VALUE), f"{float(FILL_VALUE):.1f}"}:
            continue
        route.append(value_str)
    return route



def pad_route(route: list[str], target_len: int, fill_value: int = FILL_VALUE) -> list[Any]:
    return route + [fill_value] * max(0, target_len - len(route))


# =========================================================
# MATRIX LOADERS
# =========================================================


def load_single_matrix(path: Path) -> Optional[pd.DataFrame]:
    if not path.exists():
        return None
    matrix = pd.read_csv(path, index_col=0, dtype=str)
    matrix.index = matrix.index.astype(str)
    matrix.columns = matrix.columns.astype(str)
    matrix = matrix.apply(pd.to_numeric, errors='ignore')
    return matrix



def load_matrices(matrix_dir: Path) -> dict[str, Optional[pd.DataFrame]]:
    return {name: load_single_matrix(matrix_dir / filename) for name, filename in DEFAULT_MATRIX_FILES.items()}


# =========================================================
# ROUTE IMPORTERS
# =========================================================


def import_original_routes_from_csv(path: Path) -> dict[str, list[str]]:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    columns_lower = {col.lower(): col for col in df.columns}

    route_id_col = None
    for candidate in ["route_id", "original_route_id", "id"]:
        if candidate in columns_lower:
            route_id_col = columns_lower[candidate]
            break
    if route_id_col is None:
        raise ValueError("Original routes CSV must contain route_id or original_route_id.")

    if "route_list" in columns_lower:
        route_list_col = columns_lower["route_list"]
        return {
            str(row[route_id_col]): parse_route_value(row[route_list_col])
            for _, row in df.iterrows()
        }

    routes: dict[str, list[str]] = {}
    for _, row in df.iterrows():
        routes[str(row[route_id_col])] = row_to_route_list(row)
    return routes



def import_original_routes_from_json(path: Path) -> dict[str, list[str]]:
    data = json.loads(path.read_text())

    if isinstance(data, dict):
        return {str(key): parse_route_value(value) for key, value in data.items()}

    if isinstance(data, list):
        routes: dict[str, list[str]] = {}
        for idx, item in enumerate(data, start=1):
            if isinstance(item, dict):
                route_id = item.get("route_id") or item.get("original_route_id") or f"route_{idx}"
                route_value = item.get("route_list") or item.get("route") or item.get("stops")
                routes[str(route_id)] = parse_route_value(route_value)
            else:
                routes[f"route_{idx}"] = parse_route_value(item)
        return routes

    raise ValueError("Unsupported JSON structure for original routes.")



def import_original_routes(path: Path) -> dict[str, list[str]]:
    if path.suffix.lower() == ".json":
        return import_original_routes_from_json(path)
    return import_original_routes_from_csv(path)



def import_candidate_solutions_from_csv(path: Path) -> list[dict[str, Any]]:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    columns_lower = {col.lower(): col for col in df.columns}

    original_col = columns_lower.get("original_route_id") or columns_lower.get("route_id") or columns_lower.get("original_id")
    if original_col is None:
        raise ValueError("Candidate solutions CSV must contain original_route_id or route_id.")

    solution_col = columns_lower.get("solution_id") or columns_lower.get("candidate_id")

    records: list[dict[str, Any]] = []

    if "route_list" in columns_lower:
        route_col = columns_lower["route_list"]
        for idx, row in df.iterrows():
            records.append(
                {
                    "original_route_id": str(row[original_col]),
                    "solution_id": str(row[solution_col]) if solution_col else f"solution_{idx + 1}",
                    "route": parse_route_value(row[route_col]),
                }
            )
        return records

    for idx, row in df.iterrows():
        records.append(
            {
                "original_route_id": str(row[original_col]),
                "solution_id": str(row[solution_col]) if solution_col else f"solution_{idx + 1}",
                "route": row_to_route_list(row),
            }
        )
    return records



def import_candidate_solutions_from_json(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text())

    records: list[dict[str, Any]] = []

    if isinstance(data, dict):
        # {original_route_id: [[...], [...]]}
        for original_route_id, solutions in data.items():
            if isinstance(solutions, list) and all(not isinstance(item, dict) for item in solutions):
                # maybe one route, maybe list-of-lists. Distinguish by nesting.
                if solutions and isinstance(solutions[0], list):
                    iterable = solutions
                else:
                    iterable = [solutions]
            else:
                iterable = solutions

            for idx, solution in enumerate(iterable, start=1):
                if isinstance(solution, dict):
                    solution_id = str(solution.get("solution_id") or solution.get("candidate_id") or f"solution_{idx}")
                    route_value = solution.get("route") or solution.get("route_list") or solution.get("stops")
                else:
                    solution_id = f"solution_{idx}"
                    route_value = solution

                records.append(
                    {
                        "original_route_id": str(original_route_id),
                        "solution_id": solution_id,
                        "route": parse_route_value(route_value),
                    }
                )
        return records

    if isinstance(data, list):
        for idx, item in enumerate(data, start=1):
            if isinstance(item, dict):
                original_route_id = item.get("original_route_id") or item.get("route_id") or f"route_{idx}"
                solution_id = item.get("solution_id") or item.get("candidate_id") or f"solution_{idx}"
                route_value = item.get("route") or item.get("route_list") or item.get("stops")
                records.append(
                    {
                        "original_route_id": str(original_route_id),
                        "solution_id": str(solution_id),
                        "route": parse_route_value(route_value),
                    }
                )
            else:
                raise ValueError("List JSON for candidate solutions must contain dicts or a dict keyed by original route id.")
        return records

    raise ValueError("Unsupported JSON structure for candidate solutions.")



def import_candidate_solutions(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".json":
        return import_candidate_solutions_from_json(path)
    return import_candidate_solutions_from_csv(path)


# =========================================================
# DATAFRAME BUILDERS
# =========================================================


def build_original_routes_df(original_routes: dict[str, list[str]]) -> pd.DataFrame:
    if not original_routes:
        return pd.DataFrame()

    max_len = max((len(route) for route in original_routes.values()), default=0)
    rows: list[dict[str, Any]] = []

    for original_route_id, route in original_routes.items():
        padded = pad_route(route, max_len)
        row: dict[str, Any] = {
            "original_route_id": str(original_route_id),
            "original_route": route,
            "original_route_padded": padded,
            "original_route_length": len(route),
        }
        for idx, value in enumerate(padded, start=1):
            row[f"orig_stop_{idx}"] = value
        rows.append(row)

    df = pd.DataFrame(rows).set_index("original_route_id")
    return df



def build_candidate_solutions_df(
    solution_records: list[dict[str, Any]],
    original_routes: dict[str, list[str]],
) -> pd.DataFrame:
    if not solution_records:
        return pd.DataFrame()

    max_solution_len = max((len(record["route"]) for record in solution_records), default=0)
    max_original_len = max((len(route) for route in original_routes.values()), default=0)

    rows: list[dict[str, Any]] = []

    for record in solution_records:
        original_route_id = str(record["original_route_id"])
        solution_id = str(record["solution_id"])
        route = record["route"]
        original_route = original_routes.get(original_route_id, [])

        padded_route = pad_route(route, max_solution_len)
        padded_original_route = pad_route(original_route, max_original_len)

        row: dict[str, Any] = {
            "original_route_id": original_route_id,
            "solution_id": solution_id,
            "route": route,
            "route_padded": padded_route,
            "route_length": len(route),
            "original_route": original_route,
            "original_route_padded": padded_original_route,
            "original_route_length": len(original_route),
        }

        for idx, value in enumerate(padded_route, start=1):
            row[f"stop_{idx}"] = value

        for idx, value in enumerate(padded_original_route, start=1):
            row[f"orig_stop_{idx}"] = value

        rows.append(row)

    df = pd.DataFrame(rows)
    df = df.set_index(["original_route_id", "solution_id"]).sort_index()
    return df


# =========================================================
# SCORING HELPERS
# =========================================================


def _clean_route_for_scoring(route: list[Any]) -> list[str]:
    cleaned: list[str] = []
    for value in route:
        if is_missing(value):
            continue
        value_str = str(value).strip()
        if value_str in {"", str(FILL_VALUE), f"{float(FILL_VALUE):.1f}"}:
            continue
        cleaned.append(value_str)
    return cleaned



def score_route_with_matrix(route: list[Any], matrix: Optional[pd.DataFrame], invalid_value: float = float(FILL_VALUE)) -> tuple[float, int]:
    if matrix is None:
        return float("nan"), 0

    cleaned = _clean_route_for_scoring(route)
    if len(cleaned) < 2:
        return 0.0, 0

    total = 0.0
    invalid_edges = 0

    for left, right in zip(cleaned[:-1], cleaned[1:]):
        if left not in matrix.index or right not in matrix.columns:
            invalid_edges += 1
            continue

        value = pd.to_numeric(pd.Series([matrix.loc[left, right]]), errors="coerce").iloc[0]
        if pd.isna(value) or float(value) == invalid_value:
            invalid_edges += 1
        else:
            total += float(value)

    return total, invalid_edges



def add_route_metrics(solutions_df: pd.DataFrame, matrices: dict[str, Optional[pd.DataFrame]]) -> pd.DataFrame:
    if solutions_df.empty:
        return solutions_df.copy()

    out = solutions_df.copy()
    out["route_node_count"] = out["route"].apply(lambda route: len(_clean_route_for_scoring(route)))
    out["unique_route_node_count"] = out["route"].apply(lambda route: len(set(_clean_route_for_scoring(route))))
    out["starts_match_original"] = out.apply(
        lambda row: (_clean_route_for_scoring(row["route"])[0] if _clean_route_for_scoring(row["route"]) else None)
        == (_clean_route_for_scoring(row["original_route"])[0] if _clean_route_for_scoring(row["original_route"]) else None),
        axis=1,
    )
    out["ends_match_original"] = out.apply(
        lambda row: (_clean_route_for_scoring(row["route"])[-1] if _clean_route_for_scoring(row["route"]) else None)
        == (_clean_route_for_scoring(row["original_route"])[-1] if _clean_route_for_scoring(row["original_route"]) else None),
        axis=1,
    )

    adjacency_scores = out["route"].apply(lambda route: score_route_with_matrix(route, matrices.get("adjacency")))
    out["adjacency_sum"] = adjacency_scores.apply(lambda item: item[0])
    out["invalid_adjacent_edges"] = adjacency_scores.apply(lambda item: item[1])
    out["all_edges_adjacent"] = out["invalid_adjacent_edges"] == 0

    routing_am_scores = out["route"].apply(lambda route: score_route_with_matrix(route, matrices.get("drive_time_am")))
    out["routing_am_total"] = routing_am_scores.apply(lambda item: item[0])
    out["routing_am_invalid_edges"] = routing_am_scores.apply(lambda item: item[1])
    out["routing_am_all_adjacent"] = out["routing_am_invalid_edges"] == 0
    out["routing_am_avg_per_edge"] = out.apply(
        lambda row: (float(row["routing_am_total"]) / max(row["route_node_count"] - 1, 1))
        if not pd.isna(row["routing_am_total"]) and row["routing_am_invalid_edges"] == 0 and row["route_node_count"] >= 2
        else np.nan,
        axis=1,
    )

    for matrix_name, output_col in [
        ("walk_distance", "walk_distance_total"),
        ("walk_time", "walk_time_total"),
        ("drive_distance", "drive_distance_total"),
        ("drive_time_offpeak", "drive_time_offpeak_total"),
        ("drive_time_am", "drive_time_am_total"),
        ("drive_time_pm", "drive_time_pm_total"),
    ]:
        scores = out["route"].apply(lambda route: score_route_with_matrix(route, matrices.get(matrix_name)))
        out[output_col] = scores.apply(lambda item: item[0])
        out[f"{output_col}_invalid_edges"] = scores.apply(lambda item: item[1])

    return out


# =========================================================
# EXPORT HELPERS
# =========================================================


def dataframe_to_list_of_lists(route_df: pd.DataFrame) -> list[list[str]]:
    if route_df.empty:
        return []
    return [list(_clean_route_for_scoring(route)) for route in route_df["route"].tolist()]



def dataframe_to_solution_records(route_df: pd.DataFrame) -> list[dict[str, Any]]:
    if route_df.empty:
        return []

    records: list[dict[str, Any]] = []
    for (original_route_id, solution_id), row in route_df.iterrows():
        records.append(
            {
                "original_route_id": str(original_route_id),
                "solution_id": str(solution_id),
                "route": list(_clean_route_for_scoring(row["route"])),
                "original_route": list(_clean_route_for_scoring(row["original_route"])),
            }
        )
    return records



def build_route_validation_report(
    solutions_df: pd.DataFrame,
    adjacency_matrix: Optional[pd.DataFrame],
) -> pd.DataFrame:
    if solutions_df.empty or adjacency_matrix is None:
        return pd.DataFrame(columns=["original_route_id", "solution_id", "missing_node", "position_in_route", "issue"])

    valid_nodes = set(adjacency_matrix.index.astype(str))
    rows: list[dict[str, Any]] = []

    for (original_route_id, solution_id), row in solutions_df.iterrows():
        cleaned_route = _clean_route_for_scoring(row["route"])
        for idx, node in enumerate(cleaned_route, start=1):
            if str(node) not in valid_nodes:
                rows.append({
                    "original_route_id": str(original_route_id),
                    "solution_id": str(solution_id),
                    "missing_node": str(node),
                    "position_in_route": idx,
                    "issue": "node_not_found_in_adjacency_matrix",
                })

    return pd.DataFrame(rows)


def export_outputs(
    output_dir: Path,
    matrices: dict[str, Optional[pd.DataFrame]],
    original_routes_df: pd.DataFrame,
    solutions_df: pd.DataFrame,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    safe_to_csv(original_routes_df, output_dir / "original_routes_columnwise.csv")
    safe_to_csv(solutions_df, output_dir / "candidate_solutions_columnwise.csv")

    safe_write_json(dataframe_to_list_of_lists(solutions_df), output_dir / "candidate_solutions_list_of_lists.json")
    safe_write_json(dataframe_to_solution_records(solutions_df), output_dir / "candidate_solutions_records.json")

    validation_df = build_route_validation_report(solutions_df, matrices.get("adjacency"))
    safe_to_csv(validation_df, output_dir / "route_validation_report.csv", index=False)

    matrix_summary_rows = []
    for matrix_name, matrix in matrices.items():
        matrix_summary_rows.append(
            {
                "matrix_name": matrix_name,
                "loaded": matrix is not None,
                "rows": int(matrix.shape[0]) if matrix is not None else 0,
                "cols": int(matrix.shape[1]) if matrix is not None else 0,
            }
        )
    safe_to_csv(pd.DataFrame(matrix_summary_rows), output_dir / "matrix_load_summary.csv", index=False)




# =========================================================
# COMBINED MATRIX + ROUTE IMPORT PIPELINE
# =========================================================


def make_output_files(output_dir: Path) -> OutputFiles:
    output_dir.mkdir(parents=True, exist_ok=True)
    return OutputFiles(
        adjacency_matrix_csv=str(output_dir / 'tract_adjacency_matrix_adjacent_only.csv'),
        neighbor_csv=str(output_dir / 'tract_neighbor_distances.csv'),
        walk_distance_matrix_csv=str(output_dir / 'tract_walk_distance_matrix_adjacent_only.csv'),
        walk_time_matrix_csv=str(output_dir / 'tract_walk_time_matrix_adjacent_only.csv'),
        drive_distance_matrix_csv=str(output_dir / 'tract_drive_distance_matrix_adjacent_only.csv'),
        drive_time_offpeak_matrix_csv=str(output_dir / 'tract_drive_time_matrix_offpeak_adjacent_only.csv'),
        drive_time_am_matrix_csv=str(output_dir / 'tract_drive_time_matrix_am_7_8_adjacent_only.csv'),
        drive_time_pm_matrix_csv=str(output_dir / 'tract_drive_time_matrix_pm_3_4_adjacent_only.csv'),
        walk_distance_matrix_by_id_csv=str(output_dir / 'tract_walk_distance_matrix_adjacent_only_by_id.csv'),
        walk_time_matrix_by_id_csv=str(output_dir / 'tract_walk_time_matrix_adjacent_only_by_id.csv'),
        drive_distance_matrix_by_id_csv=str(output_dir / 'tract_drive_distance_matrix_adjacent_only_by_id.csv'),
        drive_time_offpeak_matrix_by_id_csv=str(output_dir / 'tract_drive_time_matrix_offpeak_adjacent_only_by_id.csv'),
        drive_time_am_matrix_by_id_csv=str(output_dir / 'tract_drive_time_matrix_am_7_8_adjacent_only_by_id.csv'),
        drive_time_pm_matrix_by_id_csv=str(output_dir / 'tract_drive_time_matrix_pm_3_4_adjacent_only_by_id.csv'),
        tract_lookup_csv=str(output_dir / 'tract_lookup.csv'),
        route_validation_csv=str(output_dir / 'route_validation_report.csv'),
        run_metadata_json=str(output_dir / 'run_metadata.json'),
        query_results_csv=str(output_dir / 'tract_pair_query_results.csv'),
        adjacency_map_png=str(output_dir / 'tract_adjacency_only_map.png'),
        distance_heatmap_png=str(output_dir / 'adjacent_only_distance_heatmaps.png'),
        school_route_map_png=str(output_dir / 'top5_high_schools_to_downtown_routes.png'),
        school_route_summary_csv=str(output_dir / 'top5_high_school_route_summary.csv'),
        school_route_edges_csv=str(output_dir / 'top5_high_school_route_edges.csv'),
    )


def generated_outputs_to_matrix_dict(outputs: dict[str, pd.DataFrame]) -> dict[str, Optional[pd.DataFrame]]:
    return {
        'adjacency': outputs.get('adjacency_matrix'),
        'walk_distance': outputs.get('walk_distance_matrix_id', outputs.get('walk_distance_matrix')),
        'walk_time': outputs.get('walk_time_matrix_id', outputs.get('walk_time_matrix')),
        'drive_distance': outputs.get('drive_distance_matrix_id', outputs.get('drive_distance_matrix')),
        'drive_time_offpeak': outputs.get('drive_time_offpeak_matrix_id', outputs.get('drive_time_offpeak_matrix')),
        'drive_time_am': outputs.get('drive_time_am_matrix_id', outputs.get('drive_time_am_matrix')),
        'drive_time_pm': outputs.get('drive_time_pm_matrix_id', outputs.get('drive_time_pm_matrix')),
    }


def prepare_tract_data_from_source(config: ProjectConfig, tract_path: Optional[str] = None) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, bool, str]:
    using_synthetic = False

    if tract_path is None:
        return prepare_tract_data(config)

    try:
        tracts = load_tracts(tract_path, input_crs=config.input_crs)
        tracts = validate_geometries(tracts)
        id_col = detect_id_column(tracts, preferred=config.default_id_col)
    except Exception as exc:
        if not config.use_synthetic_backup:
            raise
        logger.warning('Failed to use tract file (%s). Falling back to synthetic data.', exc)
        tracts = generate_synthetic_tracts(projected_crs=config.projected_crs)
        using_synthetic = True
        id_col = config.default_id_col

    tracts = add_polygon_labels(tracts, id_col=id_col)
    tract_nodes, edge_network = build_edge_network(
        tracts_gdf=tracts,
        id_col=id_col,
        projected_crs=config.projected_crs,
        require_shared_boundary=config.require_shared_boundary,
    )
    edge_network = calculate_pair_metrics(edge_network, config)
    return tract_nodes, edge_network, using_synthetic, id_col


def run_matrix_pipeline(
    config: ProjectConfig,
    files: OutputFiles,
    tract_file: Optional[Path] = None,
    create_plots: bool = True,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, dict[str, pd.DataFrame], bool, str]:
    tract_nodes, edge_network, using_synthetic, id_col = prepare_tract_data_from_source(
        config=config,
        tract_path=str(tract_file) if tract_file is not None else None,
    )

    outputs = build_output_tables(tract_nodes, edge_network, id_col)
    export_core_outputs(outputs, files)
    safe_to_csv(build_tract_lookup_table(tract_nodes, id_col), files.tract_lookup_csv, index=False)

    if create_plots:
        plot_adjacency_map(tract_nodes, edge_network, files.adjacency_map_png)
        plot_distance_heatmaps(outputs['walk_distance_matrix'], outputs['drive_distance_matrix'], files.distance_heatmap_png)

    example_query_pairs: list[tuple[str, str]] = []
    if len(tract_nodes) >= 2:
        tract_ids = tract_nodes[id_col].astype(str).tolist()
        example_query_pairs.append((tract_ids[0], tract_ids[1]))
        example_query_pairs.append((tract_ids[0], tract_ids[-1]))

    if example_query_pairs:
        query_results = build_query_results_table(edge_network, example_query_pairs)
        safe_to_csv(query_results, files.query_results_csv, index=False)

    if config.create_school_routes:
        try:
            build_school_route_outputs(tract_nodes, edge_network, id_col, using_synthetic, files)
        except Exception as exc:
            logger.warning('School route outputs were skipped: %s', exc)
        try:
            create_top10_routes(
                tracts_gdf=tract_nodes,
                edge_gdf=edge_network,
                id_col=id_col,
                out_map=str(Path(files.school_route_map_png).with_name('top10_routes.png')),
                out_csv=str(Path(files.school_route_summary_csv).with_name('top10_route_summary.csv')),
            )
        except Exception as exc:
            logger.warning('Top10 route outputs were skipped: %s', exc)

    run_metadata = {
        'used_synthetic_backup': using_synthetic,
        'actual_tract_id_column': id_col,
        'number_of_tracts': int(len(tract_nodes)),
        'number_of_direct_neighbor_edges': int(len(edge_network)),
        'traffic_api_enabled': bool(config.use_live_traffic_api),
        'traffic_api_key_present': bool(config.google_routes_api_key),
        'created_at_local': datetime.now().isoformat(),
    }
    safe_write_json(run_metadata, files.run_metadata_json)

    logger.info('Used synthetic backup: %s', using_synthetic)
    logger.info('Actual tract ID column used: %s', id_col)
    logger.info('Number of tracts: %s', len(tract_nodes))
    logger.info('Number of direct neighbor edges: %s', len(edge_network))

    return tract_nodes, edge_network, outputs, using_synthetic, id_col




def fetch_vehicle_positions() -> None:
    if requests is None or pytz is None:
        raise ImportError('requests and pytz are required for vehicle polling.')
    s3_client = get_s3_client()
    if s3_client is None:
        raise ImportError('boto3 is required for vehicle polling.')

    slack_client = get_slack_client()

    utc_now = datetime.now(pytz.utc)
    et_timezone = pytz.timezone('US/Eastern')
    et_now = utc_now.astimezone(et_timezone)
    timestamp = et_now.strftime("%Y%m%d%H%M%S")
    hour_folder = et_now.strftime("%Y-%m-%d-%H")
    day_folder = et_now.strftime("%Y-%m-%d")
    json_folder_path = f'school-transportation/vehicle-positions/json/{day_folder}/{hour_folder}/'
    filename = f"{json_folder_path}positions_data_{timestamp}.json"

    positions_response = requests.get(
        positions_url,
        params=positions_queryString,
        headers=headers,
        timeout=60,
    )

    if positions_response.status_code != 200:
        error_date = datetime.now().astimezone(et_timezone).strftime('%Y-%m-%d %H:%M:%S')
        error_message = (
            f'<!channel> Failed to fetch bus locations at {error_date}. '
            f'Status: {positions_response.status_code} :rotating_light:'
        )
        logger.error(error_message)

        if slack_client is not None:
            try:
                response = slack_client.chat_postMessage(channel=channel_id, text=error_message)
                logger.info("Slack error notification sent: %s", response.get("ts"))
            except SlackApiError as e:
                logger.error("Error sending Slack message: %s", getattr(e, "response", {}).get('error', str(e)))
        return

    positions_data = positions_response.json()
    json_data = json.dumps(positions_data)

    hour_folder_exists = s3_client.list_objects_v2(Bucket=S3_BUCKET, Prefix=json_folder_path)
    if not hour_folder_exists.get('Contents'):
        s3_client.put_object(Bucket=S3_BUCKET, Key=json_folder_path)
        finish_time_utc = datetime.now(pytz.utc)
        finish_time_et = finish_time_utc.astimezone(et_timezone)
        finish_timestamp = finish_time_et.strftime('%Y-%m-%d %H:%M:%S')
        s3_link = (
            f"https://us-east-1.console.aws.amazon.com/s3/buckets/{S3_BUCKET}"
            f"?prefix={json_folder_path}&region=us-east-1&bucketType=general"
        )
        new_folder_message = f':white_check_mark:  <{s3_link}|New folder.>\n\nCreated at {finish_timestamp}'
        logger.info("Created new S3 hour folder at %s", json_folder_path)

        if slack_client is not None:
            try:
                response = slack_client.chat_postMessage(channel=channel_id, text=new_folder_message)
                logger.info("Slack new-folder notification sent: %s", response.get("ts"))
            except SlackApiError as e:
                logger.error("Error sending Slack message: %s", getattr(e, "response", {}).get('error', str(e)))

    s3_client.put_object(Bucket=S3_BUCKET, Key=filename, Body=json_data)
    logger.info("Uploaded vehicle positions JSON to s3://%s/%s", S3_BUCKET, filename)


def is_within_schedule() -> bool:
    if pytz is None:
        raise ImportError('pytz is required for vehicle polling.')
    start_time = 4
    end_time = 25
    eastern = pytz.timezone('US/Eastern')
    now_et = datetime.now(eastern)
    current_time = now_et.hour + now_et.minute / 60

    if end_time < start_time:
        end_time += 24

    return start_time <= current_time < end_time


def run_vehicle_position_poller(poll_interval_seconds: float = 5.0, off_hours_sleep_seconds: float = 300.0) -> None:
    logger.info("Starting vehicle position poller.")
    while True:
        if is_within_schedule():
            start_ts = time.time()
            fetch_vehicle_positions()
            elapsed_time = time.time() - start_ts
            sleep_time = max(0.0, poll_interval_seconds - elapsed_time)
            time.sleep(sleep_time)
        else:
            time.sleep(off_hours_sleep_seconds)


def build_cli_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            'Single pipeline that builds tract-based adjacency/time/distance matrices and optionally '
            'imports original routes plus candidate solutions into a column-wise -1-padded format.'
        )
    )
    parser.add_argument('--tract-file', type=Path, default=None, help='Optional tract polygon file. If omitted, auto-discovery/synthetic fallback is used.')
    parser.add_argument('--matrix-output-dir', type=Path, default=Path('tract_outputs'), help='Folder for exported tract matrices and map outputs.')
    parser.add_argument('--matrix-dir', type=Path, default=None, help='Existing folder of tract matrix CSVs to use for route scoring instead of generating new ones.')
    parser.add_argument('--original-routes', type=Path, default=None, help='CSV or JSON file of original routes.')
    parser.add_argument('--candidate-solutions', type=Path, default=None, help='CSV or JSON file of candidate solution routes.')
    parser.add_argument('--solution-output-dir', type=Path, default=Path('processed_solution_outputs'), help='Folder for route-format outputs.')
    parser.add_argument('--google-routes-api-key', type=str, default=None, help='Optional Google Routes API key. If omitted, GOOGLE_MAPS_API_KEY is used when present.')
    parser.add_argument('--skip-auto-download-tracts', action='store_true', help='Disable automatic download of real Baltimore City tract data.')
    parser.add_argument('--disable-traffic-api', action='store_true', help='Disable live traffic-aware routing API calls and use centroid-based fallbacks only.')
    parser.add_argument('--skip-school-routes', action='store_true', help='Skip school-route map and summary exports.')
    parser.add_argument('--skip-plots', action='store_true', help='Skip adjacency/distance plot exports.')
    parser.add_argument('--run-vehicle-poller', action='store_true', help='Run the Swiftly vehicle-position polling loop instead of the route pipeline.')
    parser.add_argument('--vehicle-poll-interval-seconds', type=float, default=5.0, help='Polling interval in seconds while within schedule.')
    parser.add_argument('--vehicle-off-hours-sleep-seconds', type=float, default=300.0, help='Sleep interval in seconds while outside the active schedule.')
    return parser


def main() -> None:
    parser = build_cli_parser()
    args = parser.parse_args()

    if args.run_vehicle_poller:
        run_vehicle_position_poller(
            poll_interval_seconds=args.vehicle_poll_interval_seconds,
            off_hours_sleep_seconds=args.vehicle_off_hours_sleep_seconds,
        )
        return

    config = ProjectConfig(
        create_school_routes=not args.skip_school_routes,
        auto_download_real_tracts=not args.skip_auto_download_tracts,
        use_live_traffic_api=not args.disable_traffic_api,
        google_routes_api_key=args.google_routes_api_key or os.getenv('GOOGLE_MAPS_API_KEY'),
    )

    matrices: dict[str, Optional[pd.DataFrame]] = {
        'adjacency': None,
        'walk_distance': None,
        'walk_time': None,
        'drive_distance': None,
        'drive_time_offpeak': None,
        'drive_time_am': None,
        'drive_time_pm': None,
    }

    generated_outputs: Optional[dict[str, pd.DataFrame]] = None

    # Generate matrices unless the user explicitly supplied an existing matrix directory and no tract build is needed.
    if args.matrix_dir is None or args.tract_file is not None or (args.original_routes is None and args.candidate_solutions is None):
        files = make_output_files(args.matrix_output_dir)
        _, _, generated_outputs, _, _ = run_matrix_pipeline(
            config=config,
            files=files,
            tract_file=args.tract_file,
            create_plots=not args.skip_plots,
        )
        matrices.update(generated_outputs_to_matrix_dict(generated_outputs))
    else:
        logger.info('Skipping matrix generation and loading matrices from %s', args.matrix_dir)

    # Load existing matrix dir if the user supplied one. This can override generated outputs if desired.
    if args.matrix_dir is not None:
        loaded = load_matrices(args.matrix_dir)
        matrices.update({k: v for k, v in loaded.items() if v is not None})

    if args.original_routes is not None and args.candidate_solutions is not None:
        original_routes = import_original_routes(args.original_routes)
        candidate_solution_records = import_candidate_solutions(args.candidate_solutions)

        original_routes_df = build_original_routes_df(original_routes)
        solutions_df = build_candidate_solutions_df(candidate_solution_records, original_routes)
        solutions_df = add_route_metrics(solutions_df, matrices)

        export_outputs(args.solution_output_dir, matrices, original_routes_df, solutions_df)

        logger.info('Exported route-format outputs to %s', args.solution_output_dir)
        logger.info('Original routes loaded: %s', len(original_routes_df))
        logger.info('Candidate solutions loaded: %s', len(solutions_df))
    elif args.original_routes is not None or args.candidate_solutions is not None:
        raise ValueError('Provide both --original-routes and --candidate-solutions together.')


if __name__ == '__main__':
    main()


# =========================================================
# ORIGINAL MTA ROUTE EXPORT (OFFICIAL LIVE BUS LAYER)
# =========================================================

MTA_BUS_LINES_LAYER_URL = (
    "https://mdgeodata.md.gov/imap/rest/services/Transportation/MD_Transit/FeatureServer/10/query"
)

def fetch_original_mta_routes_geojson() -> dict[str, Any]:
    """
    Pull the current official MTA Maryland bus lines from the MD iMAP ArcGIS layer
    and return them as GeoJSON. One feature corresponds to one published route line.
    """
    params = {
        "where": "1=1",
        "outFields": "OBJECTID,Route_Name,Route_Type,Route_Number,Distribution_Policy,Shape__Length",
        "returnGeometry": "true",
        "outSR": "4326",
        "f": "geojson",
    }
    request_url = MTA_BUS_LINES_LAYER_URL + "?" + urllib.parse.urlencode(params)
    raw = _download_text(request_url, timeout=60)
    payload = json.loads(raw)

    if "features" not in payload:
        raise ValueError("MTA route query did not return GeoJSON features.")
    return payload


def export_original_mta_routes_csv(
    summary_csv: str = "original_mta_routes.csv",
    vertices_csv: str = "original_mta_route_vertices.csv",
    geojson_path: str = "original_mta_routes.geojson",
) -> tuple[Path, Path, Path]:
    """
    Export:
      1) one row per official MTA route line
      2) one row per ordered vertex along each route geometry
      3) the full GeoJSON for mapping / later tract assignment
    """
    payload = fetch_original_mta_routes_geojson()
    features = payload.get("features", [])
    if not features:
        raise ValueError("No MTA routes were returned from the official layer.")

    route_rows: list[dict[str, Any]] = []
    vertex_rows: list[dict[str, Any]] = []

    for feature_idx, feature in enumerate(features, start=1):
        props = feature.get("properties", {}) or {}
        geom = feature.get("geometry", {}) or {}
        route_number = props.get("Route_Number")
        route_name = props.get("Route_Name")
        route_type = props.get("Route_Type")
        distribution_policy = props.get("Distribution_Policy")
        shape_length = props.get("Shape__Length")
        objectid = props.get("OBJECTID")

        route_key = f"{route_number} | {route_type}" if route_number or route_type else f"route_{feature_idx}"

        route_rows.append({
            "route_key": route_key,
            "objectid": objectid,
            "route_number": route_number,
            "route_name": route_name,
            "route_type": route_type,
            "distribution_policy": distribution_policy,
            "shape_length": shape_length,
            "geometry_type": geom.get("type"),
        })

        geometry_type = geom.get("type")
        coordinates = geom.get("coordinates", [])

        if geometry_type == "LineString":
            for vertex_order, coord in enumerate(coordinates, start=1):
                if len(coord) < 2:
                    continue
                vertex_rows.append({
                    "route_key": route_key,
                    "objectid": objectid,
                    "route_number": route_number,
                    "route_name": route_name,
                    "route_type": route_type,
                    "part_order": 1,
                    "vertex_order": vertex_order,
                    "lon": coord[0],
                    "lat": coord[1],
                })

        elif geometry_type == "MultiLineString":
            for part_order, part in enumerate(coordinates, start=1):
                for vertex_order, coord in enumerate(part, start=1):
                    if len(coord) < 2:
                        continue
                    vertex_rows.append({
                        "route_key": route_key,
                        "objectid": objectid,
                        "route_number": route_number,
                        "route_name": route_name,
                        "route_type": route_type,
                        "part_order": part_order,
                        "vertex_order": vertex_order,
                        "lon": coord[0],
                        "lat": coord[1],
                    })

    routes_df = pd.DataFrame(route_rows).sort_values(
        ["route_number", "route_type", "objectid"],
        na_position="last"
    ).reset_index(drop=True)

    vertices_df = pd.DataFrame(vertex_rows).sort_values(
        ["route_number", "route_type", "objectid", "part_order", "vertex_order"],
        na_position="last"
    ).reset_index(drop=True)

    summary_out = safe_to_csv(routes_df, summary_csv, index=False)
    vertices_out = safe_to_csv(vertices_df, vertices_csv, index=False)
    geojson_out = safe_write_json(payload, geojson_path)

    logger.info("Saved original MTA routes summary to %s", summary_out)
    logger.info("Saved original MTA route vertices to %s", vertices_out)
    logger.info("Saved original MTA route GeoJSON to %s", geojson_out)

    return summary_out, vertices_out, geojson_out


# Run manually with:
# export_original_mta_routes_csv()
