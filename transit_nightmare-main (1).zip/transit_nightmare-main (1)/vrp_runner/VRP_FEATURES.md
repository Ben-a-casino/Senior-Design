## Delta-based child routes & tract-centroid GUI

This document explains the delta-based "child route" features and the built-in GUI
for exploring them, built on top of the standard VRP Runner API.

---

## Concepts

- **Base route**: The original stop set from `stops.csv` (typically: depot, `pickup_*`
  census-tract centroids with demand, and `school_*` destinations).
- **Child route**: A variant of the base route where some pickup stop coordinates
  are moved slightly, represented as a list of **deltas**:
  - Each stop has a `(d_lat, d_lon)` offset.
  - The original route corresponds to all zeros.
  - Only a limited number of pickups are allowed to move, and only within a capped distance.

The intent is to explore "nearby" routing patterns without departing too far from the
underlying census-tract geography.

---

## New API fields on `POST /vrp/solve`

All of these live on the existing `SolveRequest` body.

- **Child route deltas**
  - `use_child_route_deltas: bool`
    - When `true`, compute a child route by perturbing **only stops whose id starts
      with `"pickup_"`** (e.g. `pickup_24510010100`).
    - Depot and `school_*` stops remain fixed.
  - `max_deltas: int`
    - Upper bound on how many pickup stops may receive a non-zero delta.
  - `max_offset_meters: float`
    - Upper bound on the size of the perturbation per moved stop (in both north/south
      and east/west directions).
  - `delta_seed: Optional[int]`
    - Optional random seed for reproducible delta patterns.

- **Constrain perturbed pickups to their tract**
  - `constrain_deltas_to_tracts: bool`
    - When `true`, each moved pickup must remain inside its corresponding tract
      polygon, based on the tract ID encoded in the stop id:
      `pickup_<TRACT_ID>`.
  - `tracts_file: Optional[str]`
    - Path to a tract shapefile/GeoJSON **relative to `DATA_DIR`** (e.g.
      `"shapes/census_tracts/census_tracts.geojson"`).
  - `tract_id_field: str` (default `"auto"`)
    - Column in the tract file that matches `<TRACT_ID>`. When `"auto"`, the code
      tries the following common names in order:
      - `GEOID`, `geoid`, `GEOID10`, `GEOID20`, `TRACTCE`, `tract_id`, `TRACT_ID`, `TRACT`
      - If none match, the API returns a 400 with the available columns listed.
  - `max_resample_attempts: int` (default `25`)
    - When constraining to tracts, each chosen pickup is perturbed repeatedly until
      the moved point falls inside the polygon, up to this many attempts.
    - If all attempts fail, the stop is left unchanged (zero delta).

---

## Response metadata

When deltas are enabled, the `SolveResponse.meta` dictionary includes a
`child_route_deltas` object with extra information:

```json
{
  "objective": 12345.67,
  "routes": [ /* ... */ ],
  "meta": {
    "distance_mode": "haversine",
    "depot_id": "depot",
    "num_stops": 42,
    "child_route_deltas": {
      "enabled": true,
      "max_deltas": 10,
      "max_offset_meters": 150.0,
      "delta_seed": 42,

      "constrain_deltas_to_tracts": true,
      "tracts_file": "shapes/census_tracts/census_tracts.geojson",
      "tract_id_field": "GEOID",
      "max_resample_attempts": 25,
      "constraint_stats": {
        "chosen": 10,
        "missing_tract_geom": 0,
        "resample_failures": 1,
        "applied": 9
      },

      "delta_count_nonzero": 9,
      "deltas": [
        {"d_lat": 0.0, "d_lon": 0.0},
        {"d_lat": 0.00012, "d_lon": -0.00034},
        /* ... one entry per stop ... */
      ]
    }
  }
}
```

This makes it possible to:

- Inspect how many pickups were actually moved.
- See whether any tracts were missing or failed the "inside polygon" constraint.
- Reconstruct the exact child route given the base `stops.csv` and the `deltas` list.

---

## Example solve requests

### 1. Baseline (no deltas)

```bash
curl -X POST "http://localhost:8000/vrp/solve" ^
  -H "Content-Type: application/json" ^
  -d "{\"stops_csv\":\"inputs/stops.csv\",\"num_vehicles\":4,\"vehicle_capacity\":80,\"time_limit_seconds\":15}"
```

### 2. Perturb pickup centroids only

```bash
curl -X POST "http://localhost:8000/vrp/solve" ^
  -H "Content-Type: application/json" ^
  -d "{
    \"stops_csv\": \"inputs/stops.csv\",
    \"num_vehicles\": 4,
    \"vehicle_capacity\": 80,
    \"time_limit_seconds\": 15,

    \"use_child_route_deltas\": true,
    \"max_deltas\": 10,
    \"max_offset_meters\": 150,
    \"delta_seed\": 42
  }"
```

### 3. Perturb + keep inside tract polygons

```bash
curl -X POST "http://localhost:8000/vrp/solve" ^
  -H "Content-Type: application/json" ^
  -d "{
    \"stops_csv\": \"inputs/stops.csv\",
    \"num_vehicles\": 4,
    \"vehicle_capacity\": 80,
    \"time_limit_seconds\": 15,

    \"use_child_route_deltas\": true,
    \"max_deltas\": 10,
    \"max_offset_meters\": 150,
    \"delta_seed\": 42,

    \"constrain_deltas_to_tracts\": true,
    \"tracts_file\": \"shapes/census_tracts/census_tracts.geojson\"
  }"
```

---

## Built-in GUI (`/ui/`)

The VRP Runner API now includes a lightweight browser GUI for running solves and
visualizing delta-based child routes on a map.

- **Endpoint**: `GET /ui/`
- **Backing code**: `api/routers/ui.py`
- **Map**: Leaflet + OpenStreetMap tiles
  - Each vehicle's route is drawn as a colored polyline.
  - Stops are shown as small markers:
    - `pickup_*` (tract centroids) in blue
    - `school_*` in yellow
    - depot/other in green

### Starting the GUI on Windows

From `vrp_runner/`:

```powershell
.\run_vrp_server.ps1
```

This script will:

1. Create/activate a `.venv` if needed.
2. Install `requirements.txt`.
3. Start the FastAPI app with uvicorn (default port 8000).
4. Open your default browser to `http://localhost:8000/ui/`.

### GUI features

- Form fields for:
  - `stops_csv`, `num_vehicles`, `vehicle_capacity`, `time_limit_seconds`, `depot_id`.
  - All delta-related options (`max_deltas`, `max_offset_meters`, `delta_seed`).
  - Tract constraints (`constrain_deltas_to_tracts`, `tracts_file`, `tract_id_field`, `max_resample_attempts`).
- **File browser** backed by `GET /data/list`:
  - "Browse" buttons for both `stops_csv` and `tracts_file`.
  - Click folders to navigate, click a file to select it.
- **Results panel**:
  - Objective and route count.
  - Per-vehicle route summary text.
  - Raw JSON from `POST /vrp/solve`.
  - Leaflet map showing the solved routes and stops.
- **Copy curl**:
  - "Copy curl" button generates a Windows-friendly `curl` command that
    reproduces the current form inputs.

---

## When to use these features

The delta-based child route and GUI features are especially useful when you want to:

- Experiment with how small geographic adjustments to pickup locations affect:
  - total distance,
  - vehicle loads,
  - coverage.
- Keep changes realistic by:
  - moving at most a fixed number of tracts,
  - limiting movement to a small radius,
  - staying inside each tract's polygon.
- Communicate routing scenarios visually (e.g., for stories, internal demos,
  or interactive exploration) without having to write additional plotting code.

