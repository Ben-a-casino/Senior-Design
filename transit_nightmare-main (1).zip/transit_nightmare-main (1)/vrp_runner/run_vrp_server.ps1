Param(
    [int]$Port = 8000
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Move to script directory (repo root for vrp_runner)
Set-Location -Path $PSScriptRoot

Write-Host "=== VRP Runner setup ===" -ForegroundColor Cyan

# Create virtual environment if needed
$venvPath = Join-Path $PSScriptRoot ".venv"
if (-not (Test-Path $venvPath)) {
    Write-Host "Creating virtual environment at .venv..." -ForegroundColor Yellow
    python -m venv .venv
}

# Activate venv
$activateScript = Join-Path $venvPath "Scripts\Activate.ps1"
if (-not (Test-Path $activateScript)) {
    Write-Error "Could not find venv activation script at $activateScript"
    exit 1
}

Write-Host "Activating virtual environment..." -ForegroundColor Yellow
. $activateScript

# Install dependencies
if (Test-Path "requirements.txt") {
    Write-Host "Installing Python dependencies from requirements.txt..." -ForegroundColor Yellow
    pip install --upgrade pip
    pip install -r requirements.txt
} else {
    Write-Error "requirements.txt not found in $PSScriptRoot"
    exit 1
}

# Run the FastAPI app with uvicorn
Write-Host "Starting VRP Runner API on port $Port..." -ForegroundColor Cyan
Write-Host "Opening browser to http://localhost:$Port/ui/ ..." -ForegroundColor Green

# Launch default browser to the UI
Start-Process "http://localhost:$Port/ui/"

uvicorn api.main:app --reload --port $Port

