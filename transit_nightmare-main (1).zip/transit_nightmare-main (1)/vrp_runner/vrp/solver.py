from __future__ import annotations
from typing import List, Optional, Dict, Any
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

from api.schemas import Stop, SolveResponse, RouteOut
from vrp.distances import build_haversine_matrix, load_matrix_csv

def solve_vrp(
    stops: List[Stop],
    depot_id: Optional[str],
    num_vehicles: int,
    vehicle_capacity: int,
    time_limit_seconds: int,
    distance_mode: str = "haversine",
    distance_matrix_file: Optional[str] = None,
) -> SolveResponse:
    # index mapping
    id_to_index = {s.id: i for i, s in enumerate(stops)}
    depot_index = id_to_index.get(depot_id, 0) if depot_id else 0

    demands = [s.demand for s in stops]

    if distance_mode == "haversine":
        dist = build_haversine_matrix(stops)
    elif distance_mode == "matrix_csv":
        if not distance_matrix_file:
            raise ValueError("distance_matrix_file required for matrix_csv mode.")
        dist = load_matrix_csv(distance_matrix_file, stops)
    else:
        raise ValueError(f"Unknown distance_mode: {distance_mode}")

    manager = pywrapcp.RoutingIndexManager(len(stops), num_vehicles, depot_index)
    routing = pywrapcp.RoutingModel(manager)

    def distance_cb(from_index: int, to_index: int) -> int:
        f = manager.IndexToNode(from_index)
        t = manager.IndexToNode(to_index)
        return dist[f][t]

    transit_cb_index = routing.RegisterTransitCallback(distance_cb)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_cb_index)

    def demand_cb(from_index: int) -> int:
        f = manager.IndexToNode(from_index)
        return demands[f]

    demand_cb_index = routing.RegisterUnaryTransitCallback(demand_cb)
    routing.AddDimensionWithVehicleCapacity(
        demand_cb_index,
        0,  # slack
        [vehicle_capacity] * num_vehicles,
        True,
        "Capacity",
    )

    search_params = pywrapcp.DefaultRoutingSearchParameters()
    search_params.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    search_params.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    search_params.time_limit.FromSeconds(time_limit_seconds)

    solution = routing.SolveWithParameters(search_params)
    if not solution:
        return SolveResponse(objective=float("inf"), routes=[], meta={"status": "no_solution"})

    routes_out: List[RouteOut] = []
    total_obj = solution.ObjectiveValue()

    for v in range(num_vehicles):
        index = routing.Start(v)
        route_ids = []
        route_dist = 0
        route_load = 0

        while not routing.IsEnd(index):
            node = manager.IndexToNode(index)
            route_ids.append(stops[node].id)
            route_load += demands[node]
            next_index = solution.Value(routing.NextVar(index))
            route_dist += distance_cb(index, next_index)
            index = next_index

        # add end node
        node = manager.IndexToNode(index)
        route_ids.append(stops[node].id)

        # omit empty routes (just depot->depot)
        if len(route_ids) <= 2:
            continue

        routes_out.append(RouteOut(
            vehicle=v,
            stop_ids=route_ids,
            load=route_load,
            distance=float(route_dist),
        ))

    return SolveResponse(
        objective=float(total_obj),
        routes=routes_out,
        meta={
            "distance_mode": distance_mode,
            "depot_id": stops[depot_index].id,
            "num_stops": len(stops),
        },
    )

