from __future__ import annotations
from typing import List, Dict, Tuple, Optional
import math
import pandas as pd
from api.schemas import Stop

def haversine_meters(a: Stop, b: Stop) -> float:
    R = 6371000.0
    lat1 = math.radians(a.lat)
    lon1 = math.radians(a.lon)
    lat2 = math.radians(b.lat)
    lon2 = math.radians(b.lon)

    dlat = lat2 - lat1
    dlon = lon2 - lon1
    x = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2 * R * math.asin(math.sqrt(x))

def build_haversine_matrix(stops: List[Stop]) -> List[List[int]]:
    n = len(stops)
    m = [[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            m[i][j] = int(round(haversine_meters(stops[i], stops[j])))
    return m

def load_matrix_csv(path: str, stops: List[Stop]) -> List[List[int]]:
    """
    CSV format expected:
      - either a square matrix with header row/col = stop ids
      - or long format: from_id,to_id,distance_meters
    """
    df = pd.read_csv(path)

    ids = [s.id for s in stops]
    idx = {sid: i for i, sid in enumerate(ids)}
    n = len(ids)

    # long format
    if {"from_id", "to_id", "distance_meters"}.issubset(df.columns):
        m = [[0]*n for _ in range(n)]
        for _, r in df.iterrows():
            fi = idx[str(r["from_id"])]
            ti = idx[str(r["to_id"])]
            m[fi][ti] = int(r["distance_meters"])
        return m

    # wide square format
    if df.columns[0] in ("id", "stop_id"):
        df = df.set_index(df.columns[0])

    m = [[0]*n for _ in range(n)]
    for i, sid_i in enumerate(ids):
        for j, sid_j in enumerate(ids):
            if sid_i == sid_j:
                continue
            m[i][j] = int(df.loc[sid_i, sid_j])
    return m

