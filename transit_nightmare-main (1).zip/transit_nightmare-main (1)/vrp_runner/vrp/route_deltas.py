from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import List, Sequence, Tuple, Optional, Dict

from api.schemas import Stop


@dataclass
class StopDelta:
    """
    Delta on a stop's geographic location, relative to the original MTA stop.

    The **base route** is implicitly all zeros:
        d_lat = 0, d_lon = 0 for every stop.

    A child route is represented as a list of these deltas with (0, 0) meaning
    "use the original stop location".
    """

    d_lat: float = 0.0
    d_lon: float = 0.0


def _meters_to_latlon_delta(
    north_m: float,
    east_m: float,
    at_lat_deg: float,
) -> Tuple[float, float]:
    """
    Convert local north/east offsets in meters into approximate lat/lon deltas.

    This uses a simple spherical Earth approximation which is more than
    sufficient for the small perturbations we allow on MTA stops.
    """
    # Approximate meters per degree latitude and longitude
    meters_per_deg_lat = 111_320.0
    # meters per degree longitude shrinks with latitude
    meters_per_deg_lon = (
        111_320.0 * math.cos(math.radians(at_lat_deg)) or 1e-9
    )

    d_lat = north_m / meters_per_deg_lat
    d_lon = east_m / meters_per_deg_lon
    return d_lat, d_lon


def generate_route_deltas(
    base_stops: Sequence[Stop],
    max_deltas: int,
    max_offset_meters: float,
    rng: Optional[random.Random] = None,
) -> List[StopDelta]:
    """
    Generate a list of `StopDelta` objects for a child route.

    - The returned list always has the same length as `base_stops`.
    - The original MTA route corresponds to **all zeros**.
    - At most `max_deltas` stops will have non‑zero deltas, which prevents
      too much route drift / variation.
    - Each non‑zero delta is bounded by `max_offset_meters` in both the
      north/south and east/west directions.
    """
    if rng is None:
        rng = random.Random()

    n = len(base_stops)
    deltas: List[StopDelta] = [StopDelta() for _ in range(n)]

    if n == 0 or max_deltas <= 0 or max_offset_meters <= 0:
        return deltas

    # Choose which stops will be perturbed, capped by both n and max_deltas.
    k = min(max_deltas, n)
    chosen_indices = rng.sample(range(n), k)

    for idx in chosen_indices:
        base = base_stops[idx]

        # Draw a random offset in a square of side 2 * max_offset_meters.
        north_m = rng.uniform(-max_offset_meters, max_offset_meters)
        east_m = rng.uniform(-max_offset_meters, max_offset_meters)

        d_lat, d_lon = _meters_to_latlon_delta(
            north_m=north_m,
            east_m=east_m,
            at_lat_deg=base.lat,
        )

        deltas[idx] = StopDelta(d_lat=d_lat, d_lon=d_lon)

    return deltas


def generate_route_deltas_for_indices(
    base_stops: Sequence[Stop],
    indices: Sequence[int],
    max_deltas: int,
    max_offset_meters: float,
    rng: Optional[random.Random] = None,
) -> List[StopDelta]:
    """
    Like `generate_route_deltas`, but only allows non-zero deltas for the provided
    `indices` (e.g. only `pickup_*` tract-centroid stops).
    """
    if rng is None:
        rng = random.Random()

    n = len(base_stops)
    deltas: List[StopDelta] = [StopDelta() for _ in range(n)]

    allowed = [i for i in indices if 0 <= i < n]
    if not allowed or max_deltas <= 0 or max_offset_meters <= 0:
        return deltas

    k = min(max_deltas, len(allowed))
    chosen_indices = rng.sample(allowed, k)

    for idx in chosen_indices:
        base = base_stops[idx]

        north_m = rng.uniform(-max_offset_meters, max_offset_meters)
        east_m = rng.uniform(-max_offset_meters, max_offset_meters)

        d_lat, d_lon = _meters_to_latlon_delta(
            north_m=north_m,
            east_m=east_m,
            at_lat_deg=base.lat,
        )

        deltas[idx] = StopDelta(d_lat=d_lat, d_lon=d_lon)

    return deltas


def apply_route_deltas(
    base_stops: Sequence[Stop],
    deltas: Sequence[StopDelta],
) -> List[Stop]:
    """
    Apply a list of `StopDelta` objects to a base route to create a child route.

    - `base_stops` and `deltas` must have the same length.
    - Stops with a (0, 0) delta are left unchanged.
    """
    if len(base_stops) != len(deltas):
        raise ValueError("base_stops and deltas must have the same length")

    out: List[Stop] = []
    for stop, delta in zip(base_stops, deltas):
        out.append(
            Stop(
                id=stop.id,
                lat=stop.lat + delta.d_lat,
                lon=stop.lon + delta.d_lon,
                demand=stop.demand,
            )
        )

    return out


def make_child_route(
    base_stops: Sequence[Stop],
    max_deltas: int,
    max_offset_meters: float,
    rng: Optional[random.Random] = None,
) -> Tuple[List[Stop], List[StopDelta]]:
    """
    Convenience helper to produce a child route and its delta representation.

    Returns:
        (child_stops, deltas)

    Where:
        - `deltas` is the sparse (mostly‑zero) list of `StopDelta` describing
          how the child deviates from the original MTA route.
        - `child_stops` is the concrete list of `Stop` objects with updated
          lat/lon values.
    """
    deltas = generate_route_deltas(
        base_stops=base_stops,
        max_deltas=max_deltas,
        max_offset_meters=max_offset_meters,
        rng=rng,
    )
    child_stops = apply_route_deltas(base_stops, deltas)
    return child_stops, deltas


def make_child_route_for_indices(
    base_stops: Sequence[Stop],
    indices: Sequence[int],
    max_deltas: int,
    max_offset_meters: float,
    rng: Optional[random.Random] = None,
) -> Tuple[List[Stop], List[StopDelta]]:
    """
    Convenience helper for the common case where only a subset of stops should
    be perturbed (e.g. only census-tract centroid pickup points).
    """
    deltas = generate_route_deltas_for_indices(
        base_stops=base_stops,
        indices=indices,
        max_deltas=max_deltas,
        max_offset_meters=max_offset_meters,
        rng=rng,
    )
    child_stops = apply_route_deltas(base_stops, deltas)
    return child_stops, deltas


def make_child_route_for_pickup_tracts_constrained(
    base_stops: Sequence[Stop],
    max_deltas: int,
    max_offset_meters: float,
    tracts_file_abs: str,
    tract_id_field: str = "auto",
    rng: Optional[random.Random] = None,
    max_resample_attempts: int = 25,
) -> Tuple[List[Stop], List[StopDelta], Dict[str, int]]:
    """
    Create a child route by perturbing only `pickup_<TRACT_ID>` stops, while
    ensuring the moved point remains inside that tract polygon.

    Returns:
        (child_stops, deltas, stats)

    Notes:
        - Requires geopandas + shapely at runtime.
        - If a tract is missing or a valid in-tract perturbation can't be found
          within `max_resample_attempts`, that stop is left unchanged (delta=0).
    """
    if rng is None:
        rng = random.Random()

    try:
        import geopandas as gpd
        from shapely.geometry import Point
    except Exception as e:  # pragma: no cover
        raise RuntimeError(
            "geopandas/shapely required for constrain_deltas_to_tracts"
        ) from e

    gdf = gpd.read_file(tracts_file_abs)
    if gdf.crs is None or getattr(gdf.crs, "to_epsg", lambda: None)() != 4326:
        gdf = gdf.to_crs(epsg=4326)

    if not tract_id_field or str(tract_id_field).lower() == "auto":
        candidates = [
            "GEOID",
            "geoid",
            "GEOID10",
            "GEOID20",
            "TRACTCE",
            "tract_id",
            "TRACT_ID",
            "TRACT",
        ]
        tract_id_field = next((c for c in candidates if c in gdf.columns), "")

    if tract_id_field not in gdf.columns:
        raise ValueError(
            "Could not auto-detect tract id field. "
            f"Pass tract_id_field explicitly. Available columns: {sorted(map(str, gdf.columns))}"
        )

    # Build tract_id -> polygon mapping
    tract_geom: Dict[str, object] = {}
    for _, row in gdf.iterrows():
        tid = str(row[tract_id_field])
        geom = row.get("geometry", None)
        if geom is not None and not getattr(geom, "is_empty", False):
            tract_geom[tid] = geom

    pickup_indices = []
    pickup_tract_ids: Dict[int, str] = {}
    for i, s in enumerate(base_stops):
        sid = str(s.id)
        if not sid.startswith("pickup_"):
            continue
        tid = sid[len("pickup_") :]
        pickup_indices.append(i)
        pickup_tract_ids[i] = tid

    # Choose which pickup tracts get perturbed
    chosen = rng.sample(pickup_indices, min(max_deltas, len(pickup_indices))) if (max_deltas > 0) else []
    deltas: List[StopDelta] = [StopDelta() for _ in range(len(base_stops))]

    stats = {
        "chosen": len(chosen),
        "missing_tract_geom": 0,
        "resample_failures": 0,
        "applied": 0,
    }

    for idx in chosen:
        tid = pickup_tract_ids.get(idx, "")
        geom = tract_geom.get(tid)
        if geom is None:
            stats["missing_tract_geom"] += 1
            continue

        base = base_stops[idx]
        ok = False

        # Try multiple random offsets until we land inside the polygon
        for _ in range(max_resample_attempts if max_resample_attempts > 0 else 0):
            north_m = rng.uniform(-max_offset_meters, max_offset_meters)
            east_m = rng.uniform(-max_offset_meters, max_offset_meters)
            d_lat, d_lon = _meters_to_latlon_delta(
                north_m=north_m,
                east_m=east_m,
                at_lat_deg=base.lat,
            )
            p = Point(base.lon + d_lon, base.lat + d_lat)
            if geom.contains(p):
                deltas[idx] = StopDelta(d_lat=d_lat, d_lon=d_lon)
                ok = True
                break

        if not ok:
            stats["resample_failures"] += 1
            continue

        stats["applied"] += 1

    child_stops = apply_route_deltas(base_stops, deltas)
    return child_stops, deltas, stats

