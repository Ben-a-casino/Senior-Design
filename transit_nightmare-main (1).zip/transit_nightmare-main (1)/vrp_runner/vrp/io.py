from __future__ import annotations
from typing import List, Optional
from pathlib import Path
import pandas as pd
from api.schemas import Stop

def load_stops(
    data_dir: str,
    stops: Optional[List[Stop]],
    stops_csv: Optional[str],
) -> List[Stop]:
    if stops is not None:
        return stops

    if not stops_csv:
        raise ValueError("Provide either 'stops' or 'stops_csv'.")

    base = Path(data_dir).resolve()
    fpath = (base / stops_csv).resolve()
    if not str(fpath).startswith(str(base)):
        raise ValueError("stops_csv must be inside DATA_DIR.")
    if not fpath.exists():
        raise FileNotFoundError(f"Stops file not found: {fpath}")

    df = pd.read_csv(fpath)
    required = {"id", "lat", "lon"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Stops CSV missing columns: {sorted(missing)}")

    if "demand" not in df.columns:
        df["demand"] = 0

    out = []
    for _, r in df.iterrows():
        out.append(Stop(
            id=str(r["id"]),
            lat=float(r["lat"]),
            lon=float(r["lon"]),
            demand=int(r["demand"]),
        ))
    return out

