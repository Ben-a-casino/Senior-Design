# Transit Data Extraction Scripts

Scripts to extract data from the transit_nightmare repository and prepare it for the VRP solver.

## Quick Start

### 1. Install Dependencies

```bash
pip install -r ../requirements.txt
```

### 2. Configure

Copy the example configuration:

```bash
cp config.example.yaml config.yaml
```

Edit `config.yaml` with your paths:
- `transit_nightmare_dir`: Path to the transit_nightmare repository
- `output_dir`: Local output directory
- `onedrive.local_sync_path`: Your OneDrive sync folder path

### 3. Run Extraction

**Simple method (recommended):**
```bash
python sync_transit_data.py
```

**Advanced method (more control):**
```bash
python extract_transit_data.py \
  --transit-dir ../transit_nightmare-main \
  --output-dir ./transit_nightmare_data \
  --onedrive-path "C:/Users/YOU/OneDrive/transit_nightmare_data/inputs/stops.csv" \
  --include-bus-stops
```

## Scripts

### `sync_transit_data.py`

Simplified wrapper that uses a YAML configuration file. Recommended for most users.

**Usage:**
```bash
python sync_transit_data.py [--config config.yaml] [--skip-upload]
```

**Options:**
- `--config`: Path to YAML config file (default: `config.yaml`)
- `--skip-upload`: Skip OneDrive upload, just generate files locally

### `extract_transit_data.py`

Full-featured extraction script with command-line arguments.

**Usage:**
```bash
python extract_transit_data.py \
  --transit-dir PATH \
  --output-dir PATH \
  [--onedrive-path PATH] \
  [--use-graph-api] \
  [--include-bus-stops] \
  [--depot-id ID]
```

**Options:**
- `--transit-dir`: Path to transit_nightmare repository root
- `--output-dir`: Output directory for generated files
- `--onedrive-path`: OneDrive path (local sync folder or OneDrive item path)
- `--use-graph-api`: Use Microsoft Graph API instead of local sync
- `--include-bus-stops`: Include bus stops in output
- `--depot-id`: ID of depot school (default: first school)

### `fetch_onedrive_device_code.py`

OneDrive integration via Microsoft Graph API (device code flow).

**Usage:**
```bash
export TENANT_ID="your-tenant-id"
export CLIENT_ID="your-client-id"
export ITEM_PATH="/transit_nightmare_data/inputs/stops.csv"
export OUT_FILE="/path/to/local/stops.csv"

python fetch_onedrive_device_code.py
```

## Data Sources

The scripts extract data from multiple sources in the transit_nightmare repository:

### Schools
- **Source**: `data/shapes/school_parcels/school_parcels.geojson` (default)
- **Alternative**: `data/shapes/city_schools/Baltimore_City_Schools.shp`
- **Filter**: Middle and high schools (grades 6-12)

### Student Locations
- **Enrollment**: `data/home_tracts/REVISED Banner Request-Enroll by Prog and Tract-2024.08.08.xlsx`
- **Pickup Points**: 
  - Sampled grid points: `data/shapes/bmore_grid_sampled_01_27.geojson` (preferred)
  - Census tract centers: From census tract shapefiles

### Bus Stops (Optional)
- **Source**: `data/setup/Baltimore_Region_Public_Transit_(stops).csv`

## Output Format

The scripts generate `stops.csv` with the following format:

```csv
id,lat,lon,demand
depot,39.2904,-76.6122,0
pickup_tract_12345,39.2950,-76.6100,10
school_001,39.2850,-76.6200,0
...
```

**Columns:**
- `id`: Unique identifier for the stop
- `lat`: Latitude (WGS84)
- `lon`: Longitude (WGS84)
- `demand`: Number of students to pick up (0 for schools/depots)

**Stop Types:**
- `depot`: Starting/ending point (first school by default)
- `pickup_*`: Student pickup locations (census tracts)
- `school_*`: School destinations
- `bus_stop_*`: Bus stops (if included)

## OneDrive Integration

### Option A: Local Sync (Recommended)

1. Set up OneDrive sync on your machine
2. Configure `onedrive.local_sync_path` in `config.yaml`
3. Run the script - it will copy files to your OneDrive folder
4. OneDrive will automatically sync to the cloud

### Option B: Microsoft Graph API

1. Register an Azure App with Microsoft Graph API permissions:
   - `Files.ReadWrite.All`
   - `User.Read`
2. Get your `TENANT_ID` and `CLIENT_ID`
3. Set `onedrive.use_graph_api: true` in `config.yaml`
4. Add credentials to `config.yaml` or environment variables
5. Run the script - it will authenticate via device code flow

## Troubleshooting

### "File not found" errors
- Ensure the transit_nightmare repository is downloaded
- Check that data files exist in the expected locations
- Update paths in `config.yaml` if your structure differs

### "geopandas not installed"
```bash
pip install geopandas
```

### "openpyxl not installed"
```bash
pip install openpyxl
```

### OneDrive upload fails
- For local sync: Check that the OneDrive folder path is correct
- For Graph API: Verify credentials and permissions

### No student locations found
- Check that the enrollment Excel file exists
- Verify census tract shapefiles are available
- Try `use_sampled_points: false` to use tract centers instead

## Integration with VRP Runner

After running the extraction script:

1. **Verify output**: Check that `stops.csv` was created in your output directory
2. **Sync to OneDrive**: Ensure the file is in your OneDrive sync folder
3. **Configure VRP Runner**: Set `HOST_DATA_DIR` in `.env` to your OneDrive folder
4. **Start API**: Run `docker compose up --build`
5. **Solve VRP**: Call the API with `stops_csv="inputs/stops.csv"`

## Example Workflow

```bash
# 1. Configure
cp config.example.yaml config.yaml
# Edit config.yaml with your paths

# 2. Extract data
python sync_transit_data.py

# 3. Verify output
cat transit_nightmare_data/inputs/stops.csv | head -10

# 4. Check OneDrive sync (if enabled)
# Files should appear in your OneDrive folder

# 5. Use with VRP Runner
cd ..
docker compose up --build

# 6. Test API
curl -X POST "http://localhost:8000/vrp/solve" \
  -H "Content-Type: application/json" \
  -d '{
    "stops_csv": "inputs/stops.csv",
    "num_vehicles": 4,
    "vehicle_capacity": 80,
    "time_limit_seconds": 15
  }'
```

