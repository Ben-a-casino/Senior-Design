"""
Extract and transform transit_nightmare data for VRP solver.

This script reads data from the transit_nightmare repository and converts it
into the format needed for the VRP runner (stops.csv with id, lat, lon, demand).

Supports multiple data sources:
- School locations (GeoJSON, Shapefile)
- Student enrollment by census tract (Excel, CSV)
- Bus stops (CSV, GTFS)
- Census tract centers (GeoJSON, Shapefile)
"""

import os
import sys
import pandas as pd
import json
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import argparse
from dotenv import load_dotenv

# Try to import optional dependencies
try:
    import geopandas as gpd
    HAS_GEOPANDAS = True
except ImportError:
    HAS_GEOPANDAS = False
    print("Warning: geopandas not installed. Shapefile/GeoJSON support limited.")

try:
    import openpyxl
    HAS_EXCEL = True
except ImportError:
    HAS_EXCEL = False
    print("Warning: openpyxl not installed. Excel file support limited.")


class TransitDataExtractor:
    """Extract and transform transit data for VRP."""
    
    def __init__(self, transit_nightmare_dir: str, output_dir: str):
        """
        Initialize extractor.
        
        Args:
            transit_nightmare_dir: Path to transit_nightmare repository root
            output_dir: Path to output directory (will be synced to OneDrive)
        """
        self.transit_dir = Path(transit_nightmare_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.stops_data = []
        
    def extract_schools(self, 
                       source: str = "geojson",
                       file_path: Optional[str] = None,
                       school_filter: Optional[str] = None) -> pd.DataFrame:
        """
        Extract school locations.
        
        Args:
            source: "geojson", "shapefile", or "csv"
            file_path: Path to school data file (relative to transit_nightmare_dir)
            school_filter: Filter for school types (e.g., "9 - 12|6 - 12|6 - 8|5 - 8")
        
        Returns:
            DataFrame with columns: id, lat, lon, name, type
        """
        if file_path is None:
            if source == "geojson":
                file_path = "data/shapes/school_parcels/school_parcels.geojson"
            elif source == "shapefile":
                file_path = "data/shapes/city_schools/Baltimore_City_Schools.shp"
            else:
                file_path = "data/setup/schools.csv"
        
        full_path = self.transit_dir / file_path
        
        if not full_path.exists():
            print(f"Warning: School file not found: {full_path}")
            return pd.DataFrame()
        
        if source == "geojson" and HAS_GEOPANDAS:
            gdf = gpd.read_file(full_path)
            if 'geometry' in gdf.columns:
                gdf = gdf.to_crs(4326)
                gdf['lon'] = gdf.geometry.x
                gdf['lat'] = gdf.geometry.y
        elif source == "shapefile" and HAS_GEOPANDAS:
            gdf = gpd.read_file(full_path)
            if 'geometry' in gdf.columns:
                gdf = gdf.to_crs(4326)
                gdf['lon'] = gdf.geometry.x
                gdf['lat'] = gdf.geometry.y
        else:
            # CSV fallback
            gdf = pd.read_csv(full_path)
            if 'lat' not in gdf.columns or 'lon' not in gdf.columns:
                print(f"Warning: {file_path} missing lat/lon columns")
                return pd.DataFrame()
        
        # Filter by school type if specified
        if school_filter and 'class' in gdf.columns:
            gdf = gdf[gdf['class'].str.contains(school_filter, na=False, regex=True)]
        
        # Create standardized output
        result = pd.DataFrame()
        result['id'] = gdf.get('school_number', gdf.get('prg_num', 
            gdf.get('id', range(len(gdf)))))
        result['lat'] = gdf['lat']
        result['lon'] = gdf['lon']
        result['name'] = gdf.get('schools_at_parcel', 
            gdf.get('name', gdf.get('program', '')))
        result['type'] = 'school'
        result['demand'] = 0  # Schools are destinations, not pickups
        
        return result
    
    def extract_student_locations(self,
                                  enrollment_file: Optional[str] = None,
                                  census_tract_file: Optional[str] = None,
                                  use_sampled_points: bool = True) -> pd.DataFrame:
        """
        Extract student pickup locations from census tract data.
        
        Args:
            enrollment_file: Path to Excel/CSV with student enrollment by tract
            census_tract_file: Path to census tract shapefile/GeoJSON
            use_sampled_points: If True, use sampled grid points instead of tract centers
        
        Returns:
            DataFrame with columns: id, lat, lon, demand, tract_id
        """
        # Try to find enrollment data
        if enrollment_file is None:
            enrollment_file = "data/home_tracts/REVISED Banner Request-Enroll by Prog and Tract-2024.08.08.xlsx"
        
        enroll_path = self.transit_dir / enrollment_file
        
        if not enroll_path.exists():
            print(f"Warning: Enrollment file not found: {enroll_path}")
            # Try CSV alternative
            csv_path = self.transit_dir / "data" / "output" / "student_enrollment.csv"
            if csv_path.exists():
                enroll_df = pd.read_csv(csv_path)
            else:
                return pd.DataFrame()
        else:
            if HAS_EXCEL and enrollment_file.endswith('.xlsx'):
                enroll_df = pd.read_excel(enroll_path, sheet_name=1, skiprows=5)
            else:
                enroll_df = pd.read_csv(enroll_path)
        
        # Clean column names
        enroll_df.columns = enroll_df.columns.str.lower().str.replace(' ', '_')
        
        # Get census tract centers or sampled points
        if use_sampled_points:
            sampled_file = self.transit_dir / "data" / "shapes" / "bmore_grid_sampled_01_27.geojson"
            if sampled_file.exists() and HAS_GEOPANDAS:
                points_gdf = gpd.read_file(sampled_file)
                points_gdf = points_gdf.to_crs(4326)
                points_gdf['lon'] = points_gdf.geometry.x
                points_gdf['lat'] = points_gdf.geometry.y
            else:
                # Fallback to tract centers
                return self._extract_tract_centers(census_tract_file, enroll_df)
        else:
            return self._extract_tract_centers(census_tract_file, enroll_df)
        
        # Merge enrollment with points
        # This is simplified - actual implementation would need proper tract matching
        result = []
        for idx, row in points_gdf.iterrows():
            tract_id = str(row.get('geoid', row.get('tract_id', f'tract_{idx}')))
            # Get student count for this tract (simplified)
            student_count = 0
            if 'students' in enroll_df.columns or any('x' in str(c) for c in enroll_df.columns):
                # Find matching tract column
                for col in enroll_df.columns:
                    if tract_id in str(col) or str(col).replace('x', '') == tract_id:
                        student_count = enroll_df[col].sum()
                        break
            
            result.append({
                'id': f'pickup_{tract_id}',
                'lat': row['lat'],
                'lon': row['lon'],
                'demand': int(student_count) if student_count > 0 else 1,
                'tract_id': tract_id,
                'type': 'pickup'
            })
        
        return pd.DataFrame(result)
    
    def _extract_tract_centers(self, 
                               tract_file: Optional[str],
                               enroll_df: pd.DataFrame) -> pd.DataFrame:
        """Extract census tract centers as pickup points."""
        if tract_file is None:
            # Try to find tract shapefile
            tract_file = "data/shapes/census_tracts/census_tracts.shp"
        
        tract_path = self.transit_dir / tract_file
        
        if not tract_path.exists() or not HAS_GEOPANDAS:
            print(f"Warning: Census tract file not found: {tract_path}")
            return pd.DataFrame()
        
        gdf = gpd.read_file(tract_path)
        gdf = gdf.to_crs(4326)
        gdf['lon'] = gdf.geometry.centroid.x
        gdf['lat'] = gdf.geometry.centroid.y
        
        result = []
        for idx, row in gdf.iterrows():
            tract_id = str(row.get('GEOID', row.get('geoid', f'tract_{idx}')))
            result.append({
                'id': f'pickup_{tract_id}',
                'lat': row['lat'],
                'lon': row['lon'],
                'demand': 1,  # Default demand
                'tract_id': tract_id,
                'type': 'pickup'
            })
        
        return pd.DataFrame(result)
    
    def extract_bus_stops(self, stops_file: Optional[str] = None) -> pd.DataFrame:
        """
        Extract bus stop locations.
        
        Args:
            stops_file: Path to bus stops CSV/GTFS
        
        Returns:
            DataFrame with columns: id, lat, lon, name, type
        """
        if stops_file is None:
            stops_file = "data/setup/Baltimore_Region_Public_Transit_(stops).csv"
        
        stops_path = self.transit_dir / stops_file
        
        if not stops_path.exists():
            print(f"Warning: Bus stops file not found: {stops_path}")
            return pd.DataFrame()
        
        df = pd.read_csv(stops_path)
        
        # Standardize column names
        df.columns = df.columns.str.lower().str.replace(' ', '_')
        
        # Try to find lat/lon columns
        lat_col = None
        lon_col = None
        
        for col in df.columns:
            if 'lat' in col.lower():
                lat_col = col
            if 'lon' in col.lower() or 'lng' in col.lower() or 'long' in col.lower():
                lon_col = col
        
        if lat_col is None or lon_col is None:
            print(f"Warning: Could not find lat/lon columns in {stops_path}")
            return pd.DataFrame()
        
        result = pd.DataFrame()
        result['id'] = df.get('stop_id', df.get('id', range(len(df))))
        result['lat'] = df[lat_col]
        result['lon'] = df[lon_col]
        result['name'] = df.get('stop_name', df.get('name', ''))
        result['type'] = 'bus_stop'
        result['demand'] = 0
        
        return result
    
    def combine_and_save(self,
                        schools: pd.DataFrame,
                        pickups: pd.DataFrame,
                        bus_stops: Optional[pd.DataFrame] = None,
                        depot_id: Optional[str] = None,
                        output_name: str = "stops.csv") -> str:
        """
        Combine all data sources and save as VRP-ready CSV.
        
        Args:
            schools: School locations DataFrame
            pickups: Student pickup locations DataFrame
            bus_stops: Optional bus stop locations DataFrame
            depot_id: ID of depot (if None, first school is depot)
            output_name: Output filename
        
        Returns:
            Path to saved file
        """
        all_stops = []
        
        # Add depot (first school or specified)
        if not schools.empty:
            if depot_id:
                depot = schools[schools['id'] == depot_id].iloc[0]
            else:
                depot = schools.iloc[0]
            
            all_stops.append({
                'id': str(depot['id']),
                'lat': float(depot['lat']),
                'lon': float(depot['lon']),
                'demand': 0,
                'type': 'depot'
            })
        
        # Add pickups
        if not pickups.empty:
            for _, row in pickups.iterrows():
                all_stops.append({
                    'id': str(row['id']),
                    'lat': float(row['lat']),
                    'lon': float(row['lon']),
                    'demand': int(row['demand']),
                    'type': row.get('type', 'pickup')
                })
        
        # Add other schools (destinations)
        if not schools.empty:
            for _, row in schools.iterrows():
                if str(row['id']) != all_stops[0]['id']:  # Skip depot
                    all_stops.append({
                        'id': str(row['id']),
                        'lat': float(row['lat']),
                        'lon': float(row['lon']),
                        'demand': 0,
                        'type': 'school'
                    })
        
        # Add bus stops if provided
        if bus_stops is not None and not bus_stops.empty:
            for _, row in bus_stops.iterrows():
                all_stops.append({
                    'id': str(row['id']),
                    'lat': float(row['lat']),
                    'lon': float(row['lon']),
                    'demand': 0,
                    'type': 'bus_stop'
                })
        
        # Create DataFrame and save
        output_df = pd.DataFrame(all_stops)
        output_path = self.output_dir / "inputs" / output_name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save with only VRP-required columns
        vrp_df = output_df[['id', 'lat', 'lon', 'demand']].copy()
        vrp_df.to_csv(output_path, index=False)
        
        # Also save full version with metadata
        metadata_path = self.output_dir / "inputs" / f"{output_name.replace('.csv', '_full.csv')}"
        output_df.to_csv(metadata_path, index=False)
        
        print(f"Saved {len(vrp_df)} stops to {output_path}")
        print(f"Saved full data with metadata to {metadata_path}")
        
        return str(output_path)


def upload_to_onedrive(file_path: str, 
                      onedrive_path: str,
                      use_graph_api: bool = False,
                      **graph_kwargs) -> bool:
    """
    Upload file to OneDrive.
    
    Args:
        file_path: Local file path to upload
        onedrive_path: OneDrive path (local sync folder or OneDrive item path)
        use_graph_api: If True, use Microsoft Graph API; else copy to local sync folder
        **graph_kwargs: Graph API credentials (tenant_id, client_id, etc.)
    
    Returns:
        True if successful
    """
    local_path = Path(file_path)
    
    if not local_path.exists():
        print(f"Error: File not found: {file_path}")
        return False
    
    if use_graph_api:
        # Use Graph API upload
        try:
            import sys
            from pathlib import Path
            # Add scripts directory to path
            scripts_dir = Path(__file__).parent
            sys.path.insert(0, str(scripts_dir))
            from fetch_onedrive_device_code import get_token, upload_file_to_onedrive
            
            token = get_token(
                graph_kwargs.get('tenant_id'),
                graph_kwargs.get('client_id'),
                ["Files.ReadWrite.All", "User.Read"]
            )
            
            # Upload file
            drive = graph_kwargs.get('drive', 'me/drive')
            upload_file_to_onedrive(token, drive, onedrive_path, local_path)
            print(f"Uploaded to OneDrive: {onedrive_path}")
            return True
        except Exception as e:
            print(f"Error uploading via Graph API: {e}")
            import traceback
            traceback.print_exc()
            return False
    else:
        # Copy to local OneDrive sync folder
        onedrive_local = Path(onedrive_path)
        onedrive_local.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            import shutil
            shutil.copy2(local_path, onedrive_local)
            print(f"Copied to OneDrive sync folder: {onedrive_local}")
            return True
        except Exception as e:
            print(f"Error copying to OneDrive folder: {e}")
            return False


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Extract transit_nightmare data for VRP solver"
    )
    parser.add_argument(
        "--transit-dir",
        type=str,
        default="../transit_nightmare-main",
        help="Path to transit_nightmare repository root"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./transit_nightmare_data",
        help="Output directory (will sync to OneDrive)"
    )
    parser.add_argument(
        "--onedrive-path",
        type=str,
        help="OneDrive path (local sync folder or OneDrive item path)"
    )
    parser.add_argument(
        "--use-graph-api",
        action="store_true",
        help="Use Microsoft Graph API instead of local sync"
    )
    parser.add_argument(
        "--include-bus-stops",
        action="store_true",
        help="Include bus stops in output"
    )
    parser.add_argument(
        "--depot-id",
        type=str,
        help="ID of depot school (default: first school)"
    )
    
    args = parser.parse_args()
    
    # Load environment variables
    load_dotenv()
    
    # Initialize extractor
    extractor = TransitDataExtractor(
        transit_nightmare_dir=args.transit_dir,
        output_dir=args.output_dir
    )
    
    print("Extracting school locations...")
    schools = extractor.extract_schools(
        source="geojson",
        school_filter="9 - 12|6 - 12|6 - 8|5 - 8"
    )
    
    print("Extracting student pickup locations...")
    pickups = extractor.extract_student_locations(use_sampled_points=True)
    
    bus_stops = None
    if args.include_bus_stops:
        print("Extracting bus stops...")
        bus_stops = extractor.extract_bus_stops()
    
    print("Combining and saving...")
    output_path = extractor.combine_and_save(
        schools=schools,
        pickups=pickups,
        bus_stops=bus_stops,
        depot_id=args.depot_id
    )
    
    # Upload to OneDrive if specified
    if args.onedrive_path:
        upload_to_onedrive(
            file_path=output_path,
            onedrive_path=args.onedrive_path,
            use_graph_api=args.use_graph_api,
            tenant_id=os.getenv("TENANT_ID"),
            client_id=os.getenv("CLIENT_ID")
        )
    
    print(f"\nDone! Output saved to: {output_path}")
    print(f"Use this path in your VRP solver: inputs/stops.csv")


if __name__ == "__main__":
    main()

