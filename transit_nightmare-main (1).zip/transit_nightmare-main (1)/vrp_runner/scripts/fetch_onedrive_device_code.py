import os
import requests
import msal
from pathlib import Path

GRAPH = "https://graph.microsoft.com/v1.0"

def get_token(tenant_id: str, client_id: str, scopes: list[str]) -> str:
    app = msal.PublicClientApplication(
        client_id=client_id,
        authority=f"https://login.microsoftonline.com/{tenant_id}",
    )
    flow = app.initiate_device_flow(scopes=scopes)
    if "user_code" not in flow:
        raise RuntimeError("Failed to create device flow.")

    print(flow["message"])
    result = app.acquire_token_by_device_flow(flow)
    if "access_token" not in result:
        raise RuntimeError(f"Auth failed: {result}")
    return result["access_token"]

def download_item_by_path(token: str, drive: str, item_path: str, out_path: Path):
    """
    drive: "me/drive" or "users/{userPrincipalName}/drive"
    item_path: path inside OneDrive, e.g. "/transit_nightmare_data/inputs/stops.csv"
    """
    url = f"{GRAPH}/{drive}/root:{item_path}:/content"
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, stream=True)
    r.raise_for_status()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=1024 * 1024):
            if chunk:
                f.write(chunk)

def upload_file_to_onedrive(token: str, drive: str, item_path: str, local_file: Path):
    """
    Upload a file to OneDrive.
    
    Args:
        token: Access token from get_token()
        drive: "me/drive" or "users/{userPrincipalName}/drive"
        item_path: Path in OneDrive, e.g. "/transit_nightmare_data/inputs/stops.csv"
        local_file: Local file path to upload
    """
    # Create parent folder if needed
    if "/" in item_path:
        parent_path = "/".join(item_path.split("/")[:-1])
        folder_name = item_path.split("/")[-2] if len(item_path.split("/")) > 1 else ""
        if parent_path:
            # Ensure parent folder exists
            create_folder_url = f"{GRAPH}/{drive}/root:{parent_path}:"
            # Try to get folder, create if doesn't exist
            try:
                requests.get(create_folder_url, headers={"Authorization": f"Bearer {token}"})
            except Exception:
                # Folder might not exist, but that's okay for upload
                pass
    
    # Upload file
    upload_url = f"{GRAPH}/{drive}/root:{item_path}:/content"
    
    with open(local_file, "rb") as f:
        file_content = f.read()
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/octet-stream"
    }
    
    r = requests.put(upload_url, headers=headers, data=file_content)
    r.raise_for_status()
    return r.json()

if __name__ == "__main__":
    tenant = os.environ["TENANT_ID"]
    client = os.environ["CLIENT_ID"]
    scopes = ["Files.Read.All", "User.Read"]

    drive = os.getenv("DRIVE", "me/drive")
    item_path = os.environ["ITEM_PATH"]   # e.g. "/transit_nightmare_data/inputs/stops.csv"
    out_file = Path(os.environ["OUT_FILE"])

    token = get_token(tenant, client, scopes)
    download_item_by_path(token, drive, item_path, out_file)
    print(f"Downloaded to: {out_file}")

