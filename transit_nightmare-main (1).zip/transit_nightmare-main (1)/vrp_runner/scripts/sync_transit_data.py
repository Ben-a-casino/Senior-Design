"""
Simplified script to sync transit_nightmare data to OneDrive.

This is a convenience wrapper around extract_transit_data.py that uses
a YAML configuration file.
"""

import os
import sys
import yaml
from pathlib import Path
from extract_transit_data import TransitDataExtractor, upload_to_onedrive

def load_config(config_path: str = "config.yaml") -> dict:
    """Load configuration from YAML file."""
    config_file = Path(__file__).parent / config_path
    
    if not config_file.exists():
        print(f"Error: Config file not found: {config_file}")
        print(f"Please copy config.example.yaml to {config_path} and update it.")
        sys.exit(1)
    
    with open(config_file, 'r') as f:
        return yaml.safe_load(f)

def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Sync transit_nightmare data to OneDrive for VRP solver"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="Path to configuration file"
    )
    parser.add_argument(
        "--skip-upload",
        action="store_true",
        help="Skip OneDrive upload (just generate files locally)"
    )
    
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Initialize extractor
    extractor = TransitDataExtractor(
        transit_nightmare_dir=config['transit_nightmare_dir'],
        output_dir=config['output_dir']
    )
    
    print("=" * 60)
    print("Transit Nightmare Data Extraction for VRP")
    print("=" * 60)
    
    # Extract schools
    print("\n[1/3] Extracting school locations...")
    school_config = config['data_sources']['schools']
    schools = extractor.extract_schools(
        source=school_config.get('source', 'geojson'),
        file_path=school_config.get('file_path'),
        school_filter=school_config.get('school_filter')
    )
    print(f"  Found {len(schools)} schools")
    
    # Extract student locations
    print("\n[2/3] Extracting student pickup locations...")
    student_config = config['data_sources']['students']
    pickups = extractor.extract_student_locations(
        enrollment_file=student_config.get('enrollment_file'),
        use_sampled_points=student_config.get('use_sampled_points', True)
    )
    print(f"  Found {len(pickups)} pickup locations")
    
    # Extract bus stops (optional)
    bus_stops = None
    if config['data_sources'].get('bus_stops', {}).get('enabled', False):
        print("\n[2.5/3] Extracting bus stops...")
        bus_stops = extractor.extract_bus_stops(
            stops_file=config['data_sources']['bus_stops'].get('file_path')
        )
        print(f"  Found {len(bus_stops)} bus stops")
    
    # Combine and save
    print("\n[3/3] Combining and saving data...")
    vrp_config = config.get('vrp', {})
    output_path = extractor.combine_and_save(
        schools=schools,
        pickups=pickups,
        bus_stops=bus_stops,
        depot_id=vrp_config.get('depot_id'),
        output_name=vrp_config.get('output_filename', 'stops.csv')
    )
    
    # Upload to OneDrive
    if not args.skip_upload and config.get('onedrive', {}).get('enabled', False):
        print("\n[4/4] Uploading to OneDrive...")
        onedrive_config = config['onedrive']
        
        if onedrive_config.get('use_graph_api', False):
            # Use Graph API
            upload_to_onedrive(
                file_path=output_path,
                onedrive_path=f"/transit_nightmare_data/inputs/{vrp_config.get('output_filename', 'stops.csv')}",
                use_graph_api=True,
                tenant_id=onedrive_config.get('tenant_id'),
                client_id=onedrive_config.get('client_id'),
                drive=onedrive_config.get('drive', 'me/drive')
            )
        else:
            # Use local sync
            local_path = Path(onedrive_config['local_sync_path'])
            onedrive_file = local_path / "inputs" / vrp_config.get('output_filename', 'stops.csv')
            upload_to_onedrive(
                file_path=output_path,
                onedrive_path=str(onedrive_file),
                use_graph_api=False
            )
    
    print("\n" + "=" * 60)
    print("Done!")
    print(f"Output saved to: {output_path}")
    print(f"\nTo use with VRP solver:")
    print(f"  1. Ensure your OneDrive folder is synced")
    print(f"  2. Set HOST_DATA_DIR in .env to: {config.get('onedrive', {}).get('local_sync_path', 'YOUR_ONEDRIVE_PATH')}")
    print(f"  3. Run: docker compose up --build")
    print(f"  4. Call: POST /vrp/solve with stops_csv='inputs/stops.csv'")
    print("=" * 60)

if __name__ == "__main__":
    main()

