from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class Stop(BaseModel):
    id: str
    lat: float
    lon: float
    demand: int = 0

class SolveRequest(BaseModel):
    # Either provide stops inline...
    stops: Optional[List[Stop]] = None

    # ...or provide a CSV path relative to DATA_DIR (e.g. "inputs/stops.csv")
    stops_csv: Optional[str] = None

    depot_id: Optional[str] = None  # if None, first stop is depot

    num_vehicles: int = Field(ge=1, default=3)
    vehicle_capacity: int = Field(ge=1, default=100)

    # OR-Tools tuning
    time_limit_seconds: int = Field(ge=1, default=10)

    # Distance options
    distance_mode: Optional[str] = None  # overrides env if provided

    # Optional: generate a child route by perturbing census-tract centroids.
    # When enabled, only stops whose id starts with "pickup_" will be perturbed.
    use_child_route_deltas: bool = False
    max_deltas: int = Field(ge=0, default=0)
    max_offset_meters: float = Field(ge=0, default=0)
    delta_seed: Optional[int] = None

    # Optional: constrain perturbed pickup points to remain inside their
    # corresponding census tract polygon. The tract ID is parsed from stop IDs
    # like "pickup_<TRACT_ID>" and matched against `tract_id_field` in the file.
    constrain_deltas_to_tracts: bool = False
    tracts_file: Optional[str] = None  # path relative to DATA_DIR
    tract_id_field: str = "auto"
    max_resample_attempts: int = Field(ge=0, default=25)

class RouteOut(BaseModel):
    vehicle: int
    stop_ids: List[str]
    load: int
    distance: float

class SolveResponse(BaseModel):
    objective: float
    routes: List[RouteOut]
    meta: Dict[str, Any] = {}

