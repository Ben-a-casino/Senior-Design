import os
import random
from pathlib import Path
from typing import List

from fastapi import APIRouter, HTTPException

from api.schemas import SolveRequest, SolveResponse, Stop
from vrp.io import load_stops
from vrp.solver import solve_vrp
from vrp.route_deltas import (
    make_child_route_for_indices,
    make_child_route_for_pickup_tracts_constrained,
)

router = APIRouter()

DATA_DIR = os.getenv("DATA_DIR", "/data")
DEFAULT_DISTANCE_MODE = os.getenv("DISTANCE_MODE", "haversine")
MATRIX_FILE = os.getenv("DISTANCE_MATRIX_FILE", "")


@router.post("/solve", response_model=SolveResponse)
def solve(req: SolveRequest):
    distance_mode = req.distance_mode or DEFAULT_DISTANCE_MODE

    stops = load_stops(
        data_dir=DATA_DIR,
        stops=req.stops,
        stops_csv=req.stops_csv
    )

    if len(stops) < 2:
        raise HTTPException(400, "Need at least 2 stops (including depot).")

    deltas = None
    delta_stats = None
    if req.use_child_route_deltas and req.max_deltas > 0 and req.max_offset_meters > 0:
        rng = random.Random(req.delta_seed) if req.delta_seed is not None else random.Random()

        if req.constrain_deltas_to_tracts:
            if not req.tracts_file:
                raise HTTPException(400, "tracts_file is required when constrain_deltas_to_tracts=true")

            base = Path(DATA_DIR).resolve()
            tracts_path = (base / req.tracts_file).resolve()
            if not str(tracts_path).startswith(str(base)):
                raise HTTPException(400, "tracts_file must be inside DATA_DIR")
            if not tracts_path.exists():
                raise HTTPException(404, f"tracts_file not found: {req.tracts_file}")

            child_stops, deltas, delta_stats = make_child_route_for_pickup_tracts_constrained(
                base_stops=stops,
                max_deltas=req.max_deltas,
                max_offset_meters=req.max_offset_meters,
                tracts_file_abs=str(tracts_path),
                tract_id_field=req.tract_id_field,
                rng=rng,
                max_resample_attempts=req.max_resample_attempts,
            )
            stops = child_stops
        else:
            pickup_indices = [i for i, s in enumerate(stops) if str(s.id).startswith("pickup_")]
            child_stops, deltas = make_child_route_for_indices(
                base_stops=stops,
                indices=pickup_indices,
                max_deltas=req.max_deltas,
                max_offset_meters=req.max_offset_meters,
                rng=rng,
            )
            stops = child_stops

    resp = solve_vrp(
        stops=stops,
        depot_id=req.depot_id,
        num_vehicles=req.num_vehicles,
        vehicle_capacity=req.vehicle_capacity,
        time_limit_seconds=req.time_limit_seconds,
        distance_mode=distance_mode,
        distance_matrix_file=MATRIX_FILE if distance_mode == "matrix_csv" else None,
    )
    if req.use_child_route_deltas and req.max_deltas > 0 and req.max_offset_meters > 0 and deltas is not None:
        # Attach enough info to reproduce the exact same child route.
        resp.meta = dict(resp.meta or {})
        resp.meta.update({
            "child_route_deltas": {
                "enabled": True,
                "max_deltas": req.max_deltas,
                "max_offset_meters": req.max_offset_meters,
                "delta_seed": req.delta_seed,
                "constrain_deltas_to_tracts": req.constrain_deltas_to_tracts,
                "tracts_file": req.tracts_file,
                "tract_id_field": req.tract_id_field,
                "max_resample_attempts": req.max_resample_attempts,
                "constraint_stats": delta_stats,
                "delta_count_nonzero": sum(1 for d in deltas if (d.d_lat != 0.0 or d.d_lon != 0.0)),
                "deltas": [{"d_lat": d.d_lat, "d_lon": d.d_lon} for d in deltas],
            }
        })
    return resp


@router.get("/stops", response_model=List[Stop])
def get_stops(stops_csv: str):
    """
    Helper for the GUI: return stops for a given CSV (relative to DATA_DIR).
    """
    try:
        stops = load_stops(
            data_dir=DATA_DIR,
            stops=None,
            stops_csv=stops_csv,
        )
    except FileNotFoundError:
        raise HTTPException(404, f"Stops file not found: {stops_csv}")
    except ValueError as e:
        # e.g. bad path or missing columns
        raise HTTPException(400, str(e))
    return stops

