import os
from fastapi import APIRouter, HTTPException
from pathlib import Path

router = APIRouter()

DATA_DIR = os.getenv("DATA_DIR", "/data")

@router.get("/list")
def list_files(subdir: str = ""):
    base = Path(DATA_DIR).resolve()
    target = (base / subdir).resolve()

    if not str(target).startswith(str(base)):
        raise HTTPException(400, "Invalid subdir")

    if not target.exists():
        raise HTTPException(404, "Path not found")

    if target.is_file():
        return {"type": "file", "path": str(target.relative_to(base))}

    files = []
    for p in sorted(target.iterdir()):
        files.append({
            "name": p.name,
            "type": "dir" if p.is_dir() else "file"
        })

    return {"type": "dir", "path": str(target.relative_to(base)), "items": files}

