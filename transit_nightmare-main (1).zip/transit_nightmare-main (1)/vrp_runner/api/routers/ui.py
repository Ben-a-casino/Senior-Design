import json
from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter()


@router.get("/", response_class=HTMLResponse)
def ui_index():
    # Lightweight single-file GUI (no template engine).
    return HTMLResponse(
        """
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>VRP Runner GUI</title>
    <link
      rel="stylesheet"
      href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
      crossorigin=""
    />
    <style>
      :root {
        --bg: #0b1020;
        --panel: #121a33;
        --text: #e7ecff;
        --muted: #aab5e6;
        --border: rgba(231, 236, 255, 0.12);
        --accent: #7aa2ff;
        --danger: #ff6b6b;
        --ok: #35d07f;
        --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        --sans: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji", "Segoe UI Emoji";
      }
      body {
        margin: 0;
        font-family: var(--sans);
        background: radial-gradient(1200px 600px at 15% 0%, rgba(122, 162, 255, 0.25), transparent 60%),
                    radial-gradient(900px 500px at 90% 10%, rgba(53, 208, 127, 0.16), transparent 55%),
                    var(--bg);
        color: var(--text);
      }
      .wrap { max-width: 1100px; margin: 28px auto; padding: 0 18px; }
      .title { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
      h1 { font-size: 20px; margin: 0; letter-spacing: 0.2px; }
      .sub { color: var(--muted); font-size: 12px; }
      .grid { display: grid; grid-template-columns: 430px 1fr; gap: 14px; margin-top: 14px; }
      .card {
        background: color-mix(in srgb, var(--panel) 92%, #000 8%);
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 14px;
        box-shadow: 0 18px 40px rgba(0,0,0,0.35);
      }
      .row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
      label { display: block; font-size: 12px; color: var(--muted); margin: 10px 0 6px; }
      input, select {
        width: 100%;
        box-sizing: border-box;
        padding: 10px 10px;
        border-radius: 10px;
        border: 1px solid var(--border);
        background: rgba(0,0,0,0.25);
        color: var(--text);
        outline: none;
      }
      input::placeholder { color: rgba(231,236,255,0.45); }
      .check {
        display: flex; gap: 10px; align-items: center; margin-top: 10px;
        padding: 10px; border-radius: 12px; border: 1px dashed var(--border);
        background: rgba(0,0,0,0.14);
      }
      .check input { width: auto; }
      .btns { display: flex; gap: 10px; margin-top: 12px; }
      .btns.right { justify-content: flex-end; }
      button {
        border: 1px solid var(--border);
        background: linear-gradient(180deg, rgba(122,162,255,0.22), rgba(122,162,255,0.08));
        color: var(--text);
        border-radius: 12px;
        padding: 10px 12px;
        cursor: pointer;
      }
      button.secondary {
        background: rgba(0,0,0,0.16);
      }
      button:disabled { opacity: 0.55; cursor: not-allowed; }
      .status { margin-top: 10px; font-size: 12px; color: var(--muted); }
      .status.ok { color: var(--ok); }
      .status.err { color: var(--danger); }
      pre {
        margin: 0;
        font-family: var(--mono);
        font-size: 12px;
        line-height: 1.45;
        white-space: pre-wrap;
        word-break: break-word;
      }
      .pill {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 10px;
        border-radius: 999px;
        border: 1px solid var(--border);
        background: rgba(0,0,0,0.18);
        color: var(--muted);
        font-size: 12px;
      }
      .muted { color: var(--muted); }
      .mono { font-family: var(--mono); }
      .sectionTitle { margin: 0 0 10px; font-size: 13px; color: var(--text); }
      .small { font-size: 11px; }
      .hr { height: 1px; background: var(--border); margin: 12px 0; }

      .fieldWithBtn { display: grid; grid-template-columns: 1fr auto; gap: 10px; align-items: center; }

      .kbd {
        font-family: var(--mono);
        font-size: 11px;
        color: var(--muted);
        border: 1px solid var(--border);
        border-radius: 8px;
        padding: 3px 6px;
        background: rgba(0,0,0,0.18);
      }

      .summaryGrid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px; }
      .miniCard {
        border: 1px solid var(--border);
        border-radius: 12px;
        background: rgba(0,0,0,0.14);
        padding: 10px;
      }

      .modalBg {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.62);
        display: none;
        align-items: center;
        justify-content: center;
        padding: 16px;
        z-index: 999;
      }
      .modal {
        width: min(880px, 100%);
        max-height: min(78vh, 720px);
        overflow: hidden;
        border-radius: 16px;
        border: 1px solid var(--border);
        background: color-mix(in srgb, var(--panel) 94%, #000 6%);
        box-shadow: 0 24px 80px rgba(0,0,0,0.55);
      }
      .modalHeader {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 12px 12px;
        border-bottom: 1px solid var(--border);
      }
      .modalTitle { font-size: 13px; margin: 0; }
      .modalBody { padding: 10px 12px; }
      .pathRow { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; }
      .pathRow .mono { font-size: 12px; }
      .fileList {
        border: 1px solid var(--border);
        border-radius: 14px;
        overflow: auto;
        max-height: 52vh;
        background: rgba(0,0,0,0.14);
      }
      .fileItem {
        display: grid;
        grid-template-columns: 26px 1fr auto;
        gap: 10px;
        padding: 10px 12px;
        border-bottom: 1px solid rgba(231,236,255,0.06);
        cursor: pointer;
        align-items: center;
      }
      .fileItem:hover { background: rgba(122,162,255,0.10); }
      .fileItem:last-child { border-bottom: none; }
      .badge {
        font-family: var(--mono);
        font-size: 11px;
        color: var(--muted);
        border: 1px solid var(--border);
        border-radius: 999px;
        padding: 3px 8px;
        background: rgba(0,0,0,0.16);
      }
      #map {
        width: 100%;
        height: 240px;
        border-radius: 12px;
        border: 1px solid var(--border);
        margin-top: 10px;
      }
    </style>
  </head>
  <body>
    <div class="wrap">
      <div class="title">
        <div>
          <h1>VRP Runner GUI</h1>
          <div class="sub">Solve + optional tract-centroid perturbations (bounded deltas)</div>
        </div>
        <div class="pill mono" id="healthPill">health: …</div>
      </div>

      <div class="grid">
        <div class="card">
          <div class="sectionTitle">Inputs</div>

          <label>Stops CSV (relative to DATA_DIR)</label>
          <div class="fieldWithBtn">
            <input id="stopsCsv" placeholder="inputs/stops.csv" value="inputs/stops.csv" />
            <button class="secondary" id="pickStopsBtn" title="Browse DATA_DIR">Browse</button>
          </div>

          <div class="row">
            <div>
              <label>Vehicles</label>
              <input id="numVehicles" type="number" min="1" value="4" />
            </div>
            <div>
              <label>Capacity</label>
              <input id="vehicleCapacity" type="number" min="1" value="80" />
            </div>
          </div>

          <div class="row">
            <div>
              <label>Time limit (sec)</label>
              <input id="timeLimit" type="number" min="1" value="15" />
            </div>
            <div>
              <label>Depot id (optional)</label>
              <input id="depotId" placeholder="(leave blank)" />
            </div>
          </div>

          <div class="hr"></div>
          <div class="sectionTitle">Child route deltas (pickup_*)</div>

          <div class="check">
            <input id="useDeltas" type="checkbox" />
            <div>
              <div><strong>Enable deltas</strong></div>
              <div class="muted small">Perturb only stops whose id starts with <span class="mono">pickup_</span></div>
            </div>
          </div>

          <div class="row">
            <div>
              <label>Max deltas (count)</label>
              <input id="maxDeltas" type="number" min="0" value="10" />
            </div>
            <div>
              <label>Max offset (meters)</label>
              <input id="maxOffsetMeters" type="number" min="0" value="150" />
            </div>
          </div>

          <label>Seed (optional)</label>
          <input id="deltaSeed" placeholder="e.g. 42" />

          <div class="hr"></div>
          <div class="sectionTitle">Constrain deltas to tract polygons</div>

          <div class="check">
            <input id="constrainToTracts" type="checkbox" />
            <div>
              <div><strong>Keep perturbed point inside tract</strong></div>
              <div class="muted small">Uses <span class="mono">pickup_&lt;TRACT_ID&gt;</span> to match polygon id field (auto-detected)</div>
            </div>
          </div>

          <label>Tracts file (relative to DATA_DIR)</label>
          <div class="fieldWithBtn">
            <input id="tractsFile" placeholder="shapes/census_tracts/census_tracts.geojson" />
            <button class="secondary" id="pickTractsBtn" title="Browse DATA_DIR">Browse</button>
          </div>

          <div class="row">
            <div>
              <label>Tract id field</label>
              <input id="tractIdField" value="auto" />
            </div>
            <div>
              <label>Max resample attempts</label>
              <input id="maxResample" type="number" min="0" value="25" />
            </div>
          </div>

          <div class="btns">
            <button id="runBtn">Solve</button>
            <button class="secondary" id="curlBtn">Copy curl</button>
          </div>
          <div class="status" id="status"></div>
        </div>

        <div class="card">
          <div class="sectionTitle">Result</div>
          <div class="muted small" style="margin-bottom: 10px;">
            Summary + raw JSON from <span class="mono">POST /vrp/solve</span>
          </div>

          <div class="summaryGrid">
            <div class="miniCard">
              <div class="muted small">Objective</div>
              <div class="mono" id="objectiveVal">—</div>
            </div>
            <div class="miniCard">
              <div class="muted small">Routes</div>
              <div class="mono" id="routesCount">—</div>
            </div>
          </div>

          <div class="miniCard" style="margin-bottom: 10px;">
            <div class="muted small" style="margin-bottom: 6px;">Route list</div>
            <pre id="routesText">—</pre>
          </div>

          <div class="miniCard">
            <div class="muted small" style="margin-bottom: 6px;">Raw JSON</div>
            <pre id="output">{}</pre>
          </div>

          <div class="miniCard" style="margin-top: 10px;">
            <div class="muted small" style="margin-bottom: 6px;">Map (Leaflet)</div>
            <div id="map"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="modalBg" id="fileModalBg" role="dialog" aria-modal="true">
      <div class="modal">
        <div class="modalHeader">
          <div>
            <div class="modalTitle"><strong id="fileModalTitle">Browse files</strong></div>
            <div class="muted small">Uses <span class="mono">GET /data/list</span>. Tip: click a folder to enter, click a file to select.</div>
          </div>
          <div class="btns right">
            <button class="secondary" id="fileModalCloseBtn">Close <span class="kbd">Esc</span></button>
          </div>
        </div>
        <div class="modalBody">
          <div class="pathRow">
            <button class="secondary" id="fileUpBtn" title="Go up one folder">Up</button>
            <div class="muted small">Path:</div>
            <div class="mono" id="filePathMono"></div>
          </div>
          <div class="fileList" id="fileList"></div>
          <div class="muted small" style="margin-top: 10px;">
            Selecting sets <span class="mono" id="fileTargetLabel">…</span>.
          </div>
        </div>
      </div>
    </div>

    <script
      src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
      integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
      crossorigin=""
    ></script>
    <script>
      const $ = (id) => document.getElementById(id);
      let modalTargetInputId = null;
      let modalPath = "";
      let map = null;
      let mapLayerGroup = null;

      function setEnabled(el, enabled) {
        el.disabled = !enabled;
        el.style.opacity = enabled ? "1" : "0.6";
      }

      function refreshEnablement() {
        const deltasOn = $("useDeltas").checked;
        setEnabled($("maxDeltas"), deltasOn);
        setEnabled($("maxOffsetMeters"), deltasOn);
        setEnabled($("deltaSeed"), deltasOn);

        const tractsOn = $("constrainToTracts").checked;
        setEnabled($("tractsFile"), deltasOn && tractsOn);
        setEnabled($("pickTractsBtn"), deltasOn && tractsOn);
        setEnabled($("tractIdField"), deltasOn && tractsOn);
        setEnabled($("maxResample"), deltasOn && tractsOn);
      }

      function applyPreset(name) {
        // Simple presets for common exploration modes
        if (name === "none") {
          $("useDeltas").checked = false;
          $("constrainToTracts").checked = false;
        } else if (name === "light") {
          $("useDeltas").checked = true;
          $("constrainToTracts").checked = false;
          $("maxDeltas").value = 10;
          $("maxOffsetMeters").value = 150;
          $("deltaSeed").value = "42";
        } else if (name === "constrained") {
          $("useDeltas").checked = true;
          $("constrainToTracts").checked = true;
          $("maxDeltas").value = 10;
          $("maxOffsetMeters").value = 150;
          $("deltaSeed").value = "42";
          if (!$("tractsFile").value) {
            $("tractsFile").value = "shapes/census_tracts/census_tracts.geojson";
          }
          $("tractIdField").value = "auto";
        }
        refreshEnablement();
      }

      function getPayload() {
        const depot = $("depotId").value.trim();
        const seedRaw = $("deltaSeed").value.trim();
        const seed = seedRaw === "" ? null : Number(seedRaw);

        const payload = {
          stops_csv: $("stopsCsv").value.trim() || "inputs/stops.csv",
          num_vehicles: Number($("numVehicles").value),
          vehicle_capacity: Number($("vehicleCapacity").value),
          time_limit_seconds: Number($("timeLimit").value),
          depot_id: depot === "" ? null : depot,

          use_child_route_deltas: $("useDeltas").checked,
          max_deltas: Number($("maxDeltas").value),
          max_offset_meters: Number($("maxOffsetMeters").value),
          delta_seed: seed,

          constrain_deltas_to_tracts: $("constrainToTracts").checked,
          tracts_file: $("tractsFile").value.trim() || null,
          tract_id_field: $("tractIdField").value.trim() || "auto",
          max_resample_attempts: Number($("maxResample").value),
        };

        // keep request clean
        if (payload.delta_seed === null) delete payload.delta_seed;
        if (payload.depot_id === null) delete payload.depot_id;
        if (payload.tracts_file === null) delete payload.tracts_file;

        return payload;
      }

      function setStatus(kind, msg) {
        const el = $("status");
        el.className = "status" + (kind ? (" " + kind) : "");
        el.textContent = msg || "";
      }

      async function checkHealth() {
        try {
          const r = await fetch("/health");
          const j = await r.json();
          $("healthPill").textContent = "health: " + (j.status || "ok");
          $("healthPill").style.borderColor = "rgba(53,208,127,0.35)";
        } catch (_) {
          $("healthPill").textContent = "health: down";
          $("healthPill").style.borderColor = "rgba(255,107,107,0.35)";
        }
      }

      function renderSummary(resp) {
        try {
          $("objectiveVal").textContent = (resp && typeof resp.objective !== "undefined") ? String(resp.objective) : "—";
          $("routesCount").textContent = (resp && Array.isArray(resp.routes)) ? String(resp.routes.length) : "—";

          if (!resp || !Array.isArray(resp.routes) || resp.routes.length === 0) {
            $("routesText").textContent = "—";
            return;
          }

          const lines = [];
          for (const r of resp.routes) {
            const vehicle = r.vehicle;
            const load = r.load;
            const dist = r.distance;
            const stops = (r.stop_ids || []).join(" → ");
            lines.push(`vehicle ${vehicle} | load=${load} | dist=${dist}`);
            lines.push(stops);
            lines.push("");
          }
          $("routesText").textContent = lines.join("\\n").trim();
        } catch (_) {
          $("objectiveVal").textContent = "—";
          $("routesCount").textContent = "—";
          $("routesText").textContent = "—";
        }
      }

      function ensureMap() {
        if (map) return;
        map = L.map("map");
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>',
        }).addTo(map);
        mapLayerGroup = L.layerGroup().addTo(map);
      }

      function clearMap() {
        ensureMap();
        mapLayerGroup.clearLayers();
      }

      function renderMap(resp, stops) {
        try {
          ensureMap();
          clearMap();

          if (!resp || !Array.isArray(resp.routes) || resp.routes.length === 0) {
            map.setView([39.29, -76.61], 11);
            return;
          }

          // build id -> coord
          const coords = {};
          for (const s of stops || []) {
            coords[s.id] = [s.lat, s.lon];
          }

          const colors = ["#7aa2ff", "#35d07f", "#ffcc66", "#ff6b6b", "#c792ea", "#4dd0e1"];
          const bounds = [];

          resp.routes.forEach((r, idx) => {
            const color = colors[idx % colors.length];
            const pts = [];
            (r.stop_ids || []).forEach((sid) => {
              const c = coords[sid];
              if (c) {
                pts.push(c);
                bounds.push(c);
              }
            });
            if (pts.length >= 2) {
              L.polyline(pts, { color, weight: 4, opacity: 0.9 }).addTo(mapLayerGroup);
            }
          });

          // markers for stops we actually used
          for (const [sid, c] of Object.entries(coords)) {
            if (!bounds.find((b) => b[0] === c[0] && b[1] === c[1])) continue;
            const isPickup = sid.startsWith("pickup_");
            const isSchool = sid.startsWith("school_");
            const iconColor = isPickup ? "#7aa2ff" : (isSchool ? "#ffcc66" : "#35d07f");
            const marker = L.circleMarker(c, {
              radius: 4,
              color: iconColor,
              weight: 1.5,
              fillColor: iconColor,
              fillOpacity: 0.9,
            });
            marker.bindTooltip(sid, { permanent: false, direction: "top", offset: [0, -4] });
            marker.addTo(mapLayerGroup);
          }

          if (bounds.length > 0) {
            map.fitBounds(bounds, { padding: [20, 20] });
          } else {
            map.setView([39.29, -76.61], 11);
          }
        } catch (e) {
          console.error("renderMap error", e);
        }
      }

      function buildCurl(payload) {
        const body = JSON.stringify(payload, null, 2);
        return [
          'curl -X POST "http://localhost:8000/vrp/solve" ^',
          '  -H "Content-Type: application/json" ^',
          '  -d ' + JSON.stringify(body)
        ].join("\\n");
      }

      async function listDir(subdir) {
        const qs = new URLSearchParams();
        qs.set("subdir", subdir || "");
        const r = await fetch("/data/list?" + qs.toString());
        if (!r.ok) {
          const t = await r.text();
          throw new Error(t || r.statusText);
        }
        return await r.json();
      }

      function openModal(targetInputId, title) {
        modalTargetInputId = targetInputId;
        $("fileModalTitle").textContent = title || "Browse files";
        $("fileTargetLabel").textContent = "#" + targetInputId;
        $("fileModalBg").style.display = "flex";
        loadModalPath("");
      }

      function closeModal() {
        $("fileModalBg").style.display = "none";
        modalTargetInputId = null;
        modalPath = "";
        $("fileList").innerHTML = "";
      }

      async function loadModalPath(path) {
        modalPath = path || "";
        $("filePathMono").textContent = modalPath === "" ? "." : modalPath;
        $("fileList").innerHTML = '<div class="fileItem"><div class="badge">…</div><div class="muted">Loading…</div><div></div></div>';

        try {
          const listing = await listDir(modalPath);
          const items = listing.items || [];

          const rows = [];
          if (modalPath !== "") {
            rows.push({ name: "..", type: "dir" });
          }
          for (const it of items) rows.push(it);

          $("fileList").innerHTML = "";
          for (const it of rows) {
            const isDir = it.type === "dir";
            const icon = isDir ? "dir" : "file";
            const badge = isDir ? "dir" : (String(it.name).split(".").pop() || "file");
            const el = document.createElement("div");
            el.className = "fileItem";
            el.innerHTML = `<div class="badge">${badge}</div><div class="mono">${it.name}</div><div class="muted small">${icon}</div>`;
            el.addEventListener("click", () => {
              if (it.name === "..") {
                const parts = modalPath.split("/").filter(Boolean);
                parts.pop();
                loadModalPath(parts.join("/"));
                return;
              }
              if (isDir) {
                const next = (modalPath ? (modalPath + "/") : "") + it.name;
                loadModalPath(next);
              } else {
                const selected = (modalPath ? (modalPath + "/") : "") + it.name;
                if (modalTargetInputId) {
                  $(modalTargetInputId).value = selected;
                }
                closeModal();
                refreshEnablement();
              }
            });
            $("fileList").appendChild(el);
          }
        } catch (e) {
          $("fileList").innerHTML = `<div class="fileItem"><div class="badge">err</div><div class="mono">${String(e)}</div><div></div></div>`;
        }
      }

      $("curlBtn").addEventListener("click", async () => {
        const payload = getPayload();
        const curl = buildCurl(payload);
        await navigator.clipboard.writeText(curl);
        setStatus("ok", "Copied curl to clipboard.");
        setTimeout(() => setStatus("", ""), 1500);
      });

      $("runBtn").addEventListener("click", async () => {
        const payload = getPayload();
        $("runBtn").disabled = true;
        setStatus("", "Solving…");
        $("output").textContent = "{}";
        clearMap();

        try {
          const r = await fetch("/vrp/solve", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(payload),
          });

          const text = await r.text();
          let parsed = null;
          try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }

          if (!r.ok) {
            setStatus("err", "Error: " + (parsed.detail || r.statusText));
          } else {
            setStatus("ok", "Done.");
          }
          $("output").textContent = JSON.stringify(parsed, null, 2);
          renderSummary(parsed);

          // fetch stops for mapping
          const stopsCsv = $("stopsCsv").value.trim() || "inputs/stops.csv";
          try {
            const qs = new URLSearchParams();
            qs.set("stops_csv", stopsCsv);
            const rs = await fetch("/vrp/stops?" + qs.toString());
            if (rs.ok) {
              const stops = await rs.json();
              renderMap(parsed, stops);
            }
          } catch (e) {
            console.error("failed to load stops for map", e);
          }
        } catch (e) {
          setStatus("err", "Request failed: " + String(e));
        } finally {
          $("runBtn").disabled = false;
        }
      });

      checkHealth();
      setInterval(checkHealth, 5000);

      $("useDeltas").addEventListener("change", refreshEnablement);
      $("constrainToTracts").addEventListener("change", refreshEnablement);
      refreshEnablement();

      $("pickStopsBtn").addEventListener("click", () => openModal("stopsCsv", "Select stops CSV"));
      $("pickTractsBtn").addEventListener("click", () => openModal("tractsFile", "Select tracts file"));
      $("fileModalCloseBtn").addEventListener("click", closeModal);
      $("fileModalBg").addEventListener("click", (e) => {
        if (e.target === $("fileModalBg")) closeModal();
      });
      $("fileUpBtn").addEventListener("click", () => {
        const parts = modalPath.split("/").filter(Boolean);
        parts.pop();
        loadModalPath(parts.join("/"));
      });
      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && $("fileModalBg").style.display === "flex") closeModal();
      });

      // Simple keyboard presets for power users
      window.addEventListener("keydown", (e) => {
        if (e.target.tagName === "INPUT") return;
        if (e.key === "1") applyPreset("none");        // baseline
        if (e.key === "2") applyPreset("light");       // light deltas
        if (e.key === "3") applyPreset("constrained"); // constrained deltas
      });
    </script>
  </body>
</html>
        """.strip()
    )

