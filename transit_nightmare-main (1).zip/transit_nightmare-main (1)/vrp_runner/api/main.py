from fastapi import FastAPI
from api.routers import vrp, data
from api.routers.ui import router as ui_router

app = FastAPI(title="VRP Runner", version="0.1.0")

app.include_router(data.router, prefix="/data", tags=["data"])
app.include_router(vrp.router, prefix="/vrp", tags=["vrp"])
app.include_router(ui_router, prefix="/ui", tags=["ui"])

@app.get("/health")
def health():
    return {"status": "ok"}

