# Integration Guide: Transit Nightmare → VRP Runner

This guide explains how to extract data from the transit_nightmare repository and use it with the VRP Runner.

## Overview

The integration consists of three main steps:

1. **Extract** data from transit_nightmare repository
2. **Transform** into VRP-ready format (stops.csv)
3. **Sync** to OneDrive for use with VRP Runner API

## Quick Start

### Step 1: Install Dependencies

```bash
cd vrp_runner
pip install -r requirements.txt
```

### Step 2: Configure Data Extraction

```bash
cd scripts
cp config.example.yaml config.yaml
```

Edit `config.yaml`:
- Set `transit_nightmare_dir` to your repository path
- Set `output_dir` for local output
- Configure `onedrive.local_sync_path` to your OneDrive folder

### Step 3: Extract and Sync Data

```bash
python sync_transit_data.py
```

This will:
- Extract school locations from GeoJSON/shapefiles
- Extract student pickup locations from census tract data
- Combine into `stops.csv` format
- Upload to your OneDrive sync folder

### Step 4: Configure VRP Runner

Edit `vrp_runner/.env`:

```env
HOST_DATA_DIR=C:\Users\YOU\OneDrive\transit_nightmare_data
DATA_DIR=/data
DISTANCE_MODE=haversine
```

### Step 5: Start VRP API

```bash
cd vrp_runner
docker compose up --build
```

### Step 6: Solve VRP

```bash
curl -X POST "http://localhost:8000/vrp/solve" \
  -H "Content-Type: application/json" \
  -d '{
    "stops_csv": "inputs/stops.csv",
    "num_vehicles": 4,
    "vehicle_capacity": 80,
    "time_limit_seconds": 15
  }'
```

## Data Flow

```
transit_nightmare repository
    ↓
[extract_transit_data.py]
    ↓
stops.csv (VRP format)
    ↓
OneDrive sync folder
    ↓
[Docker volume mount]
    ↓
VRP Runner API
    ↓
Optimized routes
```

## Data Sources

### Schools
- **Location**: `data/shapes/school_parcels/school_parcels.geojson`
- **Filter**: Middle and high schools (grades 6-12)
- **Output**: School destinations with lat/lon

### Student Pickup Locations
- **Enrollment**: `data/home_tracts/REVISED Banner Request-Enroll by Prog and Tract-2024.08.08.xlsx`
- **Locations**: 
  - Preferred: Sampled grid points (`data/shapes/bmore_grid_sampled_01_27.geojson`)
  - Fallback: Census tract centers
- **Output**: Pickup points with student demand

### Bus Stops (Optional)
- **Location**: `data/setup/Baltimore_Region_Public_Transit_(stops).csv`
- **Output**: Bus stop locations (can be used as intermediate stops)

## Output Format

The extraction script generates `stops.csv`:

```csv
id,lat,lon,demand
depot,39.2904,-76.6122,0
pickup_tract_12345,39.2950,-76.6100,10
pickup_tract_67890,39.2850,-76.6200,15
school_001,39.2800,-76.6150,0
school_002,39.3000,-76.6050,0
```

**Stop Types:**
- `depot`: Starting/ending point (first school)
- `pickup_*`: Student pickup locations with demand
- `school_*`: School destinations (demand=0)

## OneDrive Integration

### Option A: Local Sync (Recommended)

1. Set up OneDrive sync on your machine
2. Configure `onedrive.local_sync_path` in `config.yaml`
3. Run extraction script - files are copied to OneDrive folder
4. OneDrive automatically syncs to cloud
5. VRP Runner Docker volume mounts the local OneDrive folder

**Advantages:**
- No authentication required
- Automatic sync
- Works offline
- Simple setup

### Option B: Microsoft Graph API

1. Register Azure App with Graph API permissions
2. Get `TENANT_ID` and `CLIENT_ID`
3. Set `onedrive.use_graph_api: true` in config
4. Script authenticates via device code flow
5. Files uploaded directly to OneDrive

**Advantages:**
- Works without local OneDrive client
- Can upload to shared drives
- Programmatic control

## Troubleshooting

### Data Extraction Issues

**"File not found" errors:**
- Verify transit_nightmare repository is downloaded
- Check data files exist in expected locations
- Update paths in `config.yaml`

**"No student locations found":**
- Check enrollment Excel file exists
- Verify census tract shapefiles available
- Try `use_sampled_points: false` in config

**"geopandas/openpyxl not installed":**
```bash
pip install geopandas openpyxl
```

### OneDrive Sync Issues

**Local sync not working:**
- Verify OneDrive folder path is correct
- Check OneDrive is running and synced
- Ensure folder exists before running script

**Graph API authentication fails:**
- Verify Azure app registration
- Check permissions (Files.ReadWrite.All)
- Ensure tenant_id and client_id are correct

### VRP Runner Issues

**"stops.csv not found":**
- Verify file is in OneDrive sync folder
- Check `HOST_DATA_DIR` in `.env` matches OneDrive path
- Ensure Docker volume mount is working

**"Need at least 2 stops":**
- Check stops.csv has valid data
- Verify lat/lon columns are numeric
- Ensure depot is included

## Advanced Usage

### Custom Depot Selection

```bash
python extract_transit_data.py \
  --transit-dir ../transit_nightmare-main \
  --output-dir ./data \
  --depot-id "school_001"
```

### Include Bus Stops

```bash
python extract_transit_data.py \
  --transit-dir ../transit_nightmare-main \
  --output-dir ./data \
  --include-bus-stops
```

### Use Graph API Upload

```bash
export TENANT_ID="your-tenant-id"
export CLIENT_ID="your-client-id"

python extract_transit_data.py \
  --transit-dir ../transit_nightmare-main \
  --output-dir ./data \
  --onedrive-path "/transit_nightmare_data/inputs/stops.csv" \
  --use-graph-api
```

## Example Workflow

```bash
# 1. Setup
cd vrp_runner/scripts
cp config.example.yaml config.yaml
# Edit config.yaml

# 2. Extract data
python sync_transit_data.py

# 3. Verify output
head -10 ../transit_nightmare_data/inputs/stops.csv

# 4. Configure VRP Runner
cd ..
cp .env.example .env
# Edit .env with OneDrive path

# 5. Start API
docker compose up --build

# 6. Test in another terminal
curl http://localhost:8000/health

# 7. Solve VRP
curl -X POST "http://localhost:8000/vrp/solve" \
  -H "Content-Type: application/json" \
  -d '{
    "stops_csv": "inputs/stops.csv",
    "num_vehicles": 4,
    "vehicle_capacity": 80,
    "time_limit_seconds": 15
  }' | jq
```

## Next Steps

- Adjust vehicle capacity based on bus sizes
- Experiment with different distance modes (haversine vs matrix_csv)
- Add time windows for school start times
- Implement multi-depot scenarios
- Integrate with real-time bus location data

