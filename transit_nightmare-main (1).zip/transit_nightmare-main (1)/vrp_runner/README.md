# VRP Runner

A Docker-based Vehicle Routing Problem (VRP) solver API using OR-Tools, designed to work with data from The Baltimore Banner's transit_nightmare repository.

## Features

- **FastAPI-based REST API** for VRP solving
- **OR-Tools integration** for high-quality solutions
- **OneDrive integration** via local sync or Microsoft Graph API
- **Flexible distance calculation**: Haversine (default) or CSV distance matrix
- **Dockerized** for easy deployment and isolation

## Project Structure

```
vrp_runner/
├── docker/
│   └── Dockerfile
├── api/
│   ├── main.py
│   ├── schemas.py
│   └── routers/
│       ├── __init__.py
│       ├── data.py
│       ├── vrp.py
│       └── ui.py
├── vrp/
│   ├── __init__.py
│   ├── solver.py
│   ├── distances.py
│   ├── io.py
│   └── route_deltas.py
├── scripts/
│   └── fetch_onedrive_device_code.py
├── VRP_FEATURES.md
├── requirements.txt
├── docker-compose.yml
├── .env.example
├── run_vrp_server.ps1
└── README.md
```

## Quick Start

### 1. Setup Environment

Copy the example environment file and configure it:

```bash
cp .env.example .env
```

Edit `.env` and set `HOST_DATA_DIR` to your OneDrive-synced folder path:

**Windows:**
```
HOST_DATA_DIR=C:\Users\YOU\OneDrive\transit_nightmare_data
```

**macOS:**
```
HOST_DATA_DIR=/Users/YOU/Library/CloudStorage/OneDrive-.../transit_nightmare_data
```

**Linux:**
```
HOST_DATA_DIR=/home/YOU/OneDrive/transit_nightmare_data
```

### 2. Prepare Data

Place your data files in the OneDrive folder following the structure:

```
transit_nightmare_data/
└── inputs/
    └── stops.csv
```

**Expected `stops.csv` format:**

```csv
id,lat,lon,demand
depot,39.2904,-76.6122,0
s1,39.2950,-76.6100,10
s2,39.2850,-76.6200,15
...
```

### 3. Start the API

**Docker (original flow):**

```bash
docker compose up --build
```

The API will be available at `http://localhost:8000`

**Local (no Docker, Windows convenience script):**

```powershell
.\run_vrp_server.ps1
```

This will:

- Create/activate a `.venv` virtualenv,
- Install `requirements.txt`,
- Start `uvicorn api.main:app --reload --port 8000`,
- Open your browser to `http://localhost:8000/ui/`.

### 4. Test the API

**Health check:**
```bash
curl http://localhost:8000/health
```

**List data files:**
```bash
curl "http://localhost:8000/data/list?subdir="
```

**Solve VRP:**
```bash
curl -X POST "http://localhost:8000/vrp/solve" \
  -H "Content-Type: application/json" \
  -d '{
    "stops_csv": "inputs/stops.csv",
    "num_vehicles": 4,
    "vehicle_capacity": 80,
    "time_limit_seconds": 15
  }'
```

## API Endpoints

### Health Check
- `GET /health` - Returns API status

### Data Management
- `GET /data/list?subdir=<path>` - List files in the data directory

### VRP Solving
- `POST /vrp/solve` - Solve a VRP instance

#### Solve Request Body

```json
{
  "stops_csv": "inputs/stops.csv",  // Path relative to DATA_DIR
  "depot_id": "depot",               // Optional: ID of depot stop
  "num_vehicles": 4,                 // Number of vehicles
  "vehicle_capacity": 80,            // Capacity per vehicle
  "time_limit_seconds": 15,          // Solver time limit
  "distance_mode": "haversine"       // Optional: override env setting
}
```

Or provide stops inline:

```json
{
  "stops": [
    {"id": "depot", "lat": 39.2904, "lon": -76.6122, "demand": 0},
    {"id": "s1", "lat": 39.2950, "lon": -76.6100, "demand": 10}
  ],
  "num_vehicles": 3,
  "vehicle_capacity": 100
}
```

#### Solve Response

```json
{
  "objective": 12345.67,
  "routes": [
    {
      "vehicle": 0,
      "stop_ids": ["depot", "s1", "s2", "depot"],
      "load": 25,
      "distance": 5432.1
    }
  ],
  "meta": {
    "distance_mode": "haversine",
    "depot_id": "depot",
    "num_stops": 10
  }
}
```

## Distance Calculation Modes

### Haversine (Default)
Calculates great-circle distances between coordinates. Set in `.env`:
```
DISTANCE_MODE=haversine
```

### CSV Distance Matrix
Use a pre-computed distance matrix from a CSV file. Set in `.env`:
```
DISTANCE_MODE=matrix_csv
DISTANCE_MATRIX_FILE=/data/dist_matrix.csv
```

**CSV formats supported:**

1. **Long format:**
```csv
from_id,to_id,distance_meters
depot,s1,1234
depot,s2,2345
s1,s2,567
```

2. **Wide format (square matrix):**
```csv
id,depot,s1,s2
depot,0,1234,2345
s1,1234,0,567
s2,2345,567,0
```

## OneDrive Integration

### Option A: Local Sync (Recommended)

1. Sync your OneDrive folder locally
2. Set `HOST_DATA_DIR` in `.env` to the local path
3. The Docker volume will mount it automatically

### Option B: Microsoft Graph API

Use the provided script to download files from OneDrive:

```bash
export TENANT_ID="your-tenant-id"
export CLIENT_ID="your-client-id"
export ITEM_PATH="/transit_nightmare_data/inputs/stops.csv"
export OUT_FILE="/absolute/path/to/local/stops.csv"

python scripts/fetch_onedrive_device_code.py
```

**Note:** You'll need to register an Azure App with Microsoft Graph API permissions (`Files.Read.All`, `User.Read`).

## Integration with transit_nightmare

1. Generate your data outputs from the transit_nightmare repo (per its README.md#data)
2. Place outputs in your OneDrive-synced folder
3. Create a `stops.csv` file in `inputs/` with the required format
4. Use this VRP Runner API to solve routing problems

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `HOST_DATA_DIR` | Host path to OneDrive-synced data folder | Required |
| `DATA_DIR` | Path inside container | `/data` |
| `DISTANCE_MODE` | Distance calculation method | `haversine` |
| `DISTANCE_MATRIX_FILE` | Path to CSV distance matrix (if using `matrix_csv`) | - |

## Development

### Running Locally (without Docker)

```bash
pip install -r requirements.txt
export DATA_DIR=/path/to/data
uvicorn api.main:app --reload
```

### Building Docker Image

```bash
docker build -f docker/Dockerfile -t vrp-runner .
```

## License

This framework is designed to work alongside The Baltimore Banner's transit_nightmare repository.

